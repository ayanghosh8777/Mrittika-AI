import { CropPredictionInput, CropPredictionAnalysis } from '../types';

interface CropReference {
  name: string;
  hindiName: string;
  variety: string;
  n: [number, number];
  p: [number, number];
  k: [number, number];
  ph: [number, number];
  temp: [number, number];
  humidity: [number, number];
  rainfall: [number, number];
  yieldRange: string;
  revenueRange: string;
  waterReq: string;
  advisory: string;
  historicalPrices: { year: string; price: number }[];
}

export const CROP_DATABASE: CropReference[] = [
  {
    name: 'Wheat (गेहूं)',
    hindiName: 'गेहूं (HI-8627 Sharbati)',
    variety: 'Sharbati Gold MP-306 / HI-8627',
    n: [100, 140],
    p: [45, 65],
    k: [30, 50],
    ph: [6.0, 7.5],
    temp: [16, 25],
    humidity: [50, 65],
    rainfall: [50, 95],
    yieldRange: '22 - 26 Quintals / Acre',
    revenueRange: '₹68,000 - ₹82,000 / Acre',
    waterReq: '3 - 4 critical irrigations (CRI and flowering stages)',
    advisory: 'Best sown in early November. Optimal for loamy to black soils with balanced phosphorus.',
    historicalPrices: [
      { year: '2022', price: 2150 },
      { year: '2023', price: 2420 },
      { year: '2024', price: 2680 },
      { year: '2025', price: 2950 },
      { year: '2026', price: 3120 },
    ],
  },
  {
    name: 'Rice / Paddy (धान)',
    hindiName: 'बासमती धान (Pusa 1121)',
    variety: 'Basmati 1121 Sugandh',
    n: [70, 110],
    p: [35, 60],
    k: [35, 50],
    ph: [5.5, 7.2],
    temp: [22, 32],
    humidity: [75, 90],
    rainfall: [180, 300],
    yieldRange: '24 - 28 Quintals / Acre',
    revenueRange: '₹75,000 - ₹95,000 / Acre',
    waterReq: 'Continuous standing moisture or alternate wetting/drying',
    advisory: 'High water requirement. Ideal for high rainfall alluvial soils and irrigated canal belts.',
    historicalPrices: [
      { year: '2022', price: 3350 },
      { year: '2023', price: 3720 },
      { year: '2024', price: 3980 },
      { year: '2025', price: 4150 },
      { year: '2026', price: 4280 },
    ],
  },
  {
    name: 'Mustard (सरसों)',
    hindiName: 'पीली सरसों (Pioneer 45S46)',
    variety: 'Pioneer 45S46 / RH-749',
    n: [60, 90],
    p: [30, 50],
    k: [30, 50],
    ph: [6.2, 7.8],
    temp: [14, 22],
    humidity: [45, 65],
    rainfall: [30, 65],
    yieldRange: '8 - 11 Quintals / Acre',
    revenueRange: '₹46,000 - ₹58,000 / Acre',
    waterReq: 'Low water requirement (1 - 2 irrigations)',
    advisory: 'Thrives in lower rainfall and cool winter temperatures. Highly remunerative with low seed cost.',
    historicalPrices: [
      { year: '2022', price: 4850 },
      { year: '2023', price: 5120 },
      { year: '2024', price: 5350 },
      { year: '2025', price: 5520 },
      { year: '2026', price: 5640 },
    ],
  },
  {
    name: 'Cotton (कपास)',
    hindiName: 'कपास (Shankar-6 Long Staple)',
    variety: 'Bt Shankar-6 Long Staple',
    n: [100, 140],
    p: [40, 65],
    k: [40, 65],
    ph: [6.2, 8.2],
    temp: [22, 34],
    humidity: [55, 75],
    rainfall: [65, 120],
    yieldRange: '12 - 16 Quintals / Acre',
    revenueRange: '₹84,000 - ₹1,12,000 / Acre',
    waterReq: 'Moderate, sensitive to waterlogging at vegetative stage',
    advisory: 'Deep black cotton soil with high clay capacity provides highest boll weight.',
    historicalPrices: [
      { year: '2022', price: 6200 },
      { year: '2023', price: 6750 },
      { year: '2024', price: 7100 },
      { year: '2025', price: 7350 },
      { year: '2026', price: 7520 },
    ],
  },
  {
    name: 'Chickpea / Chana (चना)',
    hindiName: 'देसी चना (JG-11 / Vishal)',
    variety: 'JG-11 Desi / JAKI-9218',
    n: [20, 45],
    p: [50, 75],
    k: [65, 90],
    ph: [6.0, 7.8],
    temp: [16, 25],
    humidity: [40, 60],
    rainfall: [35, 75],
    yieldRange: '9 - 13 Quintals / Acre',
    revenueRange: '₹48,000 - ₹62,000 / Acre',
    waterReq: 'Minimal, rainfed or single flowering irrigation',
    advisory: 'Nitrogen-fixing pulse. Requires higher phosphorus and potassium for vigorous nodulation.',
    historicalPrices: [
      { year: '2022', price: 4400 },
      { year: '2023', price: 4750 },
      { year: '2024', price: 5050 },
      { year: '2025', price: 5300 },
      { year: '2026', price: 5580 },
    ],
  },
  {
    name: 'Soybean (सोयाबीन)',
    hindiName: 'सोयाबीन (JS-9560)',
    variety: 'JS-9560 / RVS-2001-4',
    n: [25, 45],
    p: [55, 80],
    k: [35, 55],
    ph: [6.2, 7.6],
    temp: [22, 30],
    humidity: [65, 85],
    rainfall: [90, 160],
    yieldRange: '10 - 13 Quintals / Acre',
    revenueRange: '₹46,000 - ₹58,000 / Acre',
    waterReq: 'Moderate rainfall with drainage to avoid collar rot',
    advisory: 'Excellent rotation crop for black soils. Early maturity (90-95 days) allows double cropping.',
    historicalPrices: [
      { year: '2022', price: 3900 },
      { year: '2023', price: 4250 },
      { year: '2024', price: 4420 },
      { year: '2025', price: 4500 },
      { year: '2026', price: 4580 },
    ],
  },
  {
    name: 'Maize / Corn (मक्का)',
    hindiName: 'मक्का (Kaveri 50 Super)',
    variety: 'Kaveri 50 / Pioneer 3396',
    n: [80, 120],
    p: [40, 65],
    k: [25, 45],
    ph: [5.8, 7.4],
    temp: [18, 30],
    humidity: [55, 78],
    rainfall: [70, 130],
    yieldRange: '26 - 32 Quintals / Acre',
    revenueRange: '₹55,000 - ₹68,000 / Acre',
    waterReq: 'Sensitive to moisture stress at silking stage',
    advisory: 'Rapid vegetative biomass growth. Benefits from split nitrogen applications.',
    historicalPrices: [
      { year: '2022', price: 1850 },
      { year: '2023', price: 2050 },
      { year: '2024', price: 2180 },
      { year: '2025', price: 2290 },
      { year: '2026', price: 2380 },
    ],
  },
];

// Calculation function
export function analyzeCropSuitability(input: CropPredictionInput): CropPredictionAnalysis {
  // Score each crop by closeness to parameters
  const scoredCrops = CROP_DATABASE.map((crop) => {
    // Normalization helper
    const calcParamScore = (val: number, range: [number, number]) => {
      const [min, max] = range;
      if (val >= min && val <= max) return 1.0;
      const center = (min + max) / 2;
      const span = (max - min) / 2 || 1;
      const diff = Math.abs(val - center);
      const score = Math.max(0.1, 1.0 - (diff - span) / (span * 2));
      return Math.min(1.0, score);
    };

    const nScore = calcParamScore(input.nitrogen, crop.n);
    const pScore = calcParamScore(input.phosphorus, crop.p);
    const kScore = calcParamScore(input.potassium, crop.k);
    const phScore = calcParamScore(input.ph, crop.ph);
    const tempScore = calcParamScore(input.temperature, crop.temp);
    const humScore = calcParamScore(input.humidity, crop.humidity);
    const rainScore = calcParamScore(input.rainfall, crop.rainfall);

    // Weighted aggregate score
    const soilScore = (nScore * 0.3 + pScore * 0.25 + kScore * 0.25 + phScore * 0.2) * 100;
    const climateScore = (tempScore * 0.35 + humScore * 0.3 + rainScore * 0.35) * 100;
    const totalScore = soilScore * 0.5 + climateScore * 0.5;

    return {
      crop,
      totalScore,
      soilScore,
      climateScore,
    };
  });

  // Sort descending
  scoredCrops.sort((a, b) => b.totalScore - a.totalScore);

  const best = scoredCrops[0];
  const second = scoredCrops[1] || scoredCrops[0];

  const primary = best.crop;

  // Build NPK comparison breakdown
  const getNutrientStatus = (val: number, range: [number, number]) => {
    if (val < range[0]) return 'Deficient' as const;
    if (val > range[1]) return 'Excess' as const;
    return 'Optimal' as const;
  };

  const npkComparison = [
    {
      nutrient: 'Nitrogen (N)' as const,
      input: input.nitrogen,
      idealMin: primary.n[0],
      idealMax: primary.n[1],
      status: getNutrientStatus(input.nitrogen, primary.n),
    },
    {
      nutrient: 'Phosphorus (P)' as const,
      input: input.phosphorus,
      idealMin: primary.p[0],
      idealMax: primary.p[1],
      status: getNutrientStatus(input.phosphorus, primary.p),
    },
    {
      nutrient: 'Potassium (K)' as const,
      input: input.potassium,
      idealMin: primary.k[0],
      idealMax: primary.k[1],
      status: getNutrientStatus(input.potassium, primary.k),
    },
  ];

  // Climate comparison
  const getClimateStatus = (val: number, range: [number, number]) => {
    if (val >= range[0] && val <= range[1]) return 'Ideal' as const;
    const margin = (range[1] - range[0]) * 0.3;
    if (val >= range[0] - margin && val <= range[1] + margin) return 'Acceptable' as const;
    return 'Stress' as const;
  };

  const climateComparison = [
    {
      parameter: 'Temperature' as const,
      input: input.temperature,
      idealMin: primary.temp[0],
      idealMax: primary.temp[1],
      unit: '°C',
      status: getClimateStatus(input.temperature, primary.temp),
    },
    {
      parameter: 'Humidity' as const,
      input: input.humidity,
      idealMin: primary.humidity[0],
      idealMax: primary.humidity[1],
      unit: '%',
      status: getClimateStatus(input.humidity, primary.humidity),
    },
    {
      parameter: 'Rainfall' as const,
      input: input.rainfall,
      idealMin: primary.rainfall[0],
      idealMax: primary.rainfall[1],
      unit: 'mm',
      status: getClimateStatus(input.rainfall, primary.rainfall),
    },
    {
      parameter: 'Soil pH' as const,
      input: input.ph,
      idealMin: primary.ph[0],
      idealMax: primary.ph[1],
      unit: 'pH',
      status: getClimateStatus(input.ph, primary.ph),
    },
  ];

  // Seasonal Monthly Suitability
  const monthlySuitability = [
    { month: 'Oct', score: Math.round(best.totalScore * 0.92) },
    { month: 'Nov', score: Math.round(best.totalScore * 1.0) },
    { month: 'Dec', score: Math.round(best.totalScore * 0.96) },
    { month: 'Jan', score: Math.round(best.totalScore * 0.91) },
    { month: 'Feb', score: Math.round(best.totalScore * 0.85) },
    { month: 'Mar', score: Math.round(best.totalScore * 0.76) },
  ];

  return {
    primaryCrop: primary.name,
    secondaryCrop: second.crop.name,
    confidence: Math.min(98, Math.max(76, Math.round(best.totalScore))),
    variety: primary.variety,
    expectedYield: primary.yieldRange,
    estimatedRevenue: primary.revenueRange,
    waterRequirement: primary.waterReq,
    soilSuitability: Math.round(best.soilScore),
    climateSuitability: Math.round(best.climateScore),
    npkComparison,
    climateComparison,
    monthlySuitability,
    historicalPriceTrend: primary.historicalPrices,
    advisoryNote: primary.advisory,
  };
}
