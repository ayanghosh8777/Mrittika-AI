export type AppScreen =
  | 'landing'
  | 'signup'
  | 'login'
  | 'role-selection'
  | 'farmer-signup'
  | 'dealer-signup'
  | 'farmer-dashboard'
  | 'dealer-dashboard';

export type UserRole = 'farmer' | 'dealer';

export type FarmerTab = 'home' | 'predict' | 'chat' | 'disease' | 'schemes' | 'profile';
export type DealerTab = 'overview' | 'prices' | 'analytics' | 'payments' | 'inventory' | 'profile';

export type LanguageCode = 'en' | 'hi' | 'bn' | 'mr' | 'pa';

export interface GovtScheme {
  id: string;
  title: string;
  hindiTitle: string;
  category: 'Welfare Yojna' | 'Bank Loan & Credit' | 'Subsidy & Machinery' | 'Crop Insurance';
  benefit: string;
  eligibility: string;
  subsidyAmount: string;
  documentsRequired: string[];
  officialPortalUrl: string;
  helpline: string;
  status: 'Applications Open' | 'Direct DBT Active' | 'Annual Enrollment';
}

export interface CertifiedShop {
  id: string;
  name: string;
  owner: string;
  type: 'Govt Certified Seeds' | 'IFFCO Fertilizer Depo' | 'Licensed Pesticide Store' | 'Custom Hiring Center (Machinery)';
  affiliation: string;
  district: string;
  distanceKm: number;
  address: string;
  phone: string;
  rating: number;
  inStockBadges: string[];
  isGovtAffiliated: boolean;
}

export interface CropPredictionInput {
  nitrogen: number; // N in kg/ha
  phosphorus: number; // P in kg/ha
  potassium: number; // K in kg/ha
  ph: number; // 0 to 14
  temperature: number; // °C
  humidity: number; // %
  rainfall: number; // mm
}

export interface CropPredictionAnalysis {
  primaryCrop: string;
  secondaryCrop: string;
  confidence: number;
  variety: string;
  expectedYield: string;
  estimatedRevenue: string;
  waterRequirement: string;
  soilSuitability: number;
  climateSuitability: number;
  npkComparison: {
    nutrient: 'Nitrogen (N)' | 'Phosphorus (P)' | 'Potassium (K)';
    input: number;
    idealMin: number;
    idealMax: number;
    status: 'Optimal' | 'Deficient' | 'Excess';
  }[];
  climateComparison: {
    parameter: 'Temperature' | 'Humidity' | 'Rainfall' | 'Soil pH';
    input: number;
    idealMin: number;
    idealMax: number;
    unit: string;
    status: 'Ideal' | 'Acceptable' | 'Stress';
  }[];
  monthlySuitability: { month: string; score: number }[];
  historicalPriceTrend: { year: string; price: number }[];
  advisoryNote: string;
}

export interface FarmerProfile {
  name: string;
  phone: string;
  village: string;
  district: string;
  state: string;
  landSizeAcres: number;
  primaryCrops: string[];
  soilType: string;
  language: LanguageCode;
}

export interface DealerProfile {
  name: string;
  phone: string;
  businessName: string;
  businessType: string;
  districtsCovered: string[];
  state: string;
  gstin?: string;
  verified: boolean;
}

export interface WeatherBriefing {
  temperature: number;
  condition: string;
  humidity: number;
  windKmh: number;
  rainForecast: string;
  sprayCondition: 'Optimal' | 'Caution' | 'Unfavorable';
  forecastDays: { day: string; temp: string; rainChance: number; icon: string }[];
}

export interface MandiPriceItem {
  id: string;
  commodity: string;
  variety: string;
  mandi: string;
  district: string;
  state: string;
  minPrice: number;
  maxPrice: number;
  modalPrice: number;
  unit: string;
  trend: 'up' | 'down' | 'stable';
  changePercent: number;
  sparkline: number[];
  updatedAt: string;
}

export interface DiseaseResult {
  diseaseName: string;
  scientificName: string;
  confidence: 'High Confidence' | 'Moderate Confidence' | 'Needs Expert Confirmation';
  confidenceScore: number;
  severity: 'Mild' | 'Moderate' | 'Severe';
  symptoms: string[];
  organicRemedy: string;
  chemicalRemedy: string;
  preventionAdvice: string;
  urgency: 'Action within 24h' | 'Monitor in 3 days' | 'Immediate Quarantine';
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'mitra';
  text: string;
  timestamp: string;
  audioAvailable?: boolean;
  topicTag?: string;
}

export interface InventoryItem {
  id: string;
  name: string;
  category: 'Fertilizer' | 'Seed' | 'Pesticide' | 'Equipment' | 'Irrigation';
  currentStock: number;
  unit: string;
  reorderLevel: number;
  pricePerUnit: number;
  status: 'In Stock' | 'Low Stock' | 'Critical';
}

export interface FarmerOrder {
  id: string;
  farmerName: string;
  village: string;
  productName: string;
  quantity: string;
  totalValue: number;
  date: string;
  status: 'New Request' | 'Quote Sent' | 'Fulfilled' | 'Cancelled';
}

export interface PaymentTransaction {
  id: string;
  entityName: string;
  type: 'Incoming' | 'Outgoing';
  amount: number;
  method: 'UPI' | 'NEFT/RTGS' | 'Cash / Mandi Receipt';
  date: string;
  status: 'Completed' | 'Pending' | 'Overdue';
  invoiceRef: string;
}
