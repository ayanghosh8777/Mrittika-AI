import React from 'react';
import {
  Sparkles,
  Sprout,
  Store,
  ScanEye,
  TrendingUp,
  X,
  ArrowRight,
  ShieldCheck,
  Mic,
  BrainCircuit
} from 'lucide-react';

interface MrittikaAIPopupProps {
  isOpen: boolean;
  onClose: () => void;
  onGetStarted: () => void;
}

export const MrittikaAIPopup: React.FC<MrittikaAIPopupProps> = ({
  isOpen,
  onClose,
  onGetStarted,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-[#FAF8F3] rounded-3xl max-w-lg w-full border border-[#DCD5C4] shadow-2xl overflow-hidden relative">
        
        {/* Top Header Banner with warm earthy styling */}
        <div className="bg-gradient-to-br from-[#234415] via-[#1E3A12] to-[#14290C] text-white p-6 relative overflow-hidden">
          {/* Subtle ambient lighting element */}
          <div className="absolute top-0 right-0 w-44 h-44 bg-[#568739]/20 rounded-full blur-2xl pointer-events-none" />

          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-[#E8EFE2] transition-colors"
            aria-label="Close Pop-up"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 rounded-2xl bg-[#E8EFE2] text-[#234415] flex items-center justify-center font-bold shadow-md shrink-0">
              <Sparkles className="w-6 h-6 text-[#234415]" />
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-[#F5CA5B] text-[#234415] text-[10px] font-extrabold rounded-md uppercase tracking-wider mb-1">
                <span>AI Agriculture Platform</span>
              </div>
              <h2 className="text-xl font-bold font-display leading-tight">
                Welcome to Mrittika AI
              </h2>
              <span className="text-xs text-[#D8E6CC]">मृत्तिका · Where farming meets intelligence</span>
            </div>
          </div>

          <p className="text-xs text-[#E1EED7] leading-relaxed mt-2">
            An intelligent smart farming companion connecting Indian growers in the field with agri-dealers at the mandi.
          </p>
        </div>

        {/* Core Capabilities Preview */}
        <div className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-2.5">
            
            <div className="p-3 bg-white rounded-xl border border-[#DFD8C7] shadow-2xs space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-bold text-[#234415]">
                <Mic className="w-3.5 h-3.5 text-[#234415]" />
                <span>Krishi Mitra AI</span>
              </div>
              <p className="text-[11px] text-[#63755A] leading-tight">
                Voice consultation in 5 Indian languages with daily spray briefs.
              </p>
            </div>

            <div className="p-3 bg-white rounded-xl border border-[#DFD8C7] shadow-2xs space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-bold text-[#895719]">
                <ScanEye className="w-3.5 h-3.5 text-[#895719]" />
                <span>Plant Doctor</span>
              </div>
              <p className="text-[11px] text-[#63755A] leading-tight">
                5-second leaf photo scan for disease diagnosis & remedies.
              </p>
            </div>

            <div className="p-3 bg-white rounded-xl border border-[#DFD8C7] shadow-2xs space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-bold text-[#234415]">
                <BrainCircuit className="w-3.5 h-3.5 text-[#234415]" />
                <span>Crop Predictor</span>
              </div>
              <p className="text-[11px] text-[#63755A] leading-tight">
                Scientific N, P, K, pH & climate telemetry yield analysis.
              </p>
            </div>

            <div className="p-3 bg-white rounded-xl border border-[#DFD8C7] shadow-2xs space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-bold text-[#895719]">
                <TrendingUp className="w-3.5 h-3.5 text-[#895719]" />
                <span>Mandi Prices</span>
              </div>
              <p className="text-[11px] text-[#63755A] leading-tight">
                Live Agmarknet prices, 7-day sparklines & dealer orders.
              </p>
            </div>

          </div>

          <div className="p-3 bg-[#EAF2E4] rounded-xl border border-[#CCE0BE] text-xs text-[#203D14] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#234415] shrink-0" />
              <span>Choose your role (Farmer or Dealer) at login/signup to enter.</span>
            </div>
          </div>

          {/* CTA Actions */}
          <div className="pt-2 flex flex-col sm:flex-row items-center gap-2.5">
            <button
              onClick={() => {
                onClose();
                onGetStarted();
              }}
              className="w-full py-3 bg-[#234415] hover:bg-[#1A3410] active:scale-[0.99] text-white text-xs font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 min-h-[46px]"
            >
              <span>Continue to Login / Sign Up</span>
              <ArrowRight className="w-4 h-4 text-[#C9E4B3]" />
            </button>

            <button
              onClick={onClose}
              className="w-full sm:w-auto px-4 py-3 bg-[#EFECE1] hover:bg-[#E5E1D2] text-[#47573E] text-xs font-semibold rounded-xl border border-[#DFD9C8] transition-colors whitespace-nowrap min-h-[46px]"
            >
              Close
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
