import React from 'react';
import { AppScreen, UserRole, LanguageCode } from '../../types';
import { LANGUAGES } from '../../data/mockData';
import { Sprout, Store, ArrowLeftRight, Globe, Check, Sparkles, LogOut } from 'lucide-react';

interface NavbarProps {
  currentScreen: AppScreen;
  onNavigate: (screen: AppScreen) => void;
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  selectedLanguage: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
  onOpenAiPopup: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentScreen,
  onNavigate,
  currentRole,
  onRoleChange,
  selectedLanguage,
  onLanguageChange,
  onOpenAiPopup,
}) => {
  const [langMenuOpen, setLangMenuOpen] = React.useState(false);

  const isAuthenticated =
    currentScreen === 'farmer-dashboard' || currentScreen === 'dealer-dashboard';

  return (
    <header className="sticky top-0 z-40 bg-[#FBF9F4]/90 backdrop-blur-md border-b border-[#E7E2D6] px-4 sm:px-6 lg:px-8 py-3 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        
        {/* Zone 1: Single text element wordmark */}
        <button
          onClick={() => {
            if (!isAuthenticated) onNavigate('signup');
          }}
          className="flex items-center gap-2.5 text-left group focus-visible:outline-none"
        >
          <div className="w-9 h-9 rounded-xl bg-[#234415] text-[#F3E7C4] flex items-center justify-center shadow-sm group-hover:bg-[#1A3410] transition-colors">
            <Sprout className="w-5 h-5 text-[#F3E7C4]" />
          </div>
          <div>
            <span className="text-xl font-bold tracking-tight text-[#1E3612] font-display block leading-none">
              Mrittika
            </span>
            <span className="text-[11px] text-[#63735A] font-medium tracking-wide">
              मृत्तिका · Smart Farming
            </span>
          </div>
        </button>

        {/* Zone 2: Navigation Links / Screen Switcher pills */}
        <nav className="flex items-center gap-2">
          {!isAuthenticated ? (
            /* IN THE FIRST INSTANCE (UNAUTHENTICATED): ONLY SIGN UP & LOG IN */
            <div className="flex items-center p-1 bg-[#EFECE1] rounded-xl border border-[#DFD9C8]">
              <button
                onClick={() => onNavigate('signup')}
                className={`px-4 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                  currentScreen === 'signup'
                    ? 'bg-white text-[#1E3612] shadow-sm font-bold'
                    : 'text-[#53614B] hover:text-[#1E3612]'
                }`}
              >
                Sign Up
              </button>
              <button
                onClick={() => onNavigate('login')}
                className={`px-4 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                  currentScreen === 'login'
                    ? 'bg-white text-[#1E3612] shadow-sm font-bold'
                    : 'text-[#53614B] hover:text-[#1E3612]'
                }`}
              >
                Log In
              </button>
            </div>
          ) : (
            /* INSIDE DASHBOARD (AUTHENTICATED): ACTIVE CONSOLE INDICATOR */
            <div className="hidden sm:flex items-center gap-2">
              <span className="text-xs font-bold text-[#234415] bg-[#E8EFE2] px-3 py-1.5 rounded-xl border border-[#D0DEC4] flex items-center gap-1.5">
                {currentRole === 'farmer' ? (
                  <>
                    <Sprout className="w-3.5 h-3.5" />
                    <span>Farmer Workspace Active</span>
                  </>
                ) : (
                  <>
                    <Store className="w-3.5 h-3.5" />
                    <span>Dealer Console Active</span>
                  </>
                )}
              </span>
            </div>
          )}
        </nav>

        {/* Zone 3: Actions & Language Selector */}
        <div className="flex items-center gap-2 sm:gap-3">
          
          {/* Mrittika AI Pop-up Trigger Button */}
          <button
            onClick={onOpenAiPopup}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#234415] bg-[#E8EFE2] hover:bg-[#DCE7D3] rounded-lg border border-[#CCE0BF] transition-colors min-h-[38px]"
            title="Learn about Mrittika AI"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#234415]" />
            <span className="hidden sm:inline">Mrittika AI</span>
          </button>

          {/* Language selector dropdown */}
          <div className="relative">
            <button
              onClick={() => setLangMenuOpen(!langMenuOpen)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-[#384630] bg-[#EFECE1] hover:bg-[#E5E1D2] rounded-lg border border-[#DFD9C8] transition-colors min-h-[38px]"
              aria-label="Select Language"
            >
              <Globe className="w-3.5 h-3.5 text-[#5B6D51]" />
              <span className="font-semibold uppercase tracking-wider">
                {selectedLanguage}
              </span>
            </button>

            {langMenuOpen && (
              <div className="absolute right-0 mt-2 w-44 bg-white rounded-xl shadow-lg border border-[#E0DAC9] py-1 z-50">
                <div className="px-3 py-1.5 text-[11px] font-semibold text-[#7E8D77] uppercase tracking-wider border-b border-[#F0EBE0]">
                  Choose Language
                </div>
                {LANGUAGES.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => {
                      onLanguageChange(lang.code);
                      setLangMenuOpen(false);
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2 text-xs text-left hover:bg-[#F7F5EE] transition-colors ${
                      selectedLanguage === lang.code
                        ? 'font-bold text-[#234415] bg-[#F1EFE6]'
                        : 'text-[#3E4D36]'
                    }`}
                  >
                    <span>{lang.nativeName} ({lang.label})</span>
                    {selectedLanguage === lang.code && (
                      <Check className="w-3.5 h-3.5 text-[#234415]" />
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Role Switching & Logout if Authenticated */}
          {isAuthenticated ? (
            <div className="flex items-center gap-1.5">
              {currentRole === 'farmer' ? (
                <button
                  onClick={() => {
                    onRoleChange('dealer');
                    onNavigate('dealer-dashboard');
                  }}
                  className="px-3 py-1.5 text-xs font-semibold text-[#895719] bg-[#FAF3E8] hover:bg-[#F3E5CD] border border-[#ECD9BA] rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 min-h-[38px]"
                >
                  <ArrowLeftRight className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Switch to</span> Dealer Console
                </button>
              ) : (
                <button
                  onClick={() => {
                    onRoleChange('farmer');
                    onNavigate('farmer-dashboard');
                  }}
                  className="px-3 py-1.5 text-xs font-semibold text-[#234415] bg-[#EBF2E5] hover:bg-[#DFEAD6] border border-[#CEE0C3] rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 min-h-[38px]"
                >
                  <ArrowLeftRight className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Switch to</span> Farmer App
                </button>
              )}

              {/* Log Out Button */}
              <button
                onClick={() => onNavigate('login')}
                className="p-2 text-[#5B6D51] hover:text-[#9E2A12] hover:bg-[#FBEBE8] rounded-lg transition-colors min-h-[38px] min-w-[38px] flex items-center justify-center border border-[#DFD9C8]"
                title="Log Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            /* If on unauthenticated page: direct call to action */
            currentScreen === 'login' ? (
              <button
                onClick={() => onNavigate('signup')}
                className="px-3.5 py-1.5 text-xs font-bold text-white bg-[#234415] hover:bg-[#1A3410] rounded-lg shadow-sm transition-all whitespace-nowrap min-h-[38px]"
              >
                New User? Sign Up
              </button>
            ) : (
              <button
                onClick={() => onNavigate('login')}
                className="px-3.5 py-1.5 text-xs font-bold text-[#1E3612] bg-[#EFECE1] hover:bg-[#E5E1D2] rounded-lg border border-[#DFD9C8] transition-colors whitespace-nowrap min-h-[38px]"
              >
                Old User? Log In
              </button>
            )
          )}

        </div>
      </div>
    </header>
  );
};
