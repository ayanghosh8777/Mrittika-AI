import React, { useState } from 'react';
import { AppScreen, DealerProfile } from '../../types';
import {
  Store,
  ArrowRight,
  ArrowLeft,
  Check,
  Phone,
  Building2,
  FileCheck,
  ShieldCheck,
  Send
} from 'lucide-react';

interface DealerSignupScreenProps {
  onNavigate: (screen: AppScreen) => void;
  onComplete: (profile: DealerProfile) => void;
}

export const DealerSignupScreen: React.FC<DealerSignupScreenProps> = ({
  onNavigate,
  onComplete,
}) => {
  const [step, setStep] = useState<1 | 2 | 3>(1);

  // Form State
  const [name, setName] = useState('Satish Kumar');
  const [phone, setPhone] = useState('98120 77341');
  const [businessName, setBusinessName] = useState('Kisan Seva Kendra & Agri Inputs');
  const [businessType, setBusinessType] = useState('Seeds, Fertilizers & Crop Protection');
  const [district, setDistrict] = useState('Karnal');
  const [state, setState] = useState('Haryana');
  const [gstin, setGstin] = useState('06AAECK9821L1Z9');
  const [otp, setOtp] = useState('5839');

  const BUSINESS_TYPES = [
    'Seeds, Fertilizers & Crop Protection',
    'Grain & Produce Mandi Commission Trader',
    'Farm Machinery & Drip Irrigation Equipment',
    'FPO (Farmer Producer Organization) Hub',
    'Soil & Nutrient Diagnostic Dealer',
  ];

  const handleFinish = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const profile: DealerProfile = {
      name,
      phone,
      businessName,
      businessType,
      districtsCovered: [district, 'Kurukshetra', 'Panipat'],
      state,
      gstin,
      verified: true,
    };
    onComplete(profile);
  };

  return (
    <div className="min-h-[calc(100vh-65px)] bg-[#FBF9F4] py-8 sm:py-12 px-4 sm:px-6 flex flex-col justify-center">
      <div className="max-w-xl mx-auto w-full">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => {
              if (step > 1) {
                setStep((step - 1) as any);
              } else {
                onNavigate('role-selection');
              }
            }}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#665744] hover:text-[#895719] transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>{step > 1 ? 'Previous Step' : 'Back to Role Selection'}</span>
          </button>

          <span className="text-xs font-bold text-[#895719] bg-[#FAF0E1] px-2.5 py-1 rounded-full border border-[#EBDCC5]">
            Step {step} of 3
          </span>
        </div>

        {/* Step Progress Bar */}
        <div className="w-full bg-[#E5E0D2] h-1.5 rounded-full overflow-hidden mb-6">
          <div
            className="bg-[#895719] h-full transition-all duration-300 rounded-full"
            style={{ width: `${(step / 3) * 100}%` }}
          />
        </div>

        {/* Form Container */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#E4DECFA] shadow-sm">
          {/* STEP 1: Owner Name & Phone */}
          {step === 1 && (
            <div className="space-y-5">
              <div>
                <div className="w-10 h-10 rounded-xl bg-[#FAF0E1] text-[#895719] flex items-center justify-center mb-3">
                  <Store className="w-5 h-5" />
                </div>
                <h2 className="text-xl sm:text-2xl font-bold text-[#2A1D0B] font-display">
                  Welcome to Mrittika Vyapaar
                </h2>
                <p className="text-xs sm:text-sm text-[#6C5C47] mt-1">
                  Connect directly with regional growers, track APMC prices, and streamline dealer billing.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#4E3E28] mb-1.5">
                  Business Owner / Authorized Signatory Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Satish Kumar"
                  className="w-full px-4 py-2.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-sm font-semibold text-[#2A1D0B] focus:ring-2 focus:ring-[#895719] focus:outline-none min-h-[44px]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#4E3E28] mb-1.5">
                  Primary Mobile Number (OTP Verified)
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#867560] font-semibold text-sm">
                    +91
                  </div>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="Enter 10-digit mobile number"
                    className="w-full pl-12 pr-4 py-3 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-sm font-semibold text-[#2A1D0B] focus:ring-2 focus:ring-[#895719] focus:outline-none min-h-[44px]"
                  />
                  <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-[#867560]">
                    <Phone className="w-4 h-4" />
                  </div>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="w-full py-3.5 bg-[#895719] hover:bg-[#6D420F] text-white text-sm font-semibold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 min-h-[48px]"
                >
                  <span>Continue to Business Profile</span>
                  <ArrowRight className="w-4 h-4 text-[#F3E2C4]" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: Business Info & District */}
          {step === 2 && (
            <div className="space-y-4">
              <div>
                <h2 className="text-xl sm:text-2xl font-bold text-[#2A1D0B] font-display">
                  Tell us about your dealership
                </h2>
                <p className="text-xs sm:text-sm text-[#6C5C47] mt-1">
                  Farmers in your district will be able to discover your inventory and request quotes.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#4E3E28] mb-1.5">
                  Dealership / Firm Name
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={businessName}
                    onChange={(e) => setBusinessName(e.target.value)}
                    placeholder="e.g. Kisan Seva Kendra & Agri Supplies"
                    className="w-full px-4 py-2.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-sm font-semibold text-[#2A1D0B] focus:ring-2 focus:ring-[#895719] focus:outline-none min-h-[44px]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#4E3E28] mb-1.5">
                  Primary Business Category
                </label>
                <select
                  value={businessType}
                  onChange={(e) => setBusinessType(e.target.value)}
                  className="w-full px-4 py-2.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-sm font-semibold text-[#2A1D0B] focus:ring-2 focus:ring-[#895719] focus:outline-none min-h-[44px]"
                >
                  {BUSINESS_TYPES.map((bt) => (
                    <option key={bt} value={bt}>
                      {bt}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#4E3E28] mb-1.5">
                    District of Operation
                  </label>
                  <input
                    type="text"
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                    placeholder="e.g. Karnal"
                    className="w-full px-4 py-2.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-sm font-semibold text-[#2A1D0B] focus:ring-2 focus:ring-[#895719] focus:outline-none min-h-[44px]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#4E3E28] mb-1.5">
                    State
                  </label>
                  <select
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    className="w-full px-4 py-2.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-sm font-semibold text-[#2A1D0B] focus:ring-2 focus:ring-[#895719] focus:outline-none min-h-[44px]"
                  >
                    <option value="Haryana">Haryana</option>
                    <option value="Punjab">Punjab</option>
                    <option value="Madhya Pradesh">Madhya Pradesh</option>
                    <option value="Rajasthan">Rajasthan</option>
                    <option value="Maharashtra">Maharashtra</option>
                    <option value="West Bengal">West Bengal</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#4E3E28] mb-1.5">
                  GSTIN or Krishi License No. (Optional)
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={gstin}
                    onChange={(e) => setGstin(e.target.value)}
                    placeholder="06AAECK9821L1Z9"
                    className="w-full px-4 py-2.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-sm font-mono font-semibold text-[#2A1D0B] uppercase focus:ring-2 focus:ring-[#895719] focus:outline-none min-h-[44px]"
                  />
                </div>
                <p className="text-[11px] text-[#867560] mt-1">
                  Enables the verified green badge on farmer quotations and mandi invoices.
                </p>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="w-full py-3.5 bg-[#895719] hover:bg-[#6D420F] text-white text-sm font-semibold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 min-h-[48px]"
                >
                  <span>Proceed to Verification</span>
                  <ArrowRight className="w-4 h-4 text-[#F3E2C4]" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: OTP Verification */}
          {step === 3 && (
            <div className="space-y-5">
              <div>
                <div className="w-10 h-10 rounded-xl bg-[#FAF0E1] text-[#895719] flex items-center justify-center mb-3">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <h2 className="text-xl sm:text-2xl font-bold text-[#2A1D0B] font-display">
                  Verify Business Contact
                </h2>
                <p className="text-xs sm:text-sm text-[#6C5C47] mt-1">
                  We sent a 4-digit code to <strong>+91 {phone}</strong>
                </p>
              </div>

              {/* Simulated SMS Box */}
              <div className="p-3 bg-[#FAF0E1] rounded-xl border border-[#ECD9BE] flex items-center justify-between text-xs text-[#523A1B]">
                <div className="flex items-center gap-2">
                  <Send className="w-4 h-4 text-[#895719]" />
                  <span>SMS Code: <strong>5839</strong> (Auto-detected)</span>
                </div>
                <span className="font-mono text-[11px] bg-white px-2 py-0.5 rounded text-[#895719] font-bold">
                  Demo Active
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#4E3E28] mb-2 text-center">
                  Enter 4-Digit Verification Code
                </label>
                <div className="flex justify-center gap-3">
                  {['5', '8', '3', '9'].map((digit, idx) => (
                    <div
                      key={idx}
                      className="w-12 h-14 bg-[#FAF8F3] border-2 border-[#895719] rounded-xl flex items-center justify-center text-xl font-bold text-[#2A1D0B] font-mono shadow-xs"
                    >
                      {otp[idx] || digit}
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-3">
                <button
                  type="button"
                  onClick={() => handleFinish()}
                  className="w-full py-3.5 bg-[#895719] hover:bg-[#6D420F] active:scale-[0.98] text-white text-sm font-semibold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 min-h-[48px]"
                >
                  <Store className="w-4 h-4 text-[#F3E2C4]" />
                  <span>Verify & Open Dealer Console</span>
                </button>
              </div>
            </div>
          )}

          {/* Quick Demo Bypass */}
          <div className="mt-6 pt-4 border-t border-[#EDE8DC] text-center">
            <button
              type="button"
              onClick={() => handleFinish()}
              className="text-xs font-semibold text-[#867560] hover:text-[#895719] transition-colors"
            >
              Skip verification & log in as Kisan Seva Kendra (Karnal Mandi) →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
