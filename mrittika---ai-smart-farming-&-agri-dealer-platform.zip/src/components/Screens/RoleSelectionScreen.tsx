import React from 'react';
import { AppScreen, UserRole } from '../../types';
import { Sprout, Store, ArrowRight, ArrowLeft, Check, Sparkles } from 'lucide-react';

interface RoleSelectionScreenProps {
  onNavigate: (screen: AppScreen) => void;
  onSelectRole: (role: UserRole) => void;
}

export const RoleSelectionScreen: React.FC<RoleSelectionScreenProps> = ({
  onNavigate,
  onSelectRole,
}) => {
  return (
    <div className="min-h-[calc(100vh-65px)] bg-[#FBF9F4] py-8 sm:py-16 px-4 sm:px-6 lg:px-8 flex flex-col justify-center">
      <div className="max-w-5xl mx-auto w-full">
        {/* Navigation Breadcrumb / Back button */}
        <div className="mb-6">
          <button
            onClick={() => onNavigate('landing')}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#5B6D51] hover:text-[#234415] transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Home</span>
          </button>
        </div>

        {/* Header */}
        <div className="text-center max-w-xl mx-auto mb-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#EAE6D9] text-[#47573E] rounded-full text-xs font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5 text-[#234415]" />
            <span>Choose Your Journey</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-[#16270E] font-display">
            Welcome to Mrittika
          </h1>
          <p className="mt-2 text-sm text-[#4F6047]">
            Select your role to unlock tailored tools for your farm or your business.
          </p>
        </div>

        {/* The Two Distinct Large Cards Side by Side */}
        <div className="grid md:grid-cols-2 gap-6 lg:gap-8 items-stretch">
          
          {/* 1. I'M A FARMER CARD */}
          <div className="bg-white rounded-3xl border-2 border-[#D8E6CD] hover:border-[#234415] shadow-sm hover:shadow-lg transition-all duration-200 overflow-hidden flex flex-col justify-between group">
            <div>
              {/* Authentic Photo Aspect */}
              <div className="relative h-48 sm:h-56 bg-[#E8EFE2] overflow-hidden">
                <img
                  src="/src/assets/images/farmer_role_portrait_1791000521735.jpg"
                  alt="Indian farmer in agricultural field"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-3 left-3 bg-[#234415] text-[#F3E7C4] text-xs font-bold px-3 py-1 rounded-full shadow-sm flex items-center gap-1.5">
                  <Sprout className="w-3.5 h-3.5" />
                  <span>Kisan Companion</span>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 sm:p-8 space-y-4">
                <div>
                  <h2 className="text-2xl font-bold text-[#182C10] font-display">
                    I'm a Farmer
                  </h2>
                  <p className="text-sm font-medium text-[#2D5818] mt-1 leading-snug">
                    Get crop predictions, disease detection, and expert AI advice.
                  </p>
                </div>

                <div className="space-y-2.5 pt-2">
                  <div className="flex items-center gap-2 text-xs text-[#45563D]">
                    <div className="w-4 h-4 rounded-full bg-[#E2EED9] text-[#234415] flex items-center justify-center shrink-0">
                      <Check className="w-2.5 h-2.5" />
                    </div>
                    <span>Daily briefing: weather, spray conditions & urgent tasks</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-[#45563D]">
                    <div className="w-4 h-4 rounded-full bg-[#E2EED9] text-[#234415] flex items-center justify-center shrink-0">
                      <Check className="w-2.5 h-2.5" />
                    </div>
                    <span>Krishi Mitra AI voice advisor in 5 Indian languages</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-[#45563D]">
                    <div className="w-4 h-4 rounded-full bg-[#E2EED9] text-[#234415] flex items-center justify-center shrink-0">
                      <Check className="w-2.5 h-2.5" />
                    </div>
                    <span>Instant leaf disease diagnosis with organic remedy steps</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-[#45563D]">
                    <div className="w-4 h-4 rounded-full bg-[#E2EED9] text-[#234415] flex items-center justify-center shrink-0">
                      <Check className="w-2.5 h-2.5" />
                    </div>
                    <span>Live mandi selling prices for your district</span>
                  </div>
                </div>
              </div>
            </div>

            {/* CTA Container */}
            <div className="p-6 sm:p-8 pt-0">
              <button
                onClick={() => {
                  onSelectRole('farmer');
                  onNavigate('farmer-signup');
                }}
                className="w-full py-3.5 bg-[#234415] hover:bg-[#1A3410] active:scale-[0.98] text-white text-sm font-semibold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 min-h-[48px]"
              >
                <span>Continue as a Farmer</span>
                <ArrowRight className="w-4 h-4 text-[#C9E4B3]" />
              </button>
            </div>
          </div>

          {/* 2. I'M A DEALER CARD */}
          <div className="bg-white rounded-3xl border-2 border-[#EBDCC5] hover:border-[#895719] shadow-sm hover:shadow-lg transition-all duration-200 overflow-hidden flex flex-col justify-between group">
            <div>
              {/* Authentic Photo Aspect */}
              <div className="relative h-48 sm:h-56 bg-[#FAF0E1] overflow-hidden">
                <img
                  src="/src/assets/images/dealer_role_portrait_1791000534221.jpg"
                  alt="Indian agri-inputs store owner"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-3 left-3 bg-[#895719] text-[#F9F1E2] text-xs font-bold px-3 py-1 rounded-full shadow-sm flex items-center gap-1.5">
                  <Store className="w-3.5 h-3.5" />
                  <span>Vyapaar Console</span>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 sm:p-8 space-y-4">
                <div>
                  <h2 className="text-2xl font-bold text-[#291B09] font-display">
                    I'm a Dealer
                  </h2>
                  <p className="text-sm font-medium text-[#895719] mt-1 leading-snug">
                    Track market prices, manage inventory, and grow your business.
                  </p>
                </div>

                <div className="space-y-2.5 pt-2">
                  <div className="flex items-center gap-2 text-xs text-[#524330]">
                    <div className="w-4 h-4 rounded-full bg-[#F6EADB] text-[#895719] flex items-center justify-center shrink-0">
                      <Check className="w-2.5 h-2.5" />
                    </div>
                    <span>Multi-mandi price tracker with 7-day price sparklines</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-[#524330]">
                    <div className="w-4 h-4 rounded-full bg-[#F6EADB] text-[#895719] flex items-center justify-center shrink-0">
                      <Check className="w-2.5 h-2.5" />
                    </div>
                    <span>Business analytics: product sales & district demand ranking</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-[#524330]">
                    <div className="w-4 h-4 rounded-full bg-[#F6EADB] text-[#895719] flex items-center justify-center shrink-0">
                      <Check className="w-2.5 h-2.5" />
                    </div>
                    <span>Inventory management with low-stock alerts</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-[#524330]">
                    <div className="w-4 h-4 rounded-full bg-[#F6EADB] text-[#895719] flex items-center justify-center shrink-0">
                      <Check className="w-2.5 h-2.5" />
                    </div>
                    <span>Farmer order requests & seamless UPI/bank ledger</span>
                  </div>
                </div>
              </div>
            </div>

            {/* CTA Container */}
            <div className="p-6 sm:p-8 pt-0">
              <button
                onClick={() => {
                  onSelectRole('dealer');
                  onNavigate('dealer-signup');
                }}
                className="w-full py-3.5 bg-[#895719] hover:bg-[#6C4210] active:scale-[0.98] text-white text-sm font-semibold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 min-h-[48px]"
              >
                <span>Continue as a Dealer</span>
                <ArrowRight className="w-4 h-4 text-[#F3E2C4]" />
              </button>
            </div>
          </div>

        </div>

        {/* Direct Demo Access Footnote */}
        <div className="mt-8 text-center text-xs text-[#6F7F68]">
          <span>Need to quickly evaluate? You can also jump straight into: </span>
          <button
            onClick={() => {
              onSelectRole('farmer');
              onNavigate('farmer-dashboard');
            }}
            className="text-[#234415] font-bold hover:underline mx-1"
          >
            Farmer Dashboard
          </button>
          <span>or</span>
          <button
            onClick={() => {
              onSelectRole('dealer');
              onNavigate('dealer-dashboard');
            }}
            className="text-[#895719] font-bold hover:underline mx-1"
          >
            Dealer Console
          </button>
        </div>
      </div>
    </div>
  );
};
