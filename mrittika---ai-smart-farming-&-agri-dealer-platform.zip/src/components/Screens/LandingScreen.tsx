import React from 'react';
import { AppScreen, UserRole, LanguageCode } from '../../types';
import { MOCK_MANDI_PRICES, UI_TRANSLATIONS } from '../../data/mockData';
import {
  Sprout,
  Store,
  Sparkles,
  ShieldCheck,
  TrendingUp,
  CloudSun,
  Mic,
  ScanEye,
  CheckCircle2,
  ArrowRight,
  ChevronRight
} from 'lucide-react';

interface LandingScreenProps {
  onNavigate: (screen: AppScreen) => void;
  onSelectRole: (role: UserRole) => void;
  selectedLanguage: LanguageCode;
}

export const LandingScreen: React.FC<LandingScreenProps> = ({
  onNavigate,
  onSelectRole,
  selectedLanguage,
}) => {
  const t = UI_TRANSLATIONS[selectedLanguage] || UI_TRANSLATIONS.en;

  return (
    <div className="min-h-screen bg-[#FBF9F4] text-[#1E3017]">
      {/* 1. Hero Section with Warm Photography */}
      <section className="relative overflow-hidden pt-8 pb-16 sm:pb-24 lg:pt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            
            {/* Left Column: Human Messaging */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#E8EFE2] text-[#224314] rounded-full text-xs font-semibold border border-[#D0DEC4]">
                <Sparkles className="w-3.5 h-3.5 text-[#224314]" />
                <span>Next-Gen Smart Agritech for India</span>
              </div>

              <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-[#16270E] font-display leading-[1.12]">
                Where farming meets <span className="text-[#2D5818] underline decoration-[#DFBD6A] decoration-wavy decoration-2">intelligence</span>.
              </h1>

              <p className="text-base sm:text-lg text-[#47573E] leading-relaxed max-w-xl">
                Mrittika connects Indian farmers in the field with local agri-dealers at the mandi. 
                Get AI-driven crop advice, instant leaf disease diagnosis in your voice, and verified daily market prices.
              </p>

              {/* Primary Call to Action */}
              <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                <button
                  onClick={() => onNavigate('signup')}
                  className="px-6 py-3.5 bg-[#234415] hover:bg-[#1A3410] active:scale-[0.99] text-white text-sm font-semibold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 group min-h-[48px]"
                >
                  <span>Get Started · Create Account</span>
                  <ArrowRight className="w-4 h-4 text-[#E3F1D1] group-hover:translate-x-1 transition-transform" />
                </button>

                <button
                  onClick={() => onNavigate('login')}
                  className="px-5 py-3.5 bg-[#EAE6D9] hover:bg-[#DFD9C7] text-[#28381F] text-sm font-semibold rounded-xl border border-[#D5CDBC] transition-colors flex items-center justify-center gap-2 min-h-[48px]"
                >
                  <span>Already Registered? Log In</span>
                </button>
              </div>

              {/* Trust Badges */}
              <div className="pt-4 flex flex-wrap items-center gap-4 text-xs text-[#5C6E52]">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-[#2D5818]" />
                  <span>5 Indian Languages</span>
                </div>
                <span className="text-[#BFB9A8]">·</span>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-[#2D5818]" />
                  <span>Live APMC Mandi Rates</span>
                </div>
                <span className="text-[#BFB9A8]">·</span>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-[#2D5818]" />
                  <span>Works in Low-Bandwidth</span>
                </div>
              </div>
            </div>

            {/* Right Column: Hero Visual Artwork */}
            <div className="lg:col-span-5 relative">
              <div className="relative rounded-2xl overflow-hidden shadow-xl border-4 border-[#F2ECE0] bg-[#E8E2D4]">
                <img
                  src="/src/assets/images/hero_farming_field_1791000507688.jpg"
                  alt="Fertile Indian agricultural fields with healthy crops at sunrise"
                  className="w-full h-[320px] sm:h-[400px] object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent flex flex-col justify-end p-5 text-white">
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-[#234415]/90 rounded-md text-[11px] font-semibold text-[#F2F7EC] w-fit mb-2">
                    <CloudSun className="w-3.5 h-3.5 text-[#F5CA5B]" />
                    <span>Live Soil & Microclimate Sync</span>
                  </div>
                  <p className="text-sm font-medium leading-snug">
                    "Morning spray window optimal until 11 AM before heat builds up."
                  </p>
                  <p className="text-[11px] text-[#D8E6CC] mt-1 font-mono">
                    Khargone Agro Zone · Humidity 74%
                  </p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 2. Live APMC Mandi Ticker */}
      <section className="bg-[#EFECE1] border-y border-[#E1DBCA] py-3.5 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-2">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 animate-pulse"></span>
              <span className="text-xs font-bold text-[#1E3612] uppercase tracking-wider">
                Live Mandi Price Stream
              </span>
            </div>
            <button
              onClick={() => {
                onSelectRole('dealer');
                onNavigate('dealer-dashboard');
              }}
              className="text-xs font-semibold text-[#2D5818] hover:underline flex items-center gap-1 self-start sm:self-auto"
            >
              <span>Explore All 140+ Mandis</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {MOCK_MANDI_PRICES.slice(0, 4).map((item) => (
              <div
                key={item.id}
                className="bg-white rounded-xl p-3 border border-[#E3DDD0] shadow-sm flex flex-col justify-between"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-xs font-bold text-[#1F2E18] truncate max-w-[140px]">
                      {item.commodity.split('(')[0]}
                    </h3>
                    <p className="text-[10px] text-[#697A62]">{item.mandi}</p>
                  </div>
                  <span
                    className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                      item.trend === 'up'
                        ? 'text-emerald-700 bg-emerald-50'
                        : item.trend === 'down'
                        ? 'text-amber-700 bg-amber-50'
                        : 'text-stone-700 bg-stone-100'
                    }`}
                  >
                    {item.trend === 'up' ? '▲' : item.trend === 'down' ? '▼' : '●'} {item.changePercent}%
                  </span>
                </div>
                <div className="mt-2 flex items-baseline justify-between">
                  <span className="text-sm font-extrabold text-[#1B2D15] tabular-nums">
                    ₹{item.modalPrice.toLocaleString('en-IN')}
                  </span>
                  <span className="text-[10px] text-[#7E8D77]">/ {item.unit}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. The Dual Experience: Farmer vs Dealer */}
      <section className="py-16 sm:py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-2xl sm:text-4xl font-extrabold text-[#16270E] font-display">
            Crafted for two vital hands of Indian agriculture
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#4F6047]">
            Not a sterile corporate portal. Mrittika gives farmers a tactile, voice-led pocket advisor, and dealers a clean, data-dense console.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Card 1: Farmer Reality */}
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-[#E2DCCF] shadow-sm flex flex-col justify-between hover:border-[#234415] transition-colors group">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-xl bg-[#E8EFE2] text-[#234415] flex items-center justify-center">
                <Sprout className="w-6 h-6" />
              </div>

              <div>
                <h3 className="text-xl font-bold text-[#192D12] font-display">
                  For the Farmer in the Field
                </h3>
                <p className="text-xs text-[#7B8B73] mt-0.5">
                  Mobile-first · Voice-enabled · Clear daily action briefs
                </p>
              </div>

              <ul className="space-y-3 pt-2 text-xs sm:text-sm text-[#3C4E34]">
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#2D5818] mt-0.5 shrink-0" />
                  <span>
                    <strong>Today's Action Briefing:</strong> Weather alerts, humidity, and clear advice on spraying vs irrigating.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#2D5818] mt-0.5 shrink-0" />
                  <span>
                    <strong>Krishi Mitra Voice AI:</strong> Ask questions in Hindi, Bengali, Marathi, or Punjabi; hear spoke answers back.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#2D5818] mt-0.5 shrink-0" />
                  <span>
                    <strong>Plant Doctor:</strong> Snap a photo of a diseased leaf for diagnosis and organic or chemical treatment steps.
                  </span>
                </li>
              </ul>
            </div>

            <div className="pt-8">
              <button
                onClick={() => {
                  onSelectRole('farmer');
                  onNavigate('farmer-signup');
                }}
                className="w-full py-3 bg-[#234415] hover:bg-[#1A3410] text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors min-h-[44px]"
              >
                <span>Sign Up as a Farmer</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Card 2: Dealer Reality */}
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-[#E2DCCF] shadow-sm flex flex-col justify-between hover:border-[#895719] transition-colors group">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-xl bg-[#FAF0E1] text-[#895719] flex items-center justify-center">
                <Store className="w-6 h-6" />
              </div>

              <div>
                <h3 className="text-xl font-bold text-[#2A1D0B] font-display">
                  For the Agri-Dealer at the Mandi
                </h3>
                <p className="text-xs text-[#8E795E] mt-0.5">
                  Business-dense · Multi-mandi tracking · UPI & ledger management
                </p>
              </div>

              <ul className="space-y-3 pt-2 text-xs sm:text-sm text-[#4E3E28]">
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#895719] mt-0.5 shrink-0" />
                  <span>
                    <strong>Mandi Price Tracker:</strong> Search by state, district, or crop with 7-day sparklines and price trajectory.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#895719] mt-0.5 shrink-0" />
                  <span>
                    <strong>Business Analytics:</strong> Track seasonal demand, top fertilizer sales, and regional purchasing power.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#895719] mt-0.5 shrink-0" />
                  <span>
                    <strong>Inventory & Farmer Orders:</strong> Manage stock alerts and receive procurement requests from local farmers.
                  </span>
                </li>
              </ul>
            </div>

            <div className="pt-8">
              <button
                onClick={() => {
                  onSelectRole('dealer');
                  onNavigate('dealer-signup');
                }}
                className="w-full py-3 bg-[#895719] hover:bg-[#6D420F] text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors min-h-[44px]"
              >
                <span>Sign Up as a Dealer</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Concrete Real Stories */}
      <section className="bg-[#F4EFE3] py-16 border-t border-[#E1DBCA]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-xl mx-auto mb-10">
            <h2 className="text-xl sm:text-3xl font-extrabold text-[#192E11] font-display">
              Trusted by growers and dealers across 6 states
            </h2>
            <p className="text-xs sm:text-sm text-[#5C6E52] mt-2">
              Authentic feedback from daily users in Khargone, Karnal, and Burdwan
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white p-5 rounded-xl border border-[#DFD8C7] shadow-sm flex flex-col justify-between">
              <p className="text-xs text-[#3E5036] leading-relaxed italic">
                "During the humid spell in August, Krishi Mitra warned me about early blight risk 3 days before symptoms appeared. The neem spray saved 4 acres of tomato."
              </p>
              <div className="mt-4 pt-3 border-t border-[#EFECE1] flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-[#E2EED9] text-[#224314] font-bold text-xs flex items-center justify-center">
                  RP
                </div>
                <div>
                  <h4 className="text-xs font-bold text-[#1C2C16]">Rameshwar Patel</h4>
                  <p className="text-[11px] text-[#71826B]">Soybean & Wheat Grower · Khargone, MP</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-5 rounded-xl border border-[#DFD8C7] shadow-sm flex flex-col justify-between">
              <p className="text-xs text-[#3E5036] leading-relaxed italic">
                "Checking 6 APMC mandi rates used to take half my morning on phone calls. Now I see prices and sparkline trends right on my tablet before making offers."
              </p>
              <div className="mt-4 pt-3 border-t border-[#EFECE1] flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-[#F5EAD4] text-[#895719] font-bold text-xs flex items-center justify-center">
                  SK
                </div>
                <div>
                  <h4 className="text-xs font-bold text-[#1C2C16]">Satish Kumar</h4>
                  <p className="text-[11px] text-[#71826B]">Agri-Inputs Dealer · Karnal Mandi, Haryana</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-5 rounded-xl border border-[#DFD8C7] shadow-sm flex flex-col justify-between">
              <p className="text-xs text-[#3E5036] leading-relaxed italic">
                "Being able to speak in Bengali and have the app read out fertilizer dosage recommendations makes it so simple for older farmers like my uncle to use."
              </p>
              <div className="mt-4 pt-3 border-t border-[#EFECE1] flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-[#E2EED9] text-[#224314] font-bold text-xs flex items-center justify-center">
                  PM
                </div>
                <div>
                  <h4 className="text-xs font-bold text-[#1C2C16]">Prabhat Mondal</h4>
                  <p className="text-[11px] text-[#71826B]">Paddy Farmer · Burdwan, West Bengal</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Bottom Call to Action */}
      <section className="py-14 text-center max-w-4xl mx-auto px-4 sm:px-6">
        <h2 className="text-2xl sm:text-3xl font-extrabold text-[#172B0E] font-display">
          Ready to experience modern agricultural intelligence?
        </h2>
        <p className="mt-2 text-xs sm:text-sm text-[#506348] max-w-lg mx-auto">
          Choose whether you are farming the land or supplying the tools. Start in less than 2 minutes with simple OTP verification.
        </p>
        <div className="mt-6 flex justify-center">
          <button
            onClick={() => onNavigate('role-selection')}
            className="px-8 py-3.5 bg-[#234415] hover:bg-[#1A3410] text-white text-sm font-semibold rounded-xl shadow-md transition-all flex items-center gap-2 group min-h-[48px]"
          >
            <span>Proceed to Role Selection</span>
            <ArrowRight className="w-4 h-4 text-[#D9EDC7] group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[#DFD7C7] py-6 text-center text-xs text-[#7B8B73]">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>© 2026 Mrittika Agritech Platform. Built for Indian Agriculture.</span>
          <div className="flex items-center gap-4">
            <span className="hover:text-[#234415] cursor-pointer">Privacy Policy</span>
            <span>·</span>
            <span className="hover:text-[#234415] cursor-pointer">Kisan Helpline 1800-180-1551</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
