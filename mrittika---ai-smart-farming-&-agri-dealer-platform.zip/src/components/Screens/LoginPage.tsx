import React, { useState } from 'react';
import { AppScreen, UserRole } from '../../types';
import {
  Sprout,
  Store,
  ArrowRight,
  ShieldCheck,
  Phone,
  KeyRound,
  CheckCircle2,
  ArrowLeft
} from 'lucide-react';

interface LoginPageProps {
  onNavigate: (screen: AppScreen) => void;
  onLoginAsFarmer: () => void;
  onLoginAsDealer: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  onNavigate,
  onLoginAsFarmer,
  onLoginAsDealer,
}) => {
  const [role, setRole] = useState<UserRole>('farmer');
  
  // Farmer login fields
  const [farmerPhone, setFarmerPhone] = useState('98261 44520');
  const [farmerOtp, setFarmerOtp] = useState('7291');

  // Dealer login fields
  const [dealerPhone, setDealerPhone] = useState('98120 77341');
  const [dealerOtp, setDealerOtp] = useState('5839');

  const handleFarmerLogin = (e: React.FormEvent) => {
    e.preventDefault();
    onLoginAsFarmer();
  };

  const handleDealerLogin = (e: React.FormEvent) => {
    e.preventDefault();
    onLoginAsDealer();
  };

  return (
    <div className="min-h-[calc(100vh-65px)] bg-[#FBF9F4] py-8 sm:py-12 px-4 sm:px-6 lg:px-8 flex flex-col justify-center">
      <div className="max-w-md mx-auto w-full">
        
        {/* Auth Mode Switcher */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-1 p-1 bg-[#EFECE1] rounded-xl border border-[#DFD9C8]">
            <button
              onClick={() => onNavigate('signup')}
              className="px-3.5 py-1.5 text-xs font-semibold rounded-lg text-[#53614B] hover:text-[#1E3612]"
            >
              New User · Sign Up
            </button>
            <button
              onClick={() => onNavigate('login')}
              className="px-3.5 py-1.5 text-xs font-bold rounded-lg bg-white text-[#1E3612] shadow-sm"
            >
              Old User · Log In
            </button>
          </div>

          <span className="text-xs text-[#71826B] font-medium hidden sm:inline">
            Mrittika Smart Farming
          </span>
        </div>

        {/* Card Container */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#DFD8C8] shadow-sm space-y-6">
          
          <div className="text-center space-y-1">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#16270E] font-display">
              Welcome Back
            </h1>
            <p className="text-xs sm:text-sm text-[#506348]">
              Log in to access your farm briefing or dealer mandi console.
            </p>
          </div>

          {/* TWO OPTIONS FOR ROLE: FARMER VS DEALER */}
          <div className="grid grid-cols-2 p-1.5 bg-[#EFECE1] rounded-2xl border border-[#DFD9C8]">
            <button
              type="button"
              onClick={() => setRole('farmer')}
              className={`flex items-center justify-center gap-2 py-3 rounded-xl text-xs sm:text-sm font-bold transition-all min-h-[48px] ${
                role === 'farmer'
                  ? 'bg-[#234415] text-white shadow-sm'
                  : 'text-[#47573E] hover:text-[#182C10]'
              }`}
            >
              <Sprout className="w-4 h-4" />
              <span>Farmer Login</span>
            </button>

            <button
              type="button"
              onClick={() => setRole('dealer')}
              className={`flex items-center justify-center gap-2 py-3 rounded-xl text-xs sm:text-sm font-bold transition-all min-h-[48px] ${
                role === 'dealer'
                  ? 'bg-[#895719] text-white shadow-sm'
                  : 'text-[#5C4B35] hover:text-[#2A1D0B]'
              }`}
            >
              <Store className="w-4 h-4" />
              <span>Dealer Login</span>
            </button>
          </div>

          {/* ========================================================
              FARMER LOGIN FORM (Opens Farmer Dashboard)
             ======================================================== */}
          {role === 'farmer' ? (
            <form onSubmit={handleFarmerLogin} className="space-y-4">
              <div className="p-3 bg-[#E8EFE2] rounded-xl border border-[#D0DEC4] text-xs text-[#234415]">
                <div className="flex items-center justify-between">
                  <span className="font-semibold">Logging in as Farmer opens Farmer Dashboard.</span>
                  <span className="text-[10px] bg-white px-2 py-0.5 rounded font-mono font-bold">Kisan Mode</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#35482D] mb-1">
                  Registered Mobile Number
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs text-[#71826B] font-semibold">+91</span>
                  <input
                    type="tel"
                    required
                    value={farmerPhone}
                    onChange={(e) => setFarmerPhone(e.target.value)}
                    className="w-full pl-11 pr-3 py-2.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-semibold text-[#182C10] focus:ring-2 focus:ring-[#234415] focus:outline-none min-h-[42px]"
                  />
                  <Phone className="w-4 h-4 text-[#71826B] absolute right-3 top-3 pointer-events-none" />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#35482D]">
                    4-Digit OTP Code
                  </label>
                  <span className="text-[11px] text-[#234415] font-semibold">Pre-filled: 7291</span>
                </div>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={farmerOtp}
                    onChange={(e) => setFarmerOtp(e.target.value)}
                    className="w-full px-3 py-2.5 bg-[#FAF8F3] border-2 border-[#234415] rounded-xl text-sm font-mono font-bold text-[#182C10] focus:outline-none min-h-[42px]"
                  />
                  <KeyRound className="w-4 h-4 text-[#234415] absolute right-3 top-3 pointer-events-none" />
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3.5 bg-[#234415] hover:bg-[#1A3410] active:scale-[0.99] text-white text-sm font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 min-h-[48px]"
                >
                  <Sprout className="w-4 h-4 text-[#C9E4B3]" />
                  <span>Log In as Farmer → Open Farmer Dashboard</span>
                </button>
              </div>

              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={onLoginAsFarmer}
                  className="text-xs text-[#5B6D51] hover:text-[#234415] hover:underline"
                >
                  1-Click Instant Demo Login as Rameshwar Patel (MP)
                </button>
              </div>
            </form>
          ) : (
            /* ========================================================
                DEALER LOGIN FORM (Opens Dealer Dashboard)
               ======================================================== */
            <form onSubmit={handleDealerLogin} className="space-y-4">
              <div className="p-3 bg-[#FAF0E1] rounded-xl border border-[#EBDCC5] text-xs text-[#895719]">
                <div className="flex items-center justify-between">
                  <span className="font-semibold">Logging in as Dealer opens Dealer Dashboard.</span>
                  <span className="text-[10px] bg-white px-2 py-0.5 rounded font-mono font-bold">Vyapaar Mode</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#4E3E28] mb-1">
                  Dealer Mobile or GSTIN
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs text-[#867560] font-semibold">+91</span>
                  <input
                    type="text"
                    required
                    value={dealerPhone}
                    onChange={(e) => setDealerPhone(e.target.value)}
                    className="w-full pl-11 pr-3 py-2.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-semibold text-[#2A1D0B] focus:ring-2 focus:ring-[#895719] focus:outline-none min-h-[42px]"
                  />
                  <Phone className="w-4 h-4 text-[#867560] absolute right-3 top-3 pointer-events-none" />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#4E3E28]">
                    Verification OTP Code
                  </label>
                  <span className="text-[11px] text-[#895719] font-semibold">Pre-filled: 5839</span>
                </div>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={dealerOtp}
                    onChange={(e) => setDealerOtp(e.target.value)}
                    className="w-full px-3 py-2.5 bg-[#FAF8F3] border-2 border-[#895719] rounded-xl text-sm font-mono font-bold text-[#2A1D0B] focus:outline-none min-h-[42px]"
                  />
                  <KeyRound className="w-4 h-4 text-[#895719] absolute right-3 top-3 pointer-events-none" />
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3.5 bg-[#895719] hover:bg-[#6D420F] active:scale-[0.99] text-white text-sm font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 min-h-[48px]"
                >
                  <Store className="w-4 h-4 text-[#F3E2C4]" />
                  <span>Log In as Dealer → Open Dealer Dashboard</span>
                </button>
              </div>

              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={onLoginAsDealer}
                  className="text-xs text-[#867560] hover:text-[#895719] hover:underline"
                >
                  1-Click Instant Demo Login as Kisan Seva Kendra (Karnal)
                </button>
              </div>
            </form>
          )}

        </div>

      </div>
    </div>
  );
};
