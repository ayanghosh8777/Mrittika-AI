import React, { useState } from 'react';
import { AppScreen, FarmerProfile, LanguageCode } from '../../types';
import { LANGUAGES } from '../../data/mockData';
import {
  Sprout,
  ArrowRight,
  ArrowLeft,
  Check,
  Phone,
  MapPin,
  Sparkles,
  ShieldCheck,
  Send
} from 'lucide-react';

interface FarmerSignupScreenProps {
  onNavigate: (screen: AppScreen) => void;
  onComplete: (profile: FarmerProfile) => void;
  currentLanguage: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
}

export const FarmerSignupScreen: React.FC<FarmerSignupScreenProps> = ({
  onNavigate,
  onComplete,
  currentLanguage,
  onLanguageChange,
}) => {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Form State
  const [phone, setPhone] = useState('98261 44520');
  const [name, setName] = useState('Rameshwar Patel');
  const [village, setVillage] = useState('Pipaliya');
  const [district, setDistrict] = useState('Khargone');
  const [state, setState] = useState('Madhya Pradesh');
  const [landSizeAcres, setLandSizeAcres] = useState(4.5);
  const [selectedCrops, setSelectedCrops] = useState<string[]>(['Soybean', 'Wheat', 'Mustard']);
  const [soilType, setSoilType] = useState('Black Cotton Soil (काली मिट्टी)');
  const [otp, setOtp] = useState('7291');
  const [otpSent, setOtpSent] = useState(true);

  const CROP_OPTIONS = [
    'Wheat (गेहूं)',
    'Soybean (सोयाबीन)',
    'Paddy / Rice (धान)',
    'Mustard (सरसों)',
    'Cotton (कपास)',
    'Chana / Chickpea (चना)',
    'Maize (मक्का)',
    'Vegetables / Tomato (सब्जियां)',
  ];

  const toggleCrop = (crop: string) => {
    if (selectedCrops.includes(crop)) {
      setSelectedCrops(selectedCrops.filter((c) => c !== crop));
    } else {
      setSelectedCrops([...selectedCrops, crop]);
    }
  };

  const handleFinish = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const profile: FarmerProfile = {
      name,
      phone,
      village,
      district,
      state,
      landSizeAcres,
      primaryCrops: selectedCrops,
      soilType,
      language: currentLanguage,
    };
    onComplete(profile);
  };

  return (
    <div className="min-h-[calc(100vh-65px)] bg-[#FBF9F4] py-8 sm:py-12 px-4 sm:px-6 flex flex-col justify-center">
      <div className="max-w-xl mx-auto w-full">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => {
              if (step > 1) {
                setStep((step - 1) as any);
              } else {
                onNavigate('role-selection');
              }
            }}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#5B6D51] hover:text-[#234415] transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>{step > 1 ? 'Previous Step' : 'Back to Role Selection'}</span>
          </button>

          <span className="text-xs font-bold text-[#234415] bg-[#E8EFE2] px-2.5 py-1 rounded-full border border-[#D0DEC4]">
            Step {step} of 4
          </span>
        </div>

        {/* Step Progress Bar */}
        <div className="w-full bg-[#E5E0D2] h-1.5 rounded-full overflow-hidden mb-6">
          <div
            className="bg-[#234415] h-full transition-all duration-300 rounded-full"
            style={{ width: `${(step / 4) * 100}%` }}
          />
        </div>

        {/* Form Container */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#DFD8C8] shadow-sm">
          {/* STEP 1: Language & Phone */}
          {step === 1 && (
            <div className="space-y-6">
              <div>
                <div className="w-10 h-10 rounded-xl bg-[#E8EFE2] text-[#234415] flex items-center justify-center mb-3">
                  <Sprout className="w-5 h-5" />
                </div>
                <h2 className="text-xl sm:text-2xl font-bold text-[#182C10] font-display">
                  Welcome, Farmer Friend!
                </h2>
                <p className="text-xs sm:text-sm text-[#57694F] mt-1">
                  Choose your preferred language and enter your mobile number for quick OTP sign in.
                </p>
              </div>

              {/* Language Selector */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#3D4F35] mb-2">
                  1. Select Your Spoken Language / भाषा चुनें
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {LANGUAGES.map((lang) => (
                    <button
                      key={lang.code}
                      type="button"
                      onClick={() => onLanguageChange(lang.code)}
                      className={`p-2.5 rounded-xl border text-xs font-semibold text-left transition-all min-h-[44px] flex items-center justify-between ${
                        currentLanguage === lang.code
                          ? 'bg-[#234415] text-white border-[#234415] shadow-sm'
                          : 'bg-[#F9F7F1] text-[#34442C] border-[#DCD5C4] hover:bg-[#F0EBDC]'
                      }`}
                    >
                      <span>{lang.nativeName}</span>
                      {currentLanguage === lang.code && (
                        <Check className="w-3.5 h-3.5 text-[#C9E4B3]" />
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Mobile Phone */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#3D4F35] mb-2">
                  2. Mobile Number (for OTP verification)
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#71826B] font-semibold text-sm">
                    +91
                  </div>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="Enter 10-digit phone number"
                    className="w-full pl-12 pr-4 py-3 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-sm font-semibold text-[#182C10] focus:ring-2 focus:ring-[#234415] focus:outline-none min-h-[44px]"
                  />
                  <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-[#71826B]">
                    <Phone className="w-4 h-4" />
                  </div>
                </div>
                <p className="text-[11px] text-[#71826B] mt-1.5">
                  No password needed. You will receive an instant 4-digit SMS OTP.
                </p>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="w-full py-3.5 bg-[#234415] hover:bg-[#1A3410] text-white text-sm font-semibold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 min-h-[48px]"
                >
                  <span>Continue to Farm Details</span>
                  <ArrowRight className="w-4 h-4 text-[#C9E4B3]" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: Name & Location */}
          {step === 2 && (
            <div className="space-y-5">
              <div>
                <h2 className="text-xl sm:text-2xl font-bold text-[#182C10] font-display">
                  Where is your farm located?
                </h2>
                <p className="text-xs sm:text-sm text-[#57694F] mt-1">
                  We use your village to fetch accurate localized weather and nearest mandi rates.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#3D4F35] mb-1.5">
                  Your Full Name / आपका नाम
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Rameshwar Patel"
                  className="w-full px-4 py-2.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-sm font-semibold text-[#182C10] focus:ring-2 focus:ring-[#234415] focus:outline-none min-h-[44px]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#3D4F35] mb-1.5">
                    Village / ग्राम
                  </label>
                  <input
                    type="text"
                    value={village}
                    onChange={(e) => setVillage(e.target.value)}
                    placeholder="e.g. Pipaliya"
                    className="w-full px-4 py-2.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-sm font-semibold text-[#182C10] focus:ring-2 focus:ring-[#234415] focus:outline-none min-h-[44px]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#3D4F35] mb-1.5">
                    District / जिला
                  </label>
                  <input
                    type="text"
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                    placeholder="e.g. Khargone"
                    className="w-full px-4 py-2.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-sm font-semibold text-[#182C10] focus:ring-2 focus:ring-[#234415] focus:outline-none min-h-[44px]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#3D4F35] mb-1.5">
                  State / राज्य
                </label>
                <select
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                  className="w-full px-4 py-2.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-sm font-semibold text-[#182C10] focus:ring-2 focus:ring-[#234415] focus:outline-none min-h-[44px]"
                >
                  <option value="Madhya Pradesh">Madhya Pradesh (मध्य प्रदेश)</option>
                  <option value="Haryana">Haryana (हरियाणा)</option>
                  <option value="Punjab">Punjab (ਪੰਜਾਬ)</option>
                  <option value="West Bengal">West Bengal (পশ্চিমবঙ্গ)</option>
                  <option value="Maharashtra">Maharashtra (महाराष्ट्र)</option>
                  <option value="Rajasthan">Rajasthan (राजस्थान)</option>
                  <option value="Uttar Pradesh">Uttar Pradesh (उत्तर प्रदेश)</option>
                </select>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="w-full py-3.5 bg-[#234415] hover:bg-[#1A3410] text-white text-sm font-semibold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 min-h-[48px]"
                >
                  <span>Continue to Crops Grown</span>
                  <ArrowRight className="w-4 h-4 text-[#C9E4B3]" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: Land Size & Crops */}
          {step === 3 && (
            <div className="space-y-5">
              <div>
                <h2 className="text-xl sm:text-2xl font-bold text-[#182C10] font-display">
                  What crops do you grow?
                </h2>
                <p className="text-xs sm:text-sm text-[#57694F] mt-1">
                  Helps Krishi Mitra provide tailored sowing windows, fertilizer advice, and pest alerts.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#3D4F35] mb-1.5">
                  Total Land Holding (in Acres / एकड़)
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min="0.5"
                    max="25"
                    step="0.5"
                    value={landSizeAcres}
                    onChange={(e) => setLandSizeAcres(parseFloat(e.target.value))}
                    className="flex-1 accent-[#234415]"
                  />
                  <div className="px-3 py-2 bg-[#E8EFE2] rounded-xl font-bold text-[#234415] text-sm tabular-nums whitespace-nowrap min-w-[80px] text-center border border-[#D0DEC4]">
                    {landSizeAcres} Acres
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#3D4F35] mb-2">
                  Primary Crops (Select all that apply)
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {CROP_OPTIONS.map((crop) => {
                    const isSelected = selectedCrops.some((c) => crop.includes(c));
                    return (
                      <button
                        key={crop}
                        type="button"
                        onClick={() => {
                          const baseName = crop.split(' ')[0];
                          toggleCrop(baseName);
                        }}
                        className={`p-2.5 rounded-xl border text-xs font-semibold text-left transition-all min-h-[44px] flex items-center justify-between ${
                          isSelected
                            ? 'bg-[#234415] text-white border-[#234415] shadow-xs'
                            : 'bg-[#FAF8F3] text-[#34452B] border-[#DCD5C4] hover:bg-[#F2ECE0]'
                        }`}
                      >
                        <span className="truncate">{crop}</span>
                        {isSelected && <Check className="w-3.5 h-3.5 text-[#C9E4B3] shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#3D4F35] mb-1.5">
                  Dominant Soil Type
                </label>
                <select
                  value={soilType}
                  onChange={(e) => setSoilType(e.target.value)}
                  className="w-full px-4 py-2.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-sm font-semibold text-[#182C10] focus:ring-2 focus:ring-[#234415] focus:outline-none min-h-[44px]"
                >
                  <option value="Black Cotton Soil (काली मिट्टी)">Black Cotton Soil (काली मिट्टी)</option>
                  <option value="Alluvial Soil (जलोढ़ मिट्टी)">Alluvial Loam (जलोढ़ मिट्टी)</option>
                  <option value="Red & Yellow Sandy Soil (लाल-पीली मिट्टी)">Red & Yellow Soil (लाल-पीली मिट्टी)</option>
                  <option value="Clayey Loam (दोमट मिट्टी)">Clayey Loam (दोमट मिट्टी)</option>
                </select>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => setStep(4)}
                  className="w-full py-3.5 bg-[#234415] hover:bg-[#1A3410] text-white text-sm font-semibold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 min-h-[48px]"
                >
                  <span>Proceed to Phone Verification</span>
                  <ArrowRight className="w-4 h-4 text-[#C9E4B3]" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: OTP Verification */}
          {step === 4 && (
            <div className="space-y-5">
              <div>
                <div className="w-10 h-10 rounded-xl bg-[#E8EFE2] text-[#234415] flex items-center justify-center mb-3">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <h2 className="text-xl sm:text-2xl font-bold text-[#182C10] font-display">
                  Verify Phone Number
                </h2>
                <p className="text-xs sm:text-sm text-[#57694F] mt-1">
                  We sent a 4-digit code to <strong>+91 {phone}</strong>
                </p>
              </div>

              {/* Simulated SMS Box for seamless demo testing */}
              <div className="p-3 bg-[#EAF2E4] rounded-xl border border-[#CDE0C1] flex items-center justify-between text-xs text-[#203D14]">
                <div className="flex items-center gap-2">
                  <Send className="w-4 h-4 text-[#234415]" />
                  <span>SMS Code: <strong>7291</strong> (Auto-detected)</span>
                </div>
                <span className="font-mono text-[11px] bg-white px-2 py-0.5 rounded text-[#234415] font-bold">
                  Demo Active
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#3D4F35] mb-2 text-center">
                  Enter 4-Digit Verification Code
                </label>
                <div className="flex justify-center gap-3">
                  {['7', '2', '9', '1'].map((digit, idx) => (
                    <div
                      key={idx}
                      className="w-12 h-14 bg-[#FAF8F3] border-2 border-[#234415] rounded-xl flex items-center justify-center text-xl font-bold text-[#182C10] font-mono shadow-xs"
                    >
                      {otp[idx] || digit}
                    </div>
                  ))}
                </div>
              </div>

              <div className="text-center text-xs text-[#6F7F68]">
                <span>Didn't receive code? </span>
                <button
                  type="button"
                  onClick={() => alert('Code 7291 resent via SMS')}
                  className="text-[#234415] font-bold hover:underline"
                >
                  Resend OTP in 24s
                </button>
              </div>

              <div className="pt-3">
                <button
                  type="button"
                  onClick={() => handleFinish()}
                  className="w-full py-3.5 bg-[#234415] hover:bg-[#1A3410] active:scale-[0.98] text-white text-sm font-semibold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 min-h-[48px]"
                >
                  <Sprout className="w-4 h-4 text-[#C9E4B3]" />
                  <span>Verify & Enter Farm Dashboard</span>
                </button>
              </div>
            </div>
          )}

          {/* Quick Demo Bypass */}
          <div className="mt-6 pt-4 border-t border-[#EDE8DC] text-center">
            <button
              type="button"
              onClick={() => handleFinish()}
              className="text-xs font-semibold text-[#5B6D51] hover:text-[#234415] transition-colors"
            >
              Skip verification & log in as Rameshwar Patel (4.5 Acres, MP) →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
