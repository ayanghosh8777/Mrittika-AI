import React, { useState } from 'react';
import { AppScreen, UserRole, FarmerProfile, DealerProfile, LanguageCode } from '../../types';
import { LANGUAGES } from '../../data/mockData';
import {
  Sprout,
  Store,
  ArrowRight,
  ShieldCheck,
  Phone,
  MapPin,
  Building2,
  Check,
  Sparkles,
  ArrowLeft
} from 'lucide-react';

interface SignUpPageProps {
  onNavigate: (screen: AppScreen) => void;
  onFarmerSignUp: (profile: FarmerProfile) => void;
  onDealerSignUp: (profile: DealerProfile) => void;
  selectedLanguage: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
}

export const SignUpPage: React.FC<SignUpPageProps> = ({
  onNavigate,
  onFarmerSignUp,
  onDealerSignUp,
  selectedLanguage,
  onLanguageChange,
}) => {
  const [role, setRole] = useState<UserRole>('farmer');

  // Farmer form state
  const [fName, setFName] = useState('Rameshwar Patel');
  const [fPhone, setFPhone] = useState('98261 44520');
  const [fVillage, setFVillage] = useState('Pipaliya');
  const [fDistrict, setFDistrict] = useState('Khargone');
  const [fState, setFState] = useState('Madhya Pradesh');
  const [fLandSize, setFLandSize] = useState(4.5);
  const [fSoilType, setFSoilType] = useState('Black Cotton Soil (काली मिट्टी)');
  const [fCrops, setFCrops] = useState<string[]>(['Wheat', 'Soybean', 'Mustard']);
  const [fOtp, setFOtp] = useState('7291');

  // Dealer form state
  const [dName, setDName] = useState('Satish Kumar');
  const [dPhone, setDPhone] = useState('98120 77341');
  const [dBusinessName, setDBusinessName] = useState('Kisan Seva Kendra & Agri Supplies');
  const [dBusinessType, setDBusinessType] = useState('Seeds, Fertilizers & Crop Protection');
  const [dDistrict, setDDistrict] = useState('Karnal');
  const [dState, setDState] = useState('Haryana');
  const [dGstin, setDGstin] = useState('06AAECK9821L1Z9');
  const [dOtp, setDOtp] = useState('5839');

  const handleFarmerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const profile: FarmerProfile = {
      name: fName,
      phone: fPhone,
      village: fVillage,
      district: fDistrict,
      state: fState,
      landSizeAcres: fLandSize,
      primaryCrops: fCrops,
      soilType: fSoilType,
      language: selectedLanguage,
    };
    onFarmerSignUp(profile);
  };

  const handleDealerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const profile: DealerProfile = {
      name: dName,
      phone: dPhone,
      businessName: dBusinessName,
      businessType: dBusinessType,
      districtsCovered: [dDistrict, 'Kurukshetra', 'Panipat'],
      state: dState,
      gstin: dGstin,
      verified: true,
    };
    onDealerSignUp(profile);
  };

  return (
    <div className="min-h-[calc(100vh-65px)] bg-[#FBF9F4] py-8 sm:py-12 px-4 sm:px-6 lg:px-8 flex flex-col justify-center">
      <div className="max-w-2xl mx-auto w-full">
        
        {/* Auth Mode Switcher */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-1 p-1 bg-[#EFECE1] rounded-xl border border-[#DFD9C8]">
            <button
              onClick={() => onNavigate('signup')}
              className="px-3.5 py-1.5 text-xs font-bold rounded-lg bg-white text-[#1E3612] shadow-sm"
            >
              New User · Sign Up
            </button>
            <button
              onClick={() => onNavigate('login')}
              className="px-3.5 py-1.5 text-xs font-semibold rounded-lg text-[#53614B] hover:text-[#1E3612]"
            >
              Old User · Log In
            </button>
          </div>

          <span className="text-xs text-[#71826B] font-medium hidden sm:inline">
            Mrittika Smart Farming Platform
          </span>
        </div>

        {/* Card Container */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#DFD8C8] shadow-sm space-y-6">
          
          <div className="text-center space-y-1">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#16270E] font-display">
              Create New Account
            </h1>
            <p className="text-xs sm:text-sm text-[#506348]">
              Join Mrittika to access personalized crop advisory, plant doctors, or dealer mandi analytics.
            </p>
          </div>

          {/* TWO OPTIONS FOR ROLE: FARMER VS DEALER */}
          <div className="grid grid-cols-2 p-1.5 bg-[#EFECE1] rounded-2xl border border-[#DFD9C8]">
            <button
              type="button"
              onClick={() => setRole('farmer')}
              className={`flex items-center justify-center gap-2 py-3 rounded-xl text-xs sm:text-sm font-bold transition-all min-h-[48px] ${
                role === 'farmer'
                  ? 'bg-[#234415] text-white shadow-sm'
                  : 'text-[#47573E] hover:text-[#182C10]'
              }`}
            >
              <Sprout className="w-4 h-4" />
              <span>I'm a Farmer</span>
            </button>

            <button
              type="button"
              onClick={() => setRole('dealer')}
              className={`flex items-center justify-center gap-2 py-3 rounded-xl text-xs sm:text-sm font-bold transition-all min-h-[48px] ${
                role === 'dealer'
                  ? 'bg-[#895719] text-white shadow-sm'
                  : 'text-[#5C4B35] hover:text-[#2A1D0B]'
              }`}
            >
              <Store className="w-4 h-4" />
              <span>I'm a Dealer</span>
            </button>
          </div>

          {/* ========================================================
              FARMER SIGN UP FORM (Directly opens Farmer Dashboard)
             ======================================================== */}
          {role === 'farmer' ? (
            <form onSubmit={handleFarmerSubmit} className="space-y-4">
              <div className="p-3 bg-[#E8EFE2] rounded-xl border border-[#D0DEC4] flex items-center justify-between text-xs text-[#234415]">
                <span className="font-semibold">Signing up as a Farmer opens the Farmer Dashboard immediately.</span>
                <span className="text-[10px] bg-white px-2 py-0.5 rounded font-mono font-bold">Kisan Mode</span>
              </div>

              {/* Language selection */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#35482D] mb-1.5">
                  Preferred App Language / भाषा
                </label>
                <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
                  {LANGUAGES.map((lang) => (
                    <button
                      key={lang.code}
                      type="button"
                      onClick={() => onLanguageChange(lang.code)}
                      className={`py-2 px-1 text-center rounded-xl border text-xs font-semibold transition-all ${
                        selectedLanguage === lang.code
                          ? 'bg-[#234415] text-white border-[#234415] shadow-xs'
                          : 'bg-[#FAF8F3] text-[#34452B] border-[#DCD5C4]'
                      }`}
                    >
                      {lang.nativeName}
                    </button>
                  ))}
                </div>
              </div>

              {/* Farmer Name & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#35482D] mb-1">
                    Farmer Name / किसान का नाम
                  </label>
                  <input
                    type="text"
                    required
                    value={fName}
                    onChange={(e) => setFName(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-semibold text-[#182C10] focus:ring-2 focus:ring-[#234415] focus:outline-none min-h-[42px]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#35482D] mb-1">
                    Mobile Number (Phone OTP)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-xs text-[#71826B] font-semibold">+91</span>
                    <input
                      type="tel"
                      required
                      value={fPhone}
                      onChange={(e) => setFPhone(e.target.value)}
                      className="w-full pl-11 pr-3 py-2.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-semibold text-[#182C10] focus:ring-2 focus:ring-[#234415] focus:outline-none min-h-[42px]"
                    />
                  </div>
                </div>
              </div>

              {/* Location */}
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-[#35482D] mb-1">
                    Village
                  </label>
                  <input
                    type="text"
                    value={fVillage}
                    onChange={(e) => setFVillage(e.target.value)}
                    className="w-full px-3 py-2 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-semibold text-[#182C10] focus:ring-2 focus:ring-[#234415] focus:outline-none min-h-[40px]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-[#35482D] mb-1">
                    District
                  </label>
                  <input
                    type="text"
                    value={fDistrict}
                    onChange={(e) => setFDistrict(e.target.value)}
                    className="w-full px-3 py-2 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-semibold text-[#182C10] focus:ring-2 focus:ring-[#234415] focus:outline-none min-h-[40px]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-[#35482D] mb-1">
                    State
                  </label>
                  <select
                    value={fState}
                    onChange={(e) => setFState(e.target.value)}
                    className="w-full px-2 py-2 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-semibold text-[#182C10] focus:ring-2 focus:ring-[#234415] focus:outline-none min-h-[40px]"
                  >
                    <option value="Madhya Pradesh">Madhya Pradesh</option>
                    <option value="Haryana">Haryana</option>
                    <option value="Punjab">Punjab</option>
                    <option value="West Bengal">West Bengal</option>
                    <option value="Maharashtra">Maharashtra</option>
                    <option value="Rajasthan">Rajasthan</option>
                  </select>
                </div>
              </div>

              {/* Land size & OTP */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#35482D] mb-1">
                    Land Holding (Acres)
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    value={fLandSize}
                    onChange={(e) => setFLandSize(parseFloat(e.target.value) || 1)}
                    className="w-full px-3 py-2.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-semibold text-[#182C10] focus:ring-2 focus:ring-[#234415] focus:outline-none min-h-[42px]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#35482D] mb-1">
                    SMS OTP (Pre-filled for Demo)
                  </label>
                  <input
                    type="text"
                    value={fOtp}
                    onChange={(e) => setFOtp(e.target.value)}
                    className="w-full px-3 py-2.5 bg-[#FAF8F3] border-2 border-[#234415] rounded-xl text-xs font-mono font-bold text-[#182C10] focus:outline-none min-h-[42px]"
                  />
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3.5 bg-[#234415] hover:bg-[#1A3410] active:scale-[0.99] text-white text-sm font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 min-h-[48px]"
                >
                  <Sprout className="w-4 h-4 text-[#C9E4B3]" />
                  <span>Complete Sign Up & Open Farmer Dashboard</span>
                </button>
              </div>
            </form>
          ) : (
            /* ========================================================
                DEALER SIGN UP FORM (Directly opens Dealer Dashboard)
               ======================================================== */
            <form onSubmit={handleDealerSubmit} className="space-y-4">
              <div className="p-3 bg-[#FAF0E1] rounded-xl border border-[#EBDCC5] flex items-center justify-between text-xs text-[#895719]">
                <span className="font-semibold">Signing up as a Dealer opens the Dealer Dashboard immediately.</span>
                <span className="text-[10px] bg-white px-2 py-0.5 rounded font-mono font-bold">Vyapaar Mode</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#4E3E28] mb-1">
                    Proprietor Name
                  </label>
                  <input
                    type="text"
                    required
                    value={dName}
                    onChange={(e) => setDName(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-semibold text-[#2A1D0B] focus:ring-2 focus:ring-[#895719] focus:outline-none min-h-[42px]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#4E3E28] mb-1">
                    Business Mobile Number
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-xs text-[#867560] font-semibold">+91</span>
                    <input
                      type="tel"
                      required
                      value={dPhone}
                      onChange={(e) => setDPhone(e.target.value)}
                      className="w-full pl-11 pr-3 py-2.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-semibold text-[#2A1D0B] focus:ring-2 focus:ring-[#895719] focus:outline-none min-h-[42px]"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#4E3E28] mb-1">
                  Agri-Inputs Store / Firm Name
                </label>
                <input
                  type="text"
                  required
                  value={dBusinessName}
                  onChange={(e) => setDBusinessName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-semibold text-[#2A1D0B] focus:ring-2 focus:ring-[#895719] focus:outline-none min-h-[42px]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#4E3E28] mb-1">
                    District of Operation
                  </label>
                  <input
                    type="text"
                    required
                    value={dDistrict}
                    onChange={(e) => setDDistrict(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-semibold text-[#2A1D0B] focus:ring-2 focus:ring-[#895719] focus:outline-none min-h-[42px]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-[#4E3E28] mb-1">
                    GSTIN or License (Optional)
                  </label>
                  <input
                    type="text"
                    value={dGstin}
                    onChange={(e) => setDGstin(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-mono font-semibold text-[#2A1D0B] uppercase focus:ring-2 focus:ring-[#895719] focus:outline-none min-h-[42px]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#4E3E28] mb-1">
                  Verification OTP Code (Pre-filled: 5839)
                </label>
                <input
                  type="text"
                  value={dOtp}
                  onChange={(e) => setDOtp(e.target.value)}
                  className="w-full px-3 py-2.5 bg-[#FAF8F3] border-2 border-[#895719] rounded-xl text-xs font-mono font-bold text-[#2A1D0B] focus:outline-none min-h-[42px]"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3.5 bg-[#895719] hover:bg-[#6D420F] active:scale-[0.99] text-white text-sm font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-2 min-h-[48px]"
                >
                  <Store className="w-4 h-4 text-[#F3E2C4]" />
                  <span>Complete Sign Up & Open Dealer Dashboard</span>
                </button>
              </div>
            </form>
          )}

        </div>

      </div>
    </div>
  );
};
