import React, { useState } from 'react';
import {
  FarmerProfile,
  FarmerTab,
  LanguageCode,
  WeatherBriefing,
  DiseaseResult,
  ChatMessage
} from '../../types';
import {
  MOCK_WEATHER,
  MOCK_MANDI_PRICES,
  MOCK_DISEASE_RESULT,
  INITIAL_CHAT_MESSAGES,
  QUICK_PROMPTS,
  UI_TRANSLATIONS,
  LANGUAGES
} from '../../data/mockData';
import { CropPredictionAnalysisView } from './CropPredictionAnalysisView';
import { GovtSchemesAndShopsView } from './GovtSchemesAndShopsView';
import {
  Home,
  Sprout,
  MessageSquare,
  ScanEye,
  User,
  Landmark,
  Mic,
  MicOff,
  Send,
  CloudSun,
  Droplets,
  Wind,
  AlertTriangle,
  CheckCircle2,
  Volume2,
  Upload,
  Camera,
  RefreshCw,
  PhoneCall,
  Smartphone,
  Maximize2,
  ChevronRight,
  TrendingUp,
  MapPin,
  Calendar,
  Layers,
  Sparkles,
  Info
} from 'lucide-react';

interface FarmerDashboardProps {
  profile: FarmerProfile;
  onUpdateProfile: (updated: Partial<FarmerProfile>) => void;
  selectedLanguage: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
  onSwitchToDealer: () => void;
}

export const FarmerDashboard: React.FC<FarmerDashboardProps> = ({
  profile,
  onUpdateProfile,
  selectedLanguage,
  onLanguageChange,
  onSwitchToDealer,
}) => {
  const [activeTab, setActiveTab] = useState<FarmerTab>('home');
  const [isMobileFrame, setIsMobileFrame] = useState(false);

  // Translation hook
  const t = UI_TRANSLATIONS[selectedLanguage] || UI_TRANSLATIONS.en;

  // Krishi Mitra State
  const [messages, setMessages] = useState<ChatMessage[]>(INITIAL_CHAT_MESSAGES);
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const [audioPlayingId, setAudioPlayingId] = useState<string | null>(null);

  // Crop Prediction Guided Form State
  const [soilType, setSoilType] = useState('Black Cotton Soil');
  const [season, setSeason] = useState<'Kharif (Monsoon)' | 'Rabi (Winter)' | 'Zaid (Summer)'>('Rabi (Winter)');
  const [waterSource, setWaterSource] = useState('Borewell / Tube well');
  const [predictionResult, setPredictionResult] = useState<{
    cropName: string;
    variety: string;
    expectedYield: string;
    estimatedRevenue: string;
    duration: string;
    advisoryNote: string;
    waterRequirement: string;
  } | null>({
    cropName: 'Sharbati Durum Wheat',
    variety: 'HI-8627 (Malavika)',
    expectedYield: '22 - 26 Quintals / Acre',
    estimatedRevenue: '₹68,000 - ₹78,000 / Acre',
    duration: '115 - 120 Days',
    waterRequirement: '3 - 4 critical irrigations at crown root initiation and grain filling',
    advisoryNote: 'Highly suitable for your black cotton soil with high moisture retention. Best sowing window: Nov 10 - Nov 28.',
  });

  // Disease Detection State
  const [diseaseImage, setDiseaseImage] = useState<string | null>(
    '/src/assets/images/crop_disease_sample_1791000557050.jpg'
  );
  const [isScanning, setIsScanning] = useState(false);
  const [diseaseReport, setDiseaseReport] = useState<DiseaseResult | null>(MOCK_DISEASE_RESULT);

  // Audio text-to-speech simulation
  const handlePlayVoice = (msgId: string, text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      if (audioPlayingId === msgId) {
        setAudioPlayingId(null);
        return;
      }
      const utterance = new SpeechSynthesisUtterance(text);
      if (selectedLanguage === 'hi') utterance.lang = 'hi-IN';
      else if (selectedLanguage === 'bn') utterance.lang = 'bn-IN';
      else utterance.lang = 'en-IN';

      utterance.onend = () => setAudioPlayingId(null);
      utterance.onerror = () => setAudioPlayingId(null);
      setAudioPlayingId(msgId);
      window.speechSynthesis.speak(utterance);
    } else {
      setAudioPlayingId(msgId);
      setTimeout(() => setAudioPlayingId(null), 3000);
    }
  };

  // Voice toggle simulation
  const handleToggleVoiceRecord = () => {
    if (!isRecording) {
      setIsRecording(true);
      // Simulate listening and speaking back
      setTimeout(() => {
        setIsRecording(false);
        const userVoicePrompt =
          selectedLanguage === 'hi'
            ? 'क्या इस मौसम में गेहूं की बुवाई के लिए डीएपी खाद डालना ठीक रहेगा?'
            : 'Is today a good day to spray micronutrients on soybean?';
        sendUserMessage(userVoicePrompt);
      }, 2400);
    } else {
      setIsRecording(false);
    }
  };

  const sendUserMessage = (textToSend?: string) => {
    const content = textToSend || inputText;
    if (!content.trim()) return;

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: content,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setIsThinking(true);

    // Smart Local Agronomist Answer Generator
    setTimeout(() => {
      let reply = '';
      const lower = content.toLowerCase();

      if (lower.includes('weather') || lower.includes('मौसम') || lower.includes('spray')) {
        reply =
          selectedLanguage === 'hi'
            ? 'आज आपके क्षेत्र में शाम को 25% हल्की बारिश की संभावना है। सुबह 10:30 बजे से पहले माइक्रोन्यूट्रिएंट का छिड़काव सुरक्षित रहेगा। भारी सिंचाई 24 घंटे के लिए टालें।'
            : 'Light evening drizzle (25%) is forecast today in Khargone. The morning window until 10:30 AM is ideal for micronutrient foliar spray. Hold off canal irrigation until tomorrow.';
      } else if (lower.includes('yellow') || lower.includes('पीली') || lower.includes('leaf') || lower.includes('पत्ती')) {
        reply =
          selectedLanguage === 'hi'
            ? 'निचली पत्तियों पर पीले धब्बे अर्ली ब्लाइट या नाइट्रोजन की शुरुआती कमी के हो सकते हैं। कृपया "पौध डॉक्टर" टैब में पत्ते की फोटो लें ताकि सही दवा बताई जा सके।'
            : 'Lower leaf yellowing usually indicates early blight or initial nitrogen trans-location. Please take a photo in the Plant Doctor tab for an exact diagnosis.';
      } else if (lower.includes('dap') || lower.includes('खाद') || lower.includes('fertilizer') || lower.includes('urea')) {
        reply =
          selectedLanguage === 'hi'
            ? 'आपके 4.5 एकड़ खेत के लिए गेहूं की बुवाई के समय 1 बैग डीएपी (50 किग्रा) प्रति एकड़ और 10 किग्रा जिंक सल्फेट पर्याप्त रहेगा। यूरिया की पहली टॉप-ड्रेसिंग पहली सिंचाई (21 दिन बाद) पर दें।'
            : 'For your 4.5 acres during wheat sowing, apply 1 bag DAP (50 kg) per acre with 10 kg Zinc Sulfate. Apply the first urea top-dressing at the first irrigation (21 days after sowing).';
      } else {
        reply =
          selectedLanguage === 'hi'
            ? `रामेश्वर जी, मैंने आपके सवाल को दर्ज किया है: "${content}". आपकी काली मिट्टी और मौजूदा 28°C तापमान के अनुसार, संतुलित नमी बनाए रखना सबसे जरूरी है।`
            : `Rameshwar ji, regarding "${content}": For your black cotton soil and current 28°C weather, maintaining balanced soil aeration before the Rabi crop sowing is recommended.`;
      }

      const botMsg: ChatMessage = {
        id: `mitra-${Date.now()}`,
        sender: 'mitra',
        text: reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        audioAvailable: true,
      };

      setMessages((prev) => [...prev, botMsg]);
      setIsThinking(false);
    }, 1200);
  };

  // Run Crop Prediction
  const handleCalculateCropPrediction = () => {
    setIsThinking(true);
    setTimeout(() => {
      if (season === 'Rabi (Winter)') {
        setPredictionResult({
          cropName: 'Sharbati Durum Wheat & Yellow Mustard',
          variety: 'HI-8627 (Malavika) + Pioneer 45S46',
          expectedYield: '22 - 26 Q/Acre (Wheat) | 7 - 9 Q/Acre (Mustard)',
          estimatedRevenue: '₹72,000 - ₹82,000 / Acre',
          duration: '115 - 125 Days',
          waterRequirement: 'Moderate (3 irrigations)',
          advisoryNote:
            'Excellent match for Khargone black cotton soil. Planting mustard as border strip reduces pest pressure on wheat.',
        });
      } else if (season === 'Kharif (Monsoon)') {
        setPredictionResult({
          cropName: 'Certified Soybean',
          variety: 'JS-9560 / RVS-2001-4',
          expectedYield: '10 - 13 Quintals / Acre',
          estimatedRevenue: '₹48,000 - ₹58,000 / Acre',
          duration: '90 - 95 Days',
          waterRequirement: 'Rainfed with 1 life-saving irrigation',
          advisoryNote:
            'High oil content variety with strong resistance to stem fly. Treat seeds with Trichoderma viride before sowing.',
        });
      } else {
        setPredictionResult({
          cropName: 'Summer Moong (Green Gram)',
          variety: 'Virat / IPM 205-7',
          expectedYield: '5 - 7 Quintals / Acre',
          estimatedRevenue: '₹38,000 - ₹44,000 / Acre',
          duration: '60 - 65 Days',
          waterRequirement: '4 light summer irrigations',
          advisoryNote:
            'Fixes 35 kg atmospheric nitrogen per hectare into soil, significantly reducing fertilizer requirement for following crop.',
        });
      }
      setIsThinking(false);
    }, 900);
  };

  // Run Disease Scan
  const handleScanSample = () => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      setDiseaseReport(MOCK_DISEASE_RESULT);
    }, 1500);
  };

  return (
    <div className="min-h-[calc(100vh-65px)] bg-[#FBF9F4] pb-24 sm:pb-12 text-[#182C10]">
      {/* Viewport Control Banner */}
      <div className="bg-[#EFECE1] border-b border-[#E1DBCA] px-4 py-2 text-xs flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
          <span className="font-semibold text-[#2D5818]">
            Farmer Mode Active: {profile.name}
          </span>
          <span className="text-[#84947C] hidden sm:inline">· {profile.village}, {profile.district} ({profile.landSizeAcres} Acres)</span>
        </div>

        <div className="flex items-center gap-2">
          {/* Mobile frame toggle for demo review */}
          <button
            onClick={() => setIsMobileFrame(!isMobileFrame)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-white text-[#3E4F37] border border-[#D8D2C2] hover:bg-[#F8F6F0] font-semibold text-[11px]"
          >
            {isMobileFrame ? (
              <>
                <Maximize2 className="w-3.5 h-3.5" />
                <span>Full Width</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5" />
                <span>Phone Frame</span>
              </>
            )}
          </button>

          {/* Quick Helpline */}
          <a
            href="tel:18001801551"
            className="hidden sm:flex items-center gap-1 text-[11px] text-[#234415] font-bold bg-[#E8EFE2] px-2 py-1 rounded border border-[#D0DEC4]"
          >
            <PhoneCall className="w-3 h-3" />
            <span>Kisan Call Centre 1800-180-1551</span>
          </a>
        </div>
      </div>

      {/* Main Responsive Canvas */}
      <div
        className={`mx-auto transition-all duration-300 ${
          isMobileFrame
            ? 'max-w-[420px] my-6 rounded-[36px] border-8 border-[#3A4A33] shadow-2xl overflow-hidden bg-[#FBF9F4] min-h-[780px]'
            : 'max-w-4xl px-4 sm:px-6 lg:px-8 pt-6'
        }`}
      >
        {/* Mobile Header in Frame */}
        <div className="bg-[#234415] text-white p-4 rounded-b-2xl shadow-sm flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-[#355B23] border border-[#527F3B] flex items-center justify-center font-bold text-sm text-[#F3E7C4]">
              {profile.name.charAt(0)}
            </div>
            <div>
              <h2 className="text-sm font-bold leading-tight font-display">
                {profile.name}
              </h2>
              <div className="flex items-center gap-1 text-[11px] text-[#D8E8CA]">
                <MapPin className="w-3 h-3 text-[#E2BC63]" />
                <span>{profile.village}, {profile.district}</span>
              </div>
            </div>
          </div>

          <div className="text-right">
            <div className="flex items-center gap-1 justify-end">
              <CloudSun className="w-4 h-4 text-[#F5CA5B]" />
              <span className="text-sm font-extrabold tabular-nums">28°C</span>
            </div>
            <span className="text-[10px] text-[#CADBBD] block">
              Partly Sunny · 74% Humidity
            </span>
          </div>
        </div>

        {/* ========================================================
            SUB-SCREEN 1: TODAY'S BRIEFING (HOME)
           ======================================================== */}
        {activeTab === 'home' && (
          <div className="space-y-4">
            
            {/* ONE CLEAR "ACTION PLAN FOR TODAY" CARD */}
            <div className="bg-gradient-to-br from-[#234415] to-[#172E0E] text-white rounded-2xl p-5 shadow-md relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#42722C]/20 rounded-full blur-2xl pointer-events-none" />
              
              <div className="flex items-center justify-between mb-2">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-[#F5CA5B] text-[#234415] text-[11px] font-extrabold rounded-md shadow-xs">
                  <Sparkles className="w-3 h-3" />
                  <span>{t.actionPlan}</span>
                </div>
                <span className="text-[11px] text-[#CADBBD] font-mono">
                  Today · Oct 2026
                </span>
              </div>

              <h3 className="text-lg font-bold font-display leading-snug">
                Morning Spray Window (7:30 AM - 10:30 AM)
              </h3>

              <p className="text-xs text-[#E1EED7] mt-1.5 leading-relaxed">
                Apply micronutrient / bio-pesticide spray before midday heat builds up. 
                <strong className="text-white"> Hold off heavy canal irrigation </strong> 
                because a light evening shower (25% chance) is expected.
              </p>

              <div className="mt-4 pt-3 border-t border-white/15 flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs">
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  <span className="text-[#E2EFD8]">Spray Status: <strong>Optimal Window</strong></span>
                </div>
                <button
                  onClick={() => setActiveTab('chat')}
                  className="px-3 py-1 bg-white/15 hover:bg-white/25 text-white rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors"
                >
                  <span>Ask Mitra</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Quick Stat Cards Row */}
            <div className="grid grid-cols-2 gap-3">
              {/* Weather & Soil Moisture */}
              <div className="bg-white p-3.5 rounded-2xl border border-[#DFD8C7] shadow-xs space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-semibold text-[#66775F] uppercase">
                    Soil Moisture
                  </span>
                  <Droplets className="w-4 h-4 text-[#2E689C]" />
                </div>
                <div className="text-xl font-extrabold text-[#192E11] tabular-nums">
                  34% <span className="text-xs font-normal text-[#5B6D51]">Adequate</span>
                </div>
                <p className="text-[10px] text-[#71826B]">
                  Next irrigation cycle recommended in 4 days
                </p>
              </div>

              {/* Disease Risk Badge */}
              <div className="bg-white p-3.5 rounded-2xl border border-[#DFD8C7] shadow-xs space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-semibold text-[#66775F] uppercase">
                    {t.diseaseRisk}
                  </span>
                  <AlertTriangle className="w-4 h-4 text-[#C85A32]" />
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xl font-extrabold text-[#9E3E1C]">
                    Low - Moderate
                  </span>
                </div>
                <p className="text-[10px] text-[#71826B]">
                  Fungal spore risk elevated due to 74% humidity
                </p>
              </div>
            </div>

            {/* Current Active Crop Status */}
            <div className="bg-white rounded-2xl p-4 border border-[#DFD8C7] shadow-xs">
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#35482D] flex items-center gap-1.5">
                  <Sprout className="w-4 h-4 text-[#234415]" />
                  <span>Enrolled Crops & Growth Stage</span>
                </h4>
                <button
                  onClick={() => setActiveTab('predict')}
                  className="text-xs text-[#2D5818] font-bold hover:underline"
                >
                  Plan Next Crop →
                </button>
              </div>

              <div className="space-y-2.5">
                <div className="p-3 bg-[#FAF8F3] rounded-xl border border-[#E9E4D7] flex items-center justify-between">
                  <div>
                    <h5 className="text-xs font-bold text-[#1C2C16]">
                      Soybean (JS-9560 Certified)
                    </h5>
                    <p className="text-[11px] text-[#697A62]">
                      Stage: Pod Filling (Week 9) · Health: Good
                    </p>
                  </div>
                  <span className="text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-md">
                    Healthy
                  </span>
                </div>

                <div className="p-3 bg-[#FAF8F3] rounded-xl border border-[#E9E4D7] flex items-center justify-between">
                  <div>
                    <h5 className="text-xs font-bold text-[#1C2C16]">
                      Rabi Wheat (Sharbati Gold)
                    </h5>
                    <p className="text-[11px] text-[#697A62]">
                      Stage: Field Preparation & Pre-Sowing Irrigation
                    </p>
                  </div>
                  <span className="text-[11px] font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-md">
                    Sowing in 12d
                  </span>
                </div>
              </div>
            </div>

            {/* Quick Mandi Rates Ticker for nearest APMC */}
            <div className="bg-white rounded-2xl p-4 border border-[#DFD8C7] shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#35482D] flex items-center gap-1.5">
                  <TrendingUp className="w-4 h-4 text-[#234415]" />
                  <span>Nearest APMC Mandi Rates</span>
                </h4>
                <span className="text-[10px] text-[#71826B]">Updated 1h ago</span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                {MOCK_MANDI_PRICES.slice(0, 2).map((item) => (
                  <div
                    key={item.id}
                    className="p-2.5 rounded-xl bg-[#F8F6EF] border border-[#E7E1D2]"
                  >
                    <div className="flex items-baseline justify-between">
                      <span className="text-[11px] font-bold text-[#1C2C16] truncate">
                        {item.commodity.split('(')[0]}
                      </span>
                      <span className="text-[10px] text-emerald-700 font-bold">
                        ▲ {item.changePercent}%
                      </span>
                    </div>
                    <div className="text-sm font-extrabold text-[#234415] tabular-nums mt-0.5">
                      ₹{item.modalPrice} <span className="text-[10px] font-normal text-[#64755E]">/ Q</span>
                    </div>
                    <span className="text-[9px] text-[#86977F] block truncate">
                      {item.mandi}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Action Bar / Fast Nav */}
            <div className="grid grid-cols-2 gap-3 pt-1">
              <button
                onClick={() => setActiveTab('disease')}
                className="p-3.5 bg-[#FAF3E8] hover:bg-[#F3E5CE] border border-[#EAD8BD] rounded-2xl text-left transition-colors flex items-center gap-3 min-h-[52px]"
              >
                <div className="w-9 h-9 rounded-xl bg-[#895719] text-white flex items-center justify-center shrink-0">
                  <ScanEye className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-[#3B2912]">Check Leaf Disease</h4>
                  <p className="text-[10px] text-[#816E53]">Scan with camera</p>
                </div>
              </button>

              <button
                onClick={() => setActiveTab('chat')}
                className="p-3.5 bg-[#EAF2E4] hover:bg-[#DEEBD5] border border-[#CCE0BE] rounded-2xl text-left transition-colors flex items-center gap-3 min-h-[52px]"
              >
                <div className="w-9 h-9 rounded-xl bg-[#234415] text-white flex items-center justify-center shrink-0">
                  <Mic className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-[#1A330F]">Voice Krishi Mitra</h4>
                  <p className="text-[10px] text-[#55694C]">Speak in your language</p>
                </div>
              </button>
            </div>

            {/* Sarkari Yojna & Certified Shops Quick Access Card */}
            <div className="bg-gradient-to-r from-[#FAF0E1] via-[#FDF7EE] to-[#F5EAD4] p-4 rounded-2xl border border-[#ECD9BD] shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#895719] text-white flex items-center justify-center shrink-0 shadow-xs">
                  <Landmark className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-[#2A1D0B] font-display">
                    Sarkari Yojna, KCC Loans & Certified Agri-Shops
                  </h4>
                  <p className="text-[11px] text-[#695439]">
                    PM-KISAN, PMFBY insurance, 4% KCC credit & certified seed/fertilizer outlets in {profile.district}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActiveTab('schemes')}
                className="px-3.5 py-1.5 bg-[#895719] hover:bg-[#6D420F] active:scale-[0.99] text-white text-xs font-bold rounded-xl whitespace-nowrap transition-colors flex items-center justify-center gap-1 min-h-[36px]"
              >
                <span>View Schemes & Shops</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* ========================================================
            SUB-SCREEN 2: CROP PREDICTION WITH N-P-K-pH-CLIMATE & GRAPHS
           ======================================================== */}
        {activeTab === 'predict' && (
          <CropPredictionAnalysisView />
        )}

        {/* ========================================================
            SUB-SCREEN: SARKARI YOJNA, BANK LOANS & CERTIFIED SHOPS
           ======================================================== */}
        {activeTab === 'schemes' && (
          <GovtSchemesAndShopsView profile={profile} />
        )}

        {/* ========================================================
            SUB-SCREEN 3: KRISHI MITRA AI CHATBOT (DEDICATED VIEW)
           ======================================================== */}
        {activeTab === 'chat' && (
          <div className="bg-white rounded-2xl border border-[#DFD8C7] shadow-sm flex flex-col h-[560px] overflow-hidden">
            {/* Krishi Mitra Dedicated Header */}
            <div className="p-3.5 bg-[#FAF8F3] border-b border-[#E7E2D5] flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <img
                    src="/src/assets/images/krishi_mitra_advisor_1791000544985.jpg"
                    alt="Krishi Mitra agricultural advisor"
                    className="w-10 h-10 rounded-full object-cover border-2 border-[#234415]"
                    referrerPolicy="no-referrer"
                  />
                  <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full border-2 border-white" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-[#1A2E12] font-display flex items-center gap-1.5">
                    <span>Krishi Mitra AI Advisor</span>
                    <span className="text-[10px] text-emerald-800 bg-emerald-100 px-1.5 py-0.2 rounded font-mono">
                      Online
                    </span>
                  </h4>
                  <p className="text-[11px] text-[#66775F]">
                    Local Agronomist · Ready to speak in {selectedLanguage.toUpperCase()}
                  </p>
                </div>
              </div>

              {/* Language Tag */}
              <button
                onClick={() => onLanguageChange(selectedLanguage === 'hi' ? 'en' : 'hi')}
                className="text-[11px] font-bold text-[#234415] bg-[#E8EFE2] px-2.5 py-1 rounded-lg border border-[#D0DEC4]"
              >
                Lang: {selectedLanguage.toUpperCase()}
              </button>
            </div>

            {/* Quick Prompt Chips */}
            <div className="px-3 py-2 bg-[#F6F3EA] border-b border-[#EBE6D9] overflow-x-auto flex items-center gap-1.5 no-scrollbar">
              {QUICK_PROMPTS.map((prompt) => (
                <button
                  key={prompt.label}
                  onClick={() => sendUserMessage(prompt.label)}
                  className="px-2.5 py-1 bg-white hover:bg-[#ECE6D7] rounded-full text-[11px] font-medium text-[#384831] border border-[#DCD5C4] whitespace-nowrap shrink-0 transition-colors"
                >
                  {prompt.label}
                </button>
              ))}
            </div>

            {/* Chat Message Feed */}
            <div className="flex-1 p-4 overflow-y-auto space-y-3.5 bg-[#FAF8F3]">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex items-start gap-2.5 ${
                    msg.sender === 'user' ? 'justify-end' : 'justify-start'
                  }`}
                >
                  {msg.sender === 'mitra' && (
                    <img
                      src="/src/assets/images/krishi_mitra_advisor_1791000544985.jpg"
                      alt="Mitra avatar"
                      className="w-7 h-7 rounded-full object-cover border border-[#234415] shrink-0 mt-0.5"
                      referrerPolicy="no-referrer"
                    />
                  )}

                  <div
                    className={`max-w-[82%] rounded-2xl p-3 text-xs leading-relaxed ${
                      msg.sender === 'user'
                        ? 'bg-[#234415] text-white rounded-br-xs shadow-xs'
                        : 'bg-white text-[#192E11] border border-[#DFD8C7] rounded-bl-xs shadow-xs'
                    }`}
                  >
                    <p>{msg.text}</p>

                    <div className="mt-1.5 flex items-center justify-between text-[10px] opacity-70">
                      <span>{msg.timestamp}</span>

                      {/* Text-to-speech audio button for Mitra's responses */}
                      {msg.sender === 'mitra' && (
                        <button
                          onClick={() => handlePlayVoice(msg.id, msg.text)}
                          className="flex items-center gap-1 text-[#234415] font-bold hover:underline ml-2"
                          title="Listen to response"
                        >
                          <Volume2
                            className={`w-3.5 h-3.5 ${
                              audioPlayingId === msg.id ? 'text-emerald-600 animate-bounce' : ''
                            }`}
                          />
                          <span>{audioPlayingId === msg.id ? 'Playing...' : 'Listen'}</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}

              {isThinking && (
                <div className="flex items-center gap-2 text-xs text-[#6F8168] italic p-2">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#234415]" />
                  <span>Krishi Mitra is formulating agricultural advice...</span>
                </div>
              )}
            </div>

            {/* Input Bar with Voice Toggle prominent */}
            <div className="p-3 bg-white border-t border-[#E7E2D5]">
              {isRecording ? (
                <div className="p-3 bg-[#FAF0E1] border border-[#EBDCC5] rounded-xl flex items-center justify-between animate-pulse">
                  <div className="flex items-center gap-2 text-xs font-bold text-[#895719]">
                    <span className="w-3 h-3 rounded-full bg-red-600 animate-ping"></span>
                    <span>Listening in your language... Speak now</span>
                  </div>
                  <button
                    onClick={() => setIsRecording(false)}
                    className="text-xs font-bold text-[#895719] hover:underline"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    sendUserMessage();
                  }}
                  className="flex items-center gap-2"
                >
                  {/* Dedicated Voice Button */}
                  <button
                    type="button"
                    onClick={handleToggleVoiceRecord}
                    className="w-11 h-11 rounded-xl bg-[#E8EFE2] hover:bg-[#D5E3CD] text-[#234415] flex items-center justify-center transition-colors shrink-0 shadow-xs border border-[#CDE0C1]"
                    title="Speak your question"
                  >
                    <Mic className="w-5 h-5 text-[#234415]" />
                  </button>

                  <input
                    type="text"
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder={t.askMitra}
                    className="flex-1 px-3.5 py-2.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-semibold text-[#182C10] focus:ring-2 focus:ring-[#234415] focus:outline-none min-h-[44px]"
                  />

                  <button
                    type="submit"
                    disabled={!inputText.trim()}
                    className="w-11 h-11 rounded-xl bg-[#234415] hover:bg-[#1A3410] disabled:opacity-40 text-white flex items-center justify-center transition-colors shrink-0 shadow-xs"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              )}
            </div>
          </div>
        )}

        {/* ========================================================
            SUB-SCREEN 4: DISEASE DETECTION (CAMERA / IMAGE FOCAL POINT)
           ======================================================== */}
        {activeTab === 'disease' && (
          <div className="space-y-4">
            <div className="bg-white p-4 rounded-2xl border border-[#DFD8C7] shadow-xs">
              <div className="flex items-center gap-2 mb-1">
                <div className="w-7 h-7 rounded-lg bg-[#FAF0E1] text-[#895719] flex items-center justify-center">
                  <ScanEye className="w-4 h-4" />
                </div>
                <h3 className="text-base font-bold text-[#192E11] font-display">
                  Plant Doctor · Instant Leaf Diagnostic
                </h3>
              </div>
              <p className="text-xs text-[#5C6E52]">
                Upload or snap a clear photo of an affected leaf. The AI model checks for fungal, bacterial, or nutrient deficiencies and provides organic remedies.
              </p>
            </div>

            {/* Focal Point: Camera / Image Upload Container */}
            <div className="bg-white rounded-2xl border-2 border-dashed border-[#CFC5B2] p-5 text-center relative overflow-hidden">
              {diseaseImage ? (
                <div className="space-y-3">
                  <div className="relative mx-auto max-w-sm rounded-xl overflow-hidden shadow-sm border border-[#DCD5C4]">
                    <img
                      src={diseaseImage}
                      alt="Crop disease leaf diagnosis sample"
                      className="w-full h-56 object-cover"
                      referrerPolicy="no-referrer"
                    />

                    {/* Scanning Optical Animation */}
                    {isScanning && (
                      <div className="absolute inset-0 bg-[#234415]/20 flex flex-col items-center justify-center">
                        <div className="w-full h-1 bg-emerald-400 shadow-lg shadow-emerald-400/50 animate-bounce" />
                        <span className="mt-4 px-3 py-1 bg-[#234415] text-white text-xs font-bold rounded-full">
                          Analyzing leaf pathology...
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-center gap-2">
                    <button
                      type="button"
                      onClick={handleScanSample}
                      disabled={isScanning}
                      className="px-4 py-2 bg-[#234415] hover:bg-[#1A3410] text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors min-h-[44px]"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
                      <span>{isScanning ? 'Analyzing...' : 'Re-Analyze Leaf'}</span>
                    </button>

                    <label className="px-4 py-2 bg-[#EFECE1] hover:bg-[#E5E1D2] text-[#34452B] text-xs font-semibold rounded-xl flex items-center gap-1.5 cursor-pointer min-h-[44px]">
                      <Upload className="w-3.5 h-3.5" />
                      <span>Upload Other</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const url = URL.createObjectURL(file);
                            setDiseaseImage(url);
                            handleScanSample();
                          }
                        }}
                      />
                    </label>
                  </div>
                </div>
              ) : (
                <div className="py-8 space-y-3">
                  <div className="w-14 h-14 rounded-2xl bg-[#E8EFE2] text-[#234415] flex items-center justify-center mx-auto">
                    <Camera className="w-7 h-7" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-[#182C10]">
                      Capture or Upload Leaf Image
                    </h4>
                    <p className="text-xs text-[#71826B] mt-0.5">
                      Ensure natural lighting and hold steady 10-15 cm from leaf surface
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* DIAGNOSIS RESULTS IN PLAIN LANGUAGE */}
            {diseaseReport && (
              <div className="bg-white rounded-2xl border border-[#DFD8C7] p-5 shadow-sm space-y-4">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      {/* Simple confidence badge, not raw percentages alone */}
                      <span className="text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full border border-emerald-200">
                        {diseaseReport.confidence} · {diseaseReport.confidenceScore}% match
                      </span>
                      <span className="text-[11px] font-bold text-amber-800 bg-amber-100 px-2.5 py-0.5 rounded-full">
                        {diseaseReport.urgency}
                      </span>
                    </div>

                    <h4 className="text-lg font-bold text-[#182C10] font-display mt-2">
                      {diseaseReport.diseaseName}
                    </h4>
                    <p className="text-xs text-[#6F7F68] font-mono italic">
                      {diseaseReport.scientificName}
                    </p>
                  </div>
                </div>

                {/* Visible Symptoms */}
                <div>
                  <h5 className="text-xs font-bold uppercase tracking-wider text-[#35482D] mb-1.5">
                    Recognized Symptoms:
                  </h5>
                  <ul className="text-xs text-[#3E5036] space-y-1">
                    {diseaseReport.symptoms.map((s, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-[#C85A32]">•</span>
                        <span>{s}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Treatment Suggestions */}
                <div className="space-y-3 pt-2">
                  {/* Organic Remedy */}
                  <div className="p-3.5 bg-[#EAF2E4] rounded-xl border border-[#CCE0BE]">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-[#1E3B13] mb-1">
                      <Sprout className="w-4 h-4 text-[#234415]" />
                      <span>Step 1: Organic & Safe Remedy</span>
                    </div>
                    <p className="text-xs text-[#2A441F] leading-relaxed">
                      {diseaseReport.organicRemedy}
                    </p>
                  </div>

                  {/* Chemical Remedy if spreading */}
                  <div className="p-3.5 bg-[#FAF3E8] rounded-xl border border-[#EBDCC5]">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-[#895719] mb-1">
                      <AlertTriangle className="w-4 h-4 text-[#895719]" />
                      <span>Step 2: Emergency Chemical Control (if &gt;20% plot affected)</span>
                    </div>
                    <p className="text-xs text-[#4F3C26] leading-relaxed">
                      {diseaseReport.chemicalRemedy}
                    </p>
                  </div>

                  {/* Prevention */}
                  <div className="p-3 bg-[#FAF8F3] rounded-xl border border-[#E5DFD1] text-xs text-[#4A5B42]">
                    <strong>Prevention: </strong>
                    {diseaseReport.preventionAdvice}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ========================================================
            SUB-SCREEN 5: PROFILE
           ======================================================== */}
        {activeTab === 'profile' && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl border border-[#DFD8C7] p-5 shadow-xs">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-[#234415] text-[#F3E7C4] flex items-center justify-center font-bold text-2xl font-display shadow-sm">
                  {profile.name.charAt(0)}
                </div>
                <div>
                  <h3 className="text-xl font-bold text-[#182C10] font-display">
                    {profile.name}
                  </h3>
                  <p className="text-xs text-[#5D6F54] flex items-center gap-1 mt-0.5">
                    <MapPin className="w-3.5 h-3.5 text-[#E2BC63]" />
                    <span>Village {profile.village}, {profile.district}, {profile.state}</span>
                  </p>
                  <p className="text-xs text-[#71826B] font-mono mt-1">
                    Phone: +91 {profile.phone}
                  </p>
                </div>
              </div>
            </div>

            {/* Farm Particulars List */}
            <div className="bg-white rounded-2xl border border-[#DFD8C7] p-5 shadow-xs space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#35482D]">
                Farm Particulars & Holdings
              </h4>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-2 border-b border-[#F0ECE1]">
                  <span className="text-[#64765E]">Registered Land Size</span>
                  <span className="font-bold text-[#182C10]">{profile.landSizeAcres} Acres</span>
                </div>
                <div className="flex justify-between py-2 border-b border-[#F0ECE1]">
                  <span className="text-[#64765E]">Soil Type</span>
                  <span className="font-bold text-[#182C10]">{profile.soilType}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-[#F0ECE1]">
                  <span className="text-[#64765E]">Primary Crops</span>
                  <span className="font-bold text-[#182C10]">
                    {profile.primaryCrops.join(', ')}
                  </span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-[#64765E]">Soil Health Card</span>
                  <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                    Active (2026 Issued)
                  </span>
                </div>
              </div>
            </div>

            {/* Language Preference */}
            <div className="bg-white rounded-2xl border border-[#DFD8C7] p-5 shadow-xs space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#35482D]">
                Language Preference
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {LANGUAGES.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => onLanguageChange(lang.code)}
                    className={`p-2.5 rounded-xl border text-xs font-semibold text-left transition-all min-h-[44px] ${
                      selectedLanguage === lang.code
                        ? 'bg-[#234415] text-white border-[#234415]'
                        : 'bg-[#FAF8F3] text-[#34452B] border-[#DCD5C4]'
                    }`}
                  >
                    {lang.nativeName} ({lang.label})
                  </button>
                ))}
              </div>
            </div>

            {/* Advisory History */}
            <div className="bg-white rounded-2xl border border-[#DFD8C7] p-5 shadow-xs space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#35482D]">
                Recent AI Advisory History
              </h4>
              <div className="space-y-2 text-xs">
                <div className="p-2.5 rounded-xl bg-[#FAF8F3] border border-[#E9E4D7] flex justify-between items-center">
                  <div>
                    <span className="font-bold text-[#1C2C16] block">Early Blight Scan (Tomato)</span>
                    <span className="text-[10px] text-[#71826B]">Neem spray 5ml/L prescribed</span>
                  </div>
                  <span className="text-[10px] text-[#86977F]">Today</span>
                </div>
                <div className="p-2.5 rounded-xl bg-[#FAF8F3] border border-[#E9E4D7] flex justify-between items-center">
                  <div>
                    <span className="font-bold text-[#1C2C16] block">Wheat HI-8627 Yield Estimation</span>
                    <span className="text-[10px] text-[#71826B]">24 Q/acre projected for Rabi</span>
                  </div>
                  <span className="text-[10px] text-[#86977F]">3 days ago</span>
                </div>
              </div>
            </div>

            {/* Switch to Dealer View for testing */}
            <div className="pt-2">
              <button
                type="button"
                onClick={onSwitchToDealer}
                className="w-full py-3 bg-[#FAF0E1] hover:bg-[#F3E5CE] text-[#895719] text-xs font-bold rounded-xl border border-[#ECD9BD] transition-colors min-h-[44px]"
              >
                Switch to Dealer Console Preview →
              </button>
            </div>
          </div>
        )}

      </div>

      {/* FIXED BOTTOM TAB BAR (MOBILE-FIRST ANCHOR) */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#FBF9F4]/95 backdrop-blur-md border-t border-[#DFD8C7] py-1.5 shadow-lg">
        <div className="max-w-lg mx-auto grid grid-cols-6 items-center px-1">
          
          {/* Tab 1: Home */}
          <button
            onClick={() => setActiveTab('home')}
            className={`flex flex-col items-center justify-center min-h-[48px] py-1 transition-colors ${
              activeTab === 'home' ? 'text-[#234415]' : 'text-[#687960] hover:text-[#234415]'
            }`}
          >
            <Home className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className={`text-[9px] sm:text-[10px] tracking-tight mt-1 truncate max-w-[54px] ${activeTab === 'home' ? 'font-bold' : 'font-medium'}`}>
              {t.home}
            </span>
          </button>

          {/* Tab 2: Crop Predict */}
          <button
            onClick={() => setActiveTab('predict')}
            className={`flex flex-col items-center justify-center min-h-[48px] py-1 transition-colors ${
              activeTab === 'predict' ? 'text-[#234415]' : 'text-[#687960] hover:text-[#234415]'
            }`}
          >
            <Sprout className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className={`text-[9px] sm:text-[10px] tracking-tight mt-1 truncate max-w-[54px] ${activeTab === 'predict' ? 'font-bold' : 'font-medium'}`}>
              {t.predict}
            </span>
          </button>

          {/* Tab 3: Krishi Mitra (Focal AI Hub) */}
          <button
            onClick={() => setActiveTab('chat')}
            className="flex flex-col items-center justify-center min-h-[48px] -mt-3 group"
          >
            <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center shadow-md transition-transform group-active:scale-95 ${
              activeTab === 'chat' ? 'bg-[#234415] text-white ring-4 ring-[#E8EFE2]' : 'bg-[#E8EFE2] text-[#234415] border-2 border-[#234415]'
            }`}>
              <Mic className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <span className="text-[9px] sm:text-[10px] font-bold text-[#234415] tracking-tight mt-0.5">
              Mitra AI
            </span>
          </button>

          {/* Tab 4: Plant Doctor / Disease */}
          <button
            onClick={() => setActiveTab('disease')}
            className={`flex flex-col items-center justify-center min-h-[48px] py-1 transition-colors ${
              activeTab === 'disease' ? 'text-[#234415]' : 'text-[#687960] hover:text-[#234415]'
            }`}
          >
            <ScanEye className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className={`text-[9px] sm:text-[10px] tracking-tight mt-1 truncate max-w-[54px] ${activeTab === 'disease' ? 'font-bold' : 'font-medium'}`}>
              {t.disease}
            </span>
          </button>

          {/* Tab 5: Sarkari Yojna & Shops */}
          <button
            onClick={() => setActiveTab('schemes')}
            className={`flex flex-col items-center justify-center min-h-[48px] py-1 transition-colors ${
              activeTab === 'schemes' ? 'text-[#234415]' : 'text-[#687960] hover:text-[#234415]'
            }`}
          >
            <Landmark className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className={`text-[9px] sm:text-[10px] tracking-tight mt-1 truncate max-w-[54px] ${activeTab === 'schemes' ? 'font-bold text-[#234415]' : 'font-medium'}`}>
              {t.schemes}
            </span>
          </button>

          {/* Tab 6: Profile */}
          <button
            onClick={() => setActiveTab('profile')}
            className={`flex flex-col items-center justify-center min-h-[48px] py-1 transition-colors ${
              activeTab === 'profile' ? 'text-[#234415]' : 'text-[#687960] hover:text-[#234415]'
            }`}
          >
            <User className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className={`text-[9px] sm:text-[10px] tracking-tight mt-1 truncate max-w-[54px] ${activeTab === 'profile' ? 'font-bold' : 'font-medium'}`}>
              {t.profile}
            </span>
          </button>

        </div>
      </nav>
    </div>
  );
};
