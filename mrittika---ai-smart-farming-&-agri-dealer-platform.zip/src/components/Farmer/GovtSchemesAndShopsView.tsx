import React, { useState } from 'react';
import { GovtScheme, CertifiedShop, FarmerProfile } from '../../types';
import { MOCK_GOVT_SCHEMES, MOCK_CERTIFIED_SHOPS } from '../../data/schemesAndShopsData';
import {
  Landmark,
  ShieldCheck,
  CreditCard,
  Store,
  Search,
  Phone,
  ExternalLink,
  CheckCircle2,
  FileText,
  BadgePercent,
  MapPin,
  Clock,
  Sparkles,
  ChevronRight,
  Calculator,
  X,
  PhoneCall,
  Check,
  HelpCircle
} from 'lucide-react';

interface GovtSchemesAndShopsViewProps {
  profile: FarmerProfile;
}

export const GovtSchemesAndShopsView: React.FC<GovtSchemesAndShopsViewProps> = ({ profile }) => {
  const [activeCategory, setActiveCategory] = useState<
    'all' | 'welfare' | 'loans' | 'shops'
  >('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Selected Scheme for detailed modal
  const [selectedScheme, setSelectedScheme] = useState<GovtScheme | null>(null);

  // KCC Loan Calculator State
  const [kccLoanAmount, setKccLoanAmount] = useState<number>(150000);
  const [showLoanCalc, setShowLoanCalc] = useState<boolean>(false);

  // Filter schemes
  const filteredSchemes = MOCK_GOVT_SCHEMES.filter((scheme) => {
    const matchesCategory =
      activeCategory === 'all' ||
      (activeCategory === 'welfare' &&
        (scheme.category === 'Welfare Yojna' ||
          scheme.category === 'Crop Insurance' ||
          scheme.category === 'Subsidy & Machinery')) ||
      (activeCategory === 'loans' && scheme.category === 'Bank Loan & Credit');

    const matchesSearch =
      scheme.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      scheme.hindiTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      scheme.benefit.toLowerCase().includes(searchQuery.toLowerCase()) ||
      scheme.category.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesCategory && matchesSearch;
  });

  // Filter shops
  const filteredShops = MOCK_CERTIFIED_SHOPS.filter((shop) => {
    const matchesCategory = activeCategory === 'all' || activeCategory === 'shops';
    const matchesSearch =
      shop.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      shop.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
      shop.inStockBadges.some((b) => b.toLowerCase().includes(searchQuery.toLowerCase())) ||
      shop.affiliation.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesCategory && matchesSearch;
  });

  // KCC Calculation: 7% base, 3% prompt subvention = 4% effective interest
  const standardAnnualInterest = Math.round((kccLoanAmount * 7) / 100);
  const subsidizedAnnualInterest = Math.round((kccLoanAmount * 4) / 100);
  const annualSavings = standardAnnualInterest - subsidizedAnnualInterest;

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-white p-5 rounded-2xl border border-[#DFD8C7] shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-[#E8EFE2] text-[#234415] flex items-center justify-center font-bold">
                <Landmark className="w-5 h-5 text-[#234415]" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-[#182C10] font-display">
                  Sarkari Yojna, Bank Loans & Certified Agri-Shops
                </h2>
                <p className="text-[11px] text-[#5C6E52]">
                  सरकारी योजनाएं, केसीसी रियायती ऋण एवं प्रमाणित बीज/खाद केंद्र ({profile.district}, {profile.state})
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowLoanCalc(!showLoanCalc)}
              className="px-3 py-1.5 bg-[#FAF0E1] hover:bg-[#F3E2CB] text-[#895719] text-xs font-bold rounded-xl border border-[#EBDCC5] flex items-center gap-1.5 transition-colors"
            >
              <Calculator className="w-4 h-4" />
              <span>{showLoanCalc ? 'Hide KCC Calculator' : 'KCC Loan Calculator'}</span>
            </button>
          </div>
        </div>

        {/* Search & Category Filter Navigation */}
        <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 border-t border-[#F0EBE0]">
          {/* Category Tabs */}
          <div className="flex items-center gap-1 p-1 bg-[#EFECE1] rounded-xl border border-[#DFD9C8] overflow-x-auto">
            <button
              onClick={() => setActiveCategory('all')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                activeCategory === 'all'
                  ? 'bg-white text-[#1E3612] shadow-xs font-bold'
                  : 'text-[#53614B] hover:text-[#1E3612]'
              }`}
            >
              All Facilities (सभी)
            </button>
            <button
              onClick={() => setActiveCategory('welfare')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                activeCategory === 'welfare'
                  ? 'bg-white text-[#1E3612] shadow-xs font-bold'
                  : 'text-[#53614B] hover:text-[#1E3612]'
              }`}
            >
              Welfare Yojna
            </button>
            <button
              onClick={() => setActiveCategory('loans')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                activeCategory === 'loans'
                  ? 'bg-white text-[#1E3612] shadow-xs font-bold'
                  : 'text-[#53614B] hover:text-[#1E3612]'
              }`}
            >
              Bank & KCC Loans
            </button>
            <button
              onClick={() => setActiveCategory('shops')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                activeCategory === 'shops'
                  ? 'bg-white text-[#1E3612] shadow-xs font-bold'
                  : 'text-[#53614B] hover:text-[#1E3612]'
              }`}
            >
              Certified Shops
            </button>
          </div>

          {/* Search input */}
          <div className="relative min-w-[220px]">
            <Search className="w-3.5 h-3.5 text-[#7E8D77] absolute left-3 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search yojana, loan, seeds, urea..."
              className="w-full pl-8 pr-3 py-1.5 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-semibold text-[#182C10] focus:ring-2 focus:ring-[#234415] focus:outline-none min-h-[38px]"
            />
          </div>
        </div>
      </div>

      {/* ========================================================
          INTERACTIVE KISAN CREDIT CARD (KCC) LOAN CALCULATOR
         ======================================================== */}
      {showLoanCalc && (
        <div className="bg-[#FAF3E8] p-5 rounded-2xl border border-[#ECD9BD] shadow-xs space-y-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-[#895719]" />
              <h3 className="text-sm font-bold text-[#2A1D0B] font-display">
                Kisan Credit Card (KCC) Concessional Loan Calculator
              </h3>
            </div>
            <span className="text-[11px] font-bold text-[#895719] bg-white px-2.5 py-0.5 rounded-full border border-[#E8D6BD]">
              4% Effective Annual Interest
            </span>
          </div>

          <div className="grid md:grid-cols-12 gap-6 items-center">
            <div className="md:col-span-7 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-[#3B2B16]">Crop Loan Requirement</span>
                <span className="font-mono font-extrabold text-base text-[#895719] tabular-nums">
                  ₹{kccLoanAmount.toLocaleString('en-IN')}
                </span>
              </div>
              <input
                type="range"
                min="25000"
                max="300000"
                step="5000"
                value={kccLoanAmount}
                onChange={(e) => setKccLoanAmount(Number(e.target.value))}
                className="w-full accent-[#895719]"
              />
              <div className="flex justify-between text-[10px] text-[#867560]">
                <span>₹25,000 (Small Crop)</span>
                <span>₹1,60,000 (No Collateral Limit)</span>
                <span>₹3,00,000 (Subsidized Cap)</span>
              </div>
            </div>

            <div className="md:col-span-5 grid grid-cols-2 gap-2 text-xs">
              <div className="p-3 bg-white rounded-xl border border-[#EBDCC5]">
                <span className="text-[10px] text-[#786750] block">Yearly Interest (4%)</span>
                <span className="text-base font-extrabold text-[#234415] tabular-nums block mt-0.5">
                  ₹{subsidizedAnnualInterest.toLocaleString('en-IN')}
                </span>
                <span className="text-[9px] text-[#697A62]">With 3% prompt rebate</span>
              </div>

              <div className="p-3 bg-white rounded-xl border border-[#EBDCC5]">
                <span className="text-[10px] text-[#786750] block">Govt. Subvention Savings</span>
                <span className="text-base font-extrabold text-[#895719] tabular-nums block mt-0.5">
                  +₹{annualSavings.toLocaleString('en-IN')}
                </span>
                <span className="text-[9px] text-[#697A62]">Saved vs commercial loans</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          SECTION 1: GOVERNMENT WELFARE & LOAN SCHEMES
         ======================================================== */}
      {(activeCategory === 'all' || activeCategory === 'welfare' || activeCategory === 'loans') && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#234415]"></span>
              <h3 className="text-sm font-bold text-[#182C10] font-display">
                Government Welfare & Bank Credit Schemes
              </h3>
            </div>
            <span className="text-[11px] text-[#71826B]">
              Showing {filteredSchemes.length} verified schemes
            </span>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            {filteredSchemes.map((scheme) => (
              <div
                key={scheme.id}
                className="bg-white rounded-2xl border border-[#DFD8C7] p-5 shadow-xs flex flex-col justify-between hover:border-[#234415] transition-colors"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                          scheme.category === 'Welfare Yojna'
                            ? 'bg-emerald-100 text-emerald-900 border border-emerald-200'
                            : scheme.category === 'Bank Loan & Credit'
                            ? 'bg-amber-100 text-amber-900 border border-amber-200'
                            : 'bg-blue-100 text-blue-900 border border-blue-200'
                        }`}
                      >
                        {scheme.category}
                      </span>
                      <h4 className="text-sm font-bold text-[#182C10] font-display mt-1.5 leading-snug">
                        {scheme.title}
                      </h4>
                      <p className="text-[11px] text-[#607357] font-medium">
                        {scheme.hindiTitle}
                      </p>
                    </div>

                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#E8EFE2] text-[#234415] whitespace-nowrap">
                      {scheme.status}
                    </span>
                  </div>

                  <p className="text-xs text-[#3E5036] leading-relaxed">
                    {scheme.benefit}
                  </p>

                  <div className="p-3 bg-[#FAF8F3] rounded-xl border border-[#EAE3D4] space-y-1 text-xs">
                    <div className="flex items-center gap-1.5 text-[#234415] font-bold">
                      <BadgePercent className="w-3.5 h-3.5" />
                      <span>{scheme.subsidyAmount}</span>
                    </div>
                    <p className="text-[11px] text-[#607357]">
                      <strong>Eligibility: </strong>{scheme.eligibility}
                    </p>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-[#EFECE1] flex items-center justify-between">
                  <div className="text-[10px] text-[#71826B]">
                    Helpline: <strong>{scheme.helpline.split('/')[0]}</strong>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setSelectedScheme(scheme)}
                      className="px-3 py-1.5 bg-[#234415] hover:bg-[#1A3410] text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1 min-h-[36px]"
                    >
                      <span>Check & Apply</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================
          SECTION 2: NEARBY CERTIFIED SEED, FERTILIZER & CROP SHOPS
         ======================================================== */}
      {(activeCategory === 'all' || activeCategory === 'shops') && (
        <div className="space-y-4 pt-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#895719]"></span>
              <h3 className="text-sm font-bold text-[#2A1D0B] font-display">
                Nearby Government Affiliated & Certified Agri-Shops
              </h3>
            </div>
            <span className="text-[11px] text-[#786750]">
              Verified by Dept of Agriculture, {profile.district}
            </span>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredShops.map((shop) => (
              <div
                key={shop.id}
                className="bg-white rounded-2xl border border-[#DFD8C7] p-4 shadow-xs flex flex-col justify-between space-y-3 hover:border-[#895719] transition-colors"
              >
                <div className="space-y-2">
                  <div className="flex items-start justify-between gap-1">
                    <span className="text-[10px] font-bold text-[#895719] bg-[#FAF0E1] px-2 py-0.5 rounded border border-[#ECD9BE]">
                      {shop.type}
                    </span>
                    <span className="text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3 text-emerald-700" />
                      <span>{shop.distanceKm} km away</span>
                    </span>
                  </div>

                  <div>
                    <h4 className="text-sm font-bold text-[#182C10] font-display leading-tight">
                      {shop.name}
                    </h4>
                    <p className="text-[11px] text-[#786750] mt-0.5">
                      {shop.owner}
                    </p>
                  </div>

                  <div className="text-[10px] text-[#607357] font-mono bg-[#F9F7F0] p-2 rounded-lg border border-[#EAE3D4]">
                    Affiliation: {shop.affiliation}
                  </div>

                  {/* Available Stock Badges */}
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#687960] block mb-1">
                      Certified In-Stock Items:
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {shop.inStockBadges.map((badge, idx) => (
                        <span
                          key={idx}
                          className="text-[10px] font-semibold bg-[#E8EFE2] text-[#234415] px-2 py-0.5 rounded border border-[#D0DEC4]"
                        >
                          {badge}
                        </span>
                      ))}
                    </div>
                  </div>

                  <p className="text-[11px] text-[#786750] flex items-center gap-1 pt-1">
                    <MapPin className="w-3 h-3 text-[#E2BC63] shrink-0" />
                    <span className="truncate">{shop.address}</span>
                  </p>
                </div>

                <div className="pt-3 border-t border-[#EFECE1] flex items-center justify-between">
                  <a
                    href={`tel:${shop.phone}`}
                    className="px-3 py-1.5 bg-[#FAF0E1] hover:bg-[#F3E2CB] text-[#895719] text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors min-h-[36px]"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>Call Store</span>
                  </a>

                  <button
                    onClick={() => alert(`Directions mapped to ${shop.name} (${shop.address})`)}
                    className="px-3 py-1.5 bg-[#EFECE1] hover:bg-[#E5E1D2] text-[#3E4F36] text-xs font-semibold rounded-lg flex items-center gap-1 transition-colors min-h-[36px]"
                  >
                    <span>Get Directions</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Emergency Kisan Call Center Footer Card */}
      <div className="bg-[#234415] text-white p-5 rounded-2xl shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center shrink-0">
            <PhoneCall className="w-6 h-6 text-[#F5CA5B]" />
          </div>
          <div>
            <h4 className="text-sm font-bold font-display">
              Toll-Free Kisan Call Centre & Scheme Grievance
            </h4>
            <p className="text-xs text-[#D8E6CC]">
              Available 6:00 AM to 10:00 PM daily in 22 languages: <strong>1800-180-1551</strong>
            </p>
          </div>
        </div>

        <a
          href="tel:18001801551"
          className="px-4 py-2 bg-[#F5CA5B] hover:bg-[#E2B746] text-[#234415] text-xs font-bold rounded-xl whitespace-nowrap transition-colors min-h-[40px] flex items-center justify-center"
        >
          Call 1800-180-1551 Now
        </a>
      </div>

      {/* ========================================================
          MODAL: SCHEME ELIGIBILITY CHECK & DIRECT APPLICATION
         ======================================================== */}
      {selectedScheme && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-[#DFD8C7] space-y-4 max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-start justify-between border-b border-[#EFECE1] pb-3">
              <div>
                <span className="text-[10px] font-bold text-[#234415] bg-[#E8EFE2] px-2 py-0.5 rounded uppercase">
                  {selectedScheme.category}
                </span>
                <h3 className="text-base font-bold text-[#182C10] font-display mt-1">
                  {selectedScheme.title}
                </h3>
                <p className="text-xs text-[#607357]">
                  {selectedScheme.hindiTitle}
                </p>
              </div>

              <button
                onClick={() => setSelectedScheme(null)}
                className="p-1 rounded-lg hover:bg-stone-100 text-stone-500"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Farmer Profile Auto-Verification */}
            <div className="p-3 bg-[#EAF2E4] rounded-xl border border-[#CCE0BE] text-xs text-[#203D14] space-y-1">
              <div className="flex items-center gap-1.5 font-bold">
                <CheckCircle2 className="w-4 h-4 text-[#234415]" />
                <span>Farmer Profile Match: Eligible</span>
              </div>
              <p className="text-[11px] text-[#345127]">
                Applicant: <strong>{profile.name}</strong> ({profile.landSizeAcres} Acres in {profile.village}, {profile.district}). Your land and active crop profile meets the preliminary criterion.
              </p>
            </div>

            {/* Benefit Breakdown */}
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#35482D] mb-1">
                Scheme Entitlement & Benefit
              </h4>
              <p className="text-xs text-[#3E5036] leading-relaxed">
                {selectedScheme.benefit}
              </p>
            </div>

            {/* Document Checklist */}
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#35482D] mb-2">
                Required Verification Documents
              </h4>
              <div className="space-y-1.5">
                {selectedScheme.documentsRequired.map((doc, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-xs text-[#3E5036]">
                    <div className="w-4 h-4 rounded-full bg-[#E8EFE2] text-[#234415] flex items-center justify-center shrink-0">
                      <Check className="w-2.5 h-2.5" />
                    </div>
                    <span>{doc}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Helpline and Portal Link */}
            <div className="p-3 bg-[#FAF8F3] rounded-xl border border-[#EAE3D4] text-xs flex items-center justify-between">
              <div>
                <span className="text-[10px] text-[#786750] block">Official Portal</span>
                <span className="font-mono font-bold text-[#234415]">{selectedScheme.officialPortalUrl}</span>
              </div>
              <a
                href={selectedScheme.officialPortalUrl}
                target="_blank"
                rel="noreferrer"
                className="p-2 text-[#234415] hover:bg-[#E8EFE2] rounded-lg"
              >
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>

            {/* Action buttons */}
            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                onClick={() => setSelectedScheme(null)}
                className="px-4 py-2 text-xs font-semibold text-[#786750] hover:bg-[#F2ECE0] rounded-xl min-h-[40px]"
              >
                Close
              </button>

              <button
                onClick={() => {
                  alert(
                    `Application initiated for ${selectedScheme.title}. An SMS with your application tracking token has been sent to +91 ${profile.phone}.`
                  );
                  setSelectedScheme(null);
                }}
                className="px-4 py-2 bg-[#234415] hover:bg-[#1A3410] text-white text-xs font-bold rounded-xl shadow-xs min-h-[40px] flex items-center gap-1.5"
              >
                <span>Initiate e-Kisan Application</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
