import React, { useState } from 'react';
import { CropPredictionInput, CropPredictionAnalysis } from '../../types';
import { analyzeCropSuitability } from '../../utils/cropPrediction';
import {
  Sprout,
  Sparkles,
  TrendingUp,
  RefreshCw,
  Droplets,
  Thermometer,
  Wind,
  Layers,
  CheckCircle2,
  AlertTriangle,
  Info,
  Sliders,
  Calendar,
  IndianRupee
} from 'lucide-react';

export const CropPredictionAnalysisView: React.FC = () => {
  // Input State for all 7 parameters
  const [params, setParams] = useState<CropPredictionInput>({
    nitrogen: 110,
    phosphorus: 55,
    potassium: 42,
    ph: 6.8,
    temperature: 24,
    humidity: 62,
    rainfall: 80,
  });

  const [isCalculating, setIsCalculating] = useState(false);
  const [analysis, setAnalysis] = useState<CropPredictionAnalysis>(() =>
    analyzeCropSuitability({
      nitrogen: 110,
      phosphorus: 55,
      potassium: 42,
      ph: 6.8,
      temperature: 24,
      humidity: 62,
      rainfall: 80,
    })
  );

  const handleParamChange = (field: keyof CropPredictionInput, value: number) => {
    const updated = { ...params, [field]: value };
    setParams(updated);
    // Instant real-time or fast analysis
    setAnalysis(analyzeCropSuitability(updated));
  };

  const handleApplyPreset = (preset: {
    name: string;
    n: number;
    p: number;
    k: number;
    ph: number;
    temp: number;
    hum: number;
    rain: number;
  }) => {
    setIsCalculating(true);
    const newParams: CropPredictionInput = {
      nitrogen: preset.n,
      phosphorus: preset.p,
      potassium: preset.k,
      ph: preset.ph,
      temperature: preset.temp,
      humidity: preset.hum,
      rainfall: preset.rain,
    };
    setParams(newParams);
    setTimeout(() => {
      setAnalysis(analyzeCropSuitability(newParams));
      setIsCalculating(false);
    }, 300);
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-white p-5 rounded-2xl border border-[#DFD8C7] shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-[#E8EFE2] text-[#234415] flex items-center justify-center font-bold">
                <Sprout className="w-4 h-4" />
              </div>
              <h2 className="text-lg font-bold text-[#182C10] font-display">
                NPK & Climate Crop Suitability Predictor
              </h2>
            </div>
            <p className="text-xs text-[#5D7053] mt-1">
              Adjust soil nutrients (N, P, K, pH) and microclimate telemetry (Temp, Humidity, Rainfall) to forecast the highest-yielding crop with comparative analysis graphs.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold text-[#234415] bg-[#E8EFE2] px-2.5 py-1 rounded-full border border-[#D0DEC4]">
              ICAR Agro-Data Engine
            </span>
          </div>
        </div>

        {/* Quick Presets */}
        <div className="mt-4 pt-3 border-t border-[#F0EBE0]">
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#687960] block mb-2">
            Quick Pre-Sets:
          </span>
          <div className="flex flex-wrap gap-1.5">
            {[
              { name: 'Wheat Zone (Cool & Balanced NPK)', n: 120, p: 55, k: 40, ph: 6.8, temp: 20, hum: 58, rain: 75 },
              { name: 'Basmati Rice Belt (High Rain & Humidity)', n: 90, p: 48, k: 42, ph: 6.4, temp: 28, hum: 82, rain: 220 },
              { name: 'Yellow Mustard (Cool & Low Moisture)', n: 75, p: 40, k: 38, ph: 7.0, temp: 18, hum: 52, rain: 45 },
              { name: 'Bt Cotton (Warm & Black Soil)', n: 125, p: 50, k: 55, ph: 7.4, temp: 30, hum: 65, rain: 95 },
              { name: 'Desi Chickpea / Chana (Pulse Nitrogen-Fixing)', n: 30, p: 65, k: 80, ph: 7.2, temp: 21, hum: 48, rain: 50 },
            ].map((preset) => (
              <button
                key={preset.name}
                type="button"
                onClick={() => handleApplyPreset(preset)}
                className="px-2.5 py-1 bg-[#FAF8F3] hover:bg-[#EAE4D4] border border-[#DDD6C5] rounded-lg text-xs font-semibold text-[#3C4D34] transition-colors"
              >
                {preset.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Grid: Parameters Form (Left) & Prediction Overview (Right) */}
      <div className="grid lg:grid-cols-12 gap-6">
        
        {/* Left Column: Sliders for N, P, K, pH, Temp, Humidity, Rainfall */}
        <div className="lg:col-span-6 bg-white p-5 rounded-2xl border border-[#DFD8C7] shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-[#EFECE1] pb-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#35482D] flex items-center gap-1.5">
              <Sliders className="w-4 h-4 text-[#234415]" />
              <span>1. Enter Soil & Climate Telemetry</span>
            </h3>
            <span className="text-[11px] text-[#71826B]">Live recalculation</span>
          </div>

          <div className="space-y-4 text-xs">
            {/* 1. Nitrogen (N) */}
            <div className="space-y-1">
              <div className="flex justify-between items-center">
                <label className="font-bold text-[#182C10]">
                  Nitrogen (N)
                </label>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    value={params.nitrogen}
                    onChange={(e) => handleParamChange('nitrogen', Number(e.target.value))}
                    className="w-16 px-2 py-0.5 text-right font-mono font-bold text-xs bg-[#FAF8F3] border border-[#D5CDBC] rounded"
                  />
                  <span className="text-[10px] text-[#786750]">kg/ha</span>
                </div>
              </div>
              <input
                type="range"
                min="0"
                max="160"
                value={params.nitrogen}
                onChange={(e) => handleParamChange('nitrogen', Number(e.target.value))}
                className="w-full accent-[#234415]"
              />
              <div className="flex justify-between text-[10px] text-[#8C9C86]">
                <span>0 (Severely Low)</span>
                <span>80 (Medium)</span>
                <span>160 (High)</span>
              </div>
            </div>

            {/* 2. Phosphorus (P) */}
            <div className="space-y-1">
              <div className="flex justify-between items-center">
                <label className="font-bold text-[#182C10]">
                  Phosphorus (P)
                </label>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    value={params.phosphorus}
                    onChange={(e) => handleParamChange('phosphorus', Number(e.target.value))}
                    className="w-16 px-2 py-0.5 text-right font-mono font-bold text-xs bg-[#FAF8F3] border border-[#D5CDBC] rounded"
                  />
                  <span className="text-[10px] text-[#786750]">kg/ha</span>
                </div>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={params.phosphorus}
                onChange={(e) => handleParamChange('phosphorus', Number(e.target.value))}
                className="w-full accent-[#895719]"
              />
              <div className="flex justify-between text-[10px] text-[#8C9C86]">
                <span>0</span>
                <span>50 (Moderate)</span>
                <span>100</span>
              </div>
            </div>

            {/* 3. Potassium (K) */}
            <div className="space-y-1">
              <div className="flex justify-between items-center">
                <label className="font-bold text-[#182C10]">
                  Potassium (K)
                </label>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    value={params.potassium}
                    onChange={(e) => handleParamChange('potassium', Number(e.target.value))}
                    className="w-16 px-2 py-0.5 text-right font-mono font-bold text-xs bg-[#FAF8F3] border border-[#D5CDBC] rounded"
                  />
                  <span className="text-[10px] text-[#786750]">kg/ha</span>
                </div>
              </div>
              <input
                type="range"
                min="0"
                max="120"
                value={params.potassium}
                onChange={(e) => handleParamChange('potassium', Number(e.target.value))}
                className="w-full accent-[#55783A]"
              />
              <div className="flex justify-between text-[10px] text-[#8C9C86]">
                <span>0</span>
                <span>60</span>
                <span>120</span>
              </div>
            </div>

            {/* 4. Soil pH */}
            <div className="space-y-1">
              <div className="flex justify-between items-center">
                <label className="font-bold text-[#182C10]">
                  Soil pH Value
                </label>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    step="0.1"
                    value={params.ph}
                    onChange={(e) => handleParamChange('ph', Number(e.target.value))}
                    className="w-16 px-2 py-0.5 text-right font-mono font-bold text-xs bg-[#FAF8F3] border border-[#D5CDBC] rounded"
                  />
                  <span className="text-[10px] text-[#786750]">pH</span>
                </div>
              </div>
              <input
                type="range"
                min="4.0"
                max="9.0"
                step="0.1"
                value={params.ph}
                onChange={(e) => handleParamChange('ph', Number(e.target.value))}
                className="w-full accent-[#C85A32]"
              />
              <div className="flex justify-between text-[10px] text-[#8C9C86]">
                <span>4.0 (Acidic)</span>
                <span>7.0 (Neutral)</span>
                <span>9.0 (Alkaline)</span>
              </div>
            </div>

            {/* 5. Temperature */}
            <div className="space-y-1">
              <div className="flex justify-between items-center">
                <label className="font-bold text-[#182C10] flex items-center gap-1">
                  <Thermometer className="w-3.5 h-3.5 text-[#C85A32]" />
                  <span>Ambient Temperature</span>
                </label>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    value={params.temperature}
                    onChange={(e) => handleParamChange('temperature', Number(e.target.value))}
                    className="w-16 px-2 py-0.5 text-right font-mono font-bold text-xs bg-[#FAF8F3] border border-[#D5CDBC] rounded"
                  />
                  <span className="text-[10px] text-[#786750]">°C</span>
                </div>
              </div>
              <input
                type="range"
                min="10"
                max="45"
                value={params.temperature}
                onChange={(e) => handleParamChange('temperature', Number(e.target.value))}
                className="w-full accent-[#C85A32]"
              />
            </div>

            {/* 6. Humidity */}
            <div className="space-y-1">
              <div className="flex justify-between items-center">
                <label className="font-bold text-[#182C10] flex items-center gap-1">
                  <Wind className="w-3.5 h-3.5 text-[#2E689C]" />
                  <span>Relative Humidity</span>
                </label>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    value={params.humidity}
                    onChange={(e) => handleParamChange('humidity', Number(e.target.value))}
                    className="w-16 px-2 py-0.5 text-right font-mono font-bold text-xs bg-[#FAF8F3] border border-[#D5CDBC] rounded"
                  />
                  <span className="text-[10px] text-[#786750]">%</span>
                </div>
              </div>
              <input
                type="range"
                min="20"
                max="95"
                value={params.humidity}
                onChange={(e) => handleParamChange('humidity', Number(e.target.value))}
                className="w-full accent-[#2E689C]"
              />
            </div>

            {/* 7. Rainfall */}
            <div className="space-y-1">
              <div className="flex justify-between items-center">
                <label className="font-bold text-[#182C10] flex items-center gap-1">
                  <Droplets className="w-3.5 h-3.5 text-[#194E77]" />
                  <span>Annual / Seasonal Rainfall</span>
                </label>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    value={params.rainfall}
                    onChange={(e) => handleParamChange('rainfall', Number(e.target.value))}
                    className="w-16 px-2 py-0.5 text-right font-mono font-bold text-xs bg-[#FAF8F3] border border-[#D5CDBC] rounded"
                  />
                  <span className="text-[10px] text-[#786750]">mm</span>
                </div>
              </div>
              <input
                type="range"
                min="20"
                max="320"
                value={params.rainfall}
                onChange={(e) => handleParamChange('rainfall', Number(e.target.value))}
                className="w-full accent-[#194E77]"
              />
            </div>

          </div>
        </div>

        {/* Right Column: Prediction Result Showcase */}
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-white rounded-2xl border-2 border-[#D8E6CD] p-5 shadow-sm space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-md">
                  Predicted Optimal Crop
                </span>
                <h3 className="text-2xl font-bold text-[#182C10] font-display mt-1">
                  {analysis.primaryCrop}
                </h3>
                <p className="text-xs text-[#5C6E52] font-semibold">
                  Variety: {analysis.variety}
                </p>
              </div>

              {/* Confidence badge */}
              <div className="text-right">
                <div className="px-3 py-1 bg-[#E8EFE2] rounded-xl border border-[#D0DEC4]">
                  <span className="text-[10px] text-[#55694C] uppercase block">Suitability Match</span>
                  <span className="text-lg font-extrabold text-[#234415] tabular-nums font-mono">
                    {analysis.confidence}%
                  </span>
                </div>
              </div>
            </div>

            {/* Yield & Revenue Grid */}
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div className="p-3.5 bg-[#FAF8F3] rounded-xl border border-[#E9E4D7]">
                <span className="text-[10px] text-[#786750] uppercase block">Expected Yield</span>
                <span className="text-base font-extrabold text-[#182C10] tabular-nums block mt-0.5">
                  {analysis.expectedYield}
                </span>
              </div>

              <div className="p-3.5 bg-[#FAF3E8] rounded-xl border border-[#EBDCC5]">
                <span className="text-[10px] text-[#895719] uppercase block">Projected Revenue</span>
                <span className="text-base font-extrabold text-[#895719] tabular-nums block mt-0.5">
                  {analysis.estimatedRevenue}
                </span>
              </div>
            </div>

            {/* Advisory Details */}
            <div className="space-y-2 text-xs text-[#3E5036] pt-1">
              <div className="p-3 bg-[#EAF2E4] rounded-xl border border-[#CCE0BE] flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#234415] shrink-0 mt-0.5" />
                <span><strong>Agronomic Advisory: </strong>{analysis.advisoryNote}</span>
              </div>

              <div className="flex items-center justify-between text-[11px] text-[#71826B] pt-1">
                <span>Secondary Alternative: <strong>{analysis.secondaryCrop}</strong></span>
                <span>Water: {analysis.waterRequirement.split('(')[0]}</span>
              </div>
            </div>
          </div>

          {/* Quick Score Bars */}
          <div className="bg-white p-4 rounded-2xl border border-[#DFD8C7] shadow-xs space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#35482D]">
              Soil vs Climate Compatibility Index
            </h4>

            <div className="space-y-2">
              <div>
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-[#35482D]">Soil Chemical Score (N-P-K-pH)</span>
                  <span className="font-mono text-[#234415]">{analysis.soilSuitability}%</span>
                </div>
                <div className="w-full bg-[#EFECE1] h-2 rounded-full overflow-hidden mt-1">
                  <div
                    className="bg-[#234415] h-full rounded-full transition-all duration-300"
                    style={{ width: `${analysis.soilSuitability}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-[#35482D]">Agro-Climatic Score (Temp, Rain, Moisture)</span>
                  <span className="font-mono text-[#895719]">{analysis.climateSuitability}%</span>
                </div>
                <div className="w-full bg-[#EFECE1] h-2 rounded-full overflow-hidden mt-1">
                  <div
                    className="bg-[#895719] h-full rounded-full transition-all duration-300"
                    style={{ width: `${analysis.climateSuitability}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* ========================================================
          ANALYSIS GRAPHS SECTION (REQUESTED BY USER)
         ======================================================== */}
      <div className="space-y-4 pt-2">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-[#234415]"></div>
          <h3 className="text-base font-bold text-[#182C10] font-display">
            In-Depth Telemetry Analysis Graphs
          </h3>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          
          {/* GRAPH 1: N-P-K NUTRIENT COMPARISON CHART (INPUT VS OPTIMAL) */}
          <div className="bg-white p-5 rounded-2xl border border-[#DFD8C7] shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#35482D]">
                  Graph 1: N-P-K Soil Level vs Ideal Crop Demand
                </h4>
                <p className="text-[11px] text-[#71826B]">
                  Compares your soil input against ideal requirements for {analysis.primaryCrop}
                </p>
              </div>
              <span className="text-[10px] text-[#786750] font-mono">kg/ha</span>
            </div>

            <div className="space-y-4 pt-2">
              {analysis.npkComparison.map((item) => {
                const maxScale = 160;
                const inputWidth = Math.min(100, (item.input / maxScale) * 100);
                const idealStart = (item.idealMin / maxScale) * 100;
                const idealWidth = ((item.idealMax - item.idealMin) / maxScale) * 100;

                return (
                  <div key={item.nutrient} className="space-y-1 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-[#182C10]">{item.nutrient}</span>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[#182C10] font-bold">
                          {item.input} kg/ha
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.2 rounded-full ${
                            item.status === 'Optimal'
                              ? 'bg-emerald-100 text-emerald-800'
                              : item.status === 'Deficient'
                              ? 'bg-amber-100 text-amber-900'
                              : 'bg-stone-200 text-stone-800'
                          }`}
                        >
                          {item.status}
                        </span>
                      </div>
                    </div>

                    {/* Comparative Dual Bar */}
                    <div className="relative w-full bg-[#F0EBE0] h-6 rounded-lg overflow-hidden flex items-center px-1">
                      {/* Ideal Zone Box */}
                      <div
                        className="absolute h-4 bg-emerald-200/70 border border-emerald-400 rounded"
                        style={{
                          left: `${idealStart}%`,
                          width: `${idealWidth}%`,
                        }}
                        title={`Ideal range: ${item.idealMin} - ${item.idealMax} kg/ha`}
                      />

                      {/* Actual User Input Bar */}
                      <div
                        className={`h-2.5 rounded-full transition-all duration-300 z-10 ${
                          item.status === 'Optimal'
                            ? 'bg-[#234415]'
                            : item.status === 'Deficient'
                            ? 'bg-[#B45309]'
                            : 'bg-[#6B7280]'
                        }`}
                        style={{ width: `${inputWidth}%` }}
                      />
                    </div>

                    <div className="flex justify-between text-[10px] text-[#7A8A73]">
                      <span>Zero</span>
                      <span>Target Window: {item.idealMin} - {item.idealMax} kg/ha</span>
                      <span>160 kg/ha</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* GRAPH 2: CLIMATE RANGE & STRESS TOLERANCE METERS */}
          <div className="bg-white p-5 rounded-2xl border border-[#DFD8C7] shadow-xs space-y-3">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#35482D]">
                Graph 2: Microclimate & Soil pH Stress Tolerances
              </h4>
              <p className="text-[11px] text-[#71826B]">
                Physiological ranges for {analysis.primaryCrop}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              {analysis.climateComparison.map((item) => (
                <div
                  key={item.parameter}
                  className="p-3 bg-[#FAF8F3] rounded-xl border border-[#EBE5D6] space-y-1.5 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[#182C10]">{item.parameter}</span>
                    <span
                      className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                        item.status === 'Ideal'
                          ? 'bg-emerald-100 text-emerald-800'
                          : item.status === 'Acceptable'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {item.status}
                    </span>
                  </div>

                  <div className="text-base font-extrabold text-[#234415] tabular-nums font-mono">
                    {item.input} <span className="text-xs font-normal text-[#786750]">{item.unit}</span>
                  </div>

                  <div className="text-[10px] text-[#786750]">
                    Optimal: <strong>{item.idealMin} - {item.idealMax} {item.unit}</strong>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-3 bg-[#EAF2E4] rounded-xl border border-[#CCE0BE] text-xs text-[#2A441F] flex items-center gap-2 mt-2">
              <Info className="w-4 h-4 text-[#234415] shrink-0" />
              <span>
                All 4 environmental variables lie safely inside vegetative growth boundaries.
              </span>
            </div>
          </div>

          {/* GRAPH 3: HISTORICAL APMC MANDI PRICE GROWTH */}
          <div className="bg-white p-5 rounded-2xl border border-[#DFD8C7] shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#35482D]">
                  Graph 3: 5-Year Mandi Price Trend for {analysis.primaryCrop.split('(')[0]}
                </h4>
                <p className="text-[11px] text-[#71826B]">
                  Modal APMC trading price trajectory (₹ / Quintal)
                </p>
              </div>
              <span className="text-[10px] text-[#786750] font-mono">₹/Q</span>
            </div>

            {/* SVG Trendline */}
            <div className="pt-2">
              <svg viewBox="0 0 360 140" className="w-full h-36 overflow-visible">
                {/* Horizontal guide lines */}
                {[30, 65, 100].map((y) => (
                  <line key={y} x1="0" y1={y} x2="360" y2={y} stroke="#EBE5D8" strokeDasharray="3 3" />
                ))}

                {/* Path line */}
                {(() => {
                  const pts = analysis.historicalPriceTrend;
                  const min = Math.min(...pts.map((p) => p.price)) * 0.9;
                  const max = Math.max(...pts.map((p) => p.price)) * 1.05;
                  const width = 360;
                  const height = 110;

                  const coords = pts.map((p, i) => {
                    const x = 30 + (i / (pts.length - 1)) * (width - 60);
                    const y = height - ((p.price - min) / (max - min)) * (height - 20) - 10;
                    return { x, y, ...p };
                  });

                  const d = coords
                    .map((c, i) => `${i === 0 ? 'M' : 'L'} ${c.x} ${c.y}`)
                    .join(' ');

                  return (
                    <g>
                      <path d={d} fill="none" stroke="#234415" strokeWidth="3" strokeLinecap="round" />
                      {coords.map((c, i) => (
                        <g key={i}>
                          <circle cx={c.x} cy={c.y} r="4" fill="#895719" stroke="#FFF" strokeWidth="2" />
                          <text x={c.x} y={c.y - 8} textAnchor="middle" fontSize="9" fontWeight="bold" fill="#182C10">
                            ₹{c.price}
                          </text>
                          <text x={c.x} y="132" textAnchor="middle" fontSize="10" fill="#786750">
                            {c.year}
                          </text>
                        </g>
                      ))}
                    </g>
                  );
                })()}
              </svg>
            </div>
          </div>

          {/* GRAPH 4: MONTH-BY-MONTH SOWING SUITABILITY CURVE */}
          <div className="bg-white p-5 rounded-2xl border border-[#DFD8C7] shadow-xs space-y-3">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#35482D]">
                Graph 4: Month-by-Month Sowing Suitability Index
              </h4>
              <p className="text-[11px] text-[#71826B]">
                Probability score of maximum yield based on seasonal germination temperatures
              </p>
            </div>

            <div className="grid grid-cols-6 gap-2 pt-3">
              {analysis.monthlySuitability.map((m) => (
                <div key={m.month} className="flex flex-col items-center">
                  <span className="text-[10px] font-mono font-bold text-[#234415] mb-1">
                    {m.score}%
                  </span>
                  <div className="w-full bg-[#EFECE1] h-24 rounded-xl overflow-hidden flex flex-col justify-end p-1">
                    <div
                      className={`w-full rounded-lg transition-all duration-300 ${
                        m.score >= 95
                          ? 'bg-[#234415]'
                          : m.score >= 85
                          ? 'bg-[#55783A]'
                          : 'bg-[#B45309]'
                      }`}
                      style={{ height: `${m.score}%` }}
                    />
                  </div>
                  <span className="text-xs font-bold text-[#182C10] mt-1.5">
                    {m.month}
                  </span>
                </div>
              ))}
            </div>

            <p className="text-[11px] text-[#786750] text-center pt-1">
              Optimal sowing peak highlighted in deep green (November window).
            </p>
          </div>

        </div>
      </div>

    </div>
  );
};
