import React, { useState } from 'react';
import {
  DealerProfile,
  DealerTab,
  MandiPriceItem,
  InventoryItem,
  PaymentTransaction,
  FarmerOrder
} from '../../types';
import {
  MOCK_MANDI_PRICES,
  MOCK_INVENTORY,
  MOCK_PAYMENTS,
  MOCK_FARMER_ORDERS
} from '../../data/mockData';
import {
  LayoutDashboard,
  TrendingUp,
  BarChart3,
  CreditCard,
  Package,
  Building2,
  Search,
  Filter,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
  CheckCircle2,
  Clock,
  AlertCircle,
  Plus,
  Download,
  Share2,
  Store,
  ChevronRight,
  ShieldCheck,
  Send,
  Eye,
  X,
  QrCode,
  FileSpreadsheet
} from 'lucide-react';

interface DealerDashboardProps {
  profile: DealerProfile;
  onUpdateProfile: (updated: Partial<DealerProfile>) => void;
  onSwitchToFarmer: () => void;
}

export const DealerDashboard: React.FC<DealerDashboardProps> = ({
  profile,
  onUpdateProfile,
  onSwitchToFarmer,
}) => {
  const [activeTab, setActiveTab] = useState<DealerTab>('overview');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Market Price Tracker Filters
  const [selectedState, setSelectedState] = useState<string>('All States');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('All Districts');
  const [searchCommodity, setSearchCommodity] = useState<string>('');

  // Inventory & Orders State
  const [inventory, setInventory] = useState<InventoryItem[]>(MOCK_INVENTORY);
  const [orders, setOrders] = useState<FarmerOrder[]>(MOCK_FARMER_ORDERS);
  const [payments, setPayments] = useState<PaymentTransaction[]>(MOCK_PAYMENTS);

  // Modals
  const [showAddPaymentModal, setShowAddPaymentModal] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<PaymentTransaction | null>(null);
  const [showAddStockModal, setShowAddStockModal] = useState(false);

  // Filtered Mandi Prices
  const filteredMandiPrices = MOCK_MANDI_PRICES.filter((item) => {
    const matchesState = selectedState === 'All States' || item.state === selectedState;
    const matchesDistrict = selectedDistrict === 'All Districts' || item.district === selectedDistrict;
    const matchesSearch =
      item.commodity.toLowerCase().includes(searchCommodity.toLowerCase()) ||
      item.variety.toLowerCase().includes(searchCommodity.toLowerCase()) ||
      item.mandi.toLowerCase().includes(searchCommodity.toLowerCase());
    return matchesState && matchesDistrict && matchesSearch;
  });

  // Extract unique states for filter chips
  const statesList = ['All States', ...Array.from(new Set(MOCK_MANDI_PRICES.map((p) => p.state)))];

  // Helper to draw clean SVG sparkline
  const renderSparkline = (points: number[], trend: 'up' | 'down' | 'stable') => {
    const min = Math.min(...points);
    const max = Math.max(...points);
    const range = max - min || 1;
    const width = 80;
    const height = 24;

    const pathData = points
      .map((p, i) => {
        const x = (i / (points.length - 1)) * width;
        const y = height - ((p - min) / range) * (height - 6) - 3;
        return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
      })
      .join(' ');

    const strokeColor = trend === 'up' ? '#15803D' : trend === 'down' ? '#B45309' : '#57534E';

    return (
      <svg width={width} height={height} className="overflow-visible inline-block">
        <path d={pathData} fill="none" stroke={strokeColor} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
  };

  // Order Fulfillment Handler
  const handleUpdateOrderStatus = (orderId: string, newStatus: FarmerOrder['status']) => {
    setOrders((prev) =>
      prev.map((ord) => (ord.id === orderId ? { ...ord, status: newStatus } : ord))
    );
  };

  return (
    <div className="min-h-[calc(100vh-65px)] bg-[#F8F6F0] text-[#1D2916] flex flex-col lg:flex-row">
      
      {/* ========================================================
          SIDEBAR NAVIGATION (DESKTOP) / COLLAPSIBLE DRAWER
         ======================================================== */}
      <aside className="w-full lg:w-64 bg-[#F2EDE2] border-r border-[#E0D9C8] flex flex-col shrink-0 lg:min-h-[calc(100vh-65px)]">
        
        {/* Dealership Identity in Sidebar */}
        <div className="p-4 border-b border-[#E0D9C8] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#895719] text-[#FDF8EE] flex items-center justify-center font-bold text-sm shadow-xs">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xs font-bold text-[#2A1D0B] font-display leading-tight truncate max-w-[140px]">
                {profile.businessName}
              </h2>
              <span className="inline-flex items-center gap-1 text-[10px] text-emerald-800 font-semibold">
                <ShieldCheck className="w-3 h-3 text-emerald-700" />
                <span>Verified Agri-Dealer</span>
              </span>
            </div>
          </div>

          {/* Mobile drawer toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-1.5 rounded-lg bg-white border border-[#D5CDBC] text-[#4E3E28]"
          >
            <Filter className="w-4 h-4" />
          </button>
        </div>

        {/* Nav Items */}
        <nav className={`p-3 space-y-1 ${mobileMenuOpen ? 'block' : 'hidden lg:block'}`}>
          {[
            { id: 'overview', label: 'Overview & Stats', icon: LayoutDashboard },
            { id: 'prices', label: 'Mandi Price Tracker', icon: TrendingUp },
            { id: 'analytics', label: 'Business Analysis', icon: BarChart3 },
            { id: 'payments', label: 'Payments & Ledger', icon: CreditCard },
            { id: 'inventory', label: 'Inventory & Orders', icon: Package },
            { id: 'profile', label: 'Business Profile', icon: Building2 },
          ].map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id as DealerTab);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold text-left transition-all min-h-[44px] ${
                  isActive
                    ? 'bg-[#895719] text-white shadow-xs'
                    : 'text-[#4F412E] hover:bg-[#E7E0D1] hover:text-[#2A1D0B]'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-[#895719]'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}

          <div className="pt-4 mt-4 border-t border-[#DFD8C7]">
            <button
              onClick={onSwitchToFarmer}
              className="w-full flex items-center justify-between p-2.5 bg-[#E8EFE2] hover:bg-[#DCE7D4] text-[#234415] rounded-xl text-xs font-bold border border-[#D0DEC4] transition-colors min-h-[44px]"
            >
              <span>Switch to Farmer View</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </nav>

        {/* Bottom Status Box */}
        <div className="hidden lg:block mt-auto p-4 border-t border-[#E0D9C8] text-[11px] text-[#786750]">
          <div className="flex justify-between items-center">
            <span>District Hub: <strong>{profile.districtsCovered[0]}</strong></span>
            <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
          </div>
          <span className="text-[10px] text-[#9E8E78] block mt-0.5">
            APMC Agmarknet Feed: Live
          </span>
        </div>
      </aside>

      {/* ========================================================
          MAIN CONTENT VIEWPORT
         ======================================================== */}
      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full space-y-6">

        {/* ========================================================
            SUB-SCREEN 1: OVERVIEW & STATS
           ======================================================== */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            
            {/* Top Stat Row: Key Metrics at a Glance */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              
              {/* Stat 1: Top Commodity Price Benchmark */}
              <div className="bg-white p-4 rounded-2xl border border-[#DFD8C7] shadow-xs">
                <span className="text-[11px] font-semibold text-[#6C5D47] uppercase block">
                  Top Commodity Today
                </span>
                <div className="flex items-baseline justify-between mt-1">
                  <span className="text-xl font-extrabold text-[#2A1D0B] font-display tabular-nums">
                    ₹4,280 <span className="text-xs font-normal text-[#786750]">/ Q</span>
                  </span>
                  <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                    ▲ 2.1%
                  </span>
                </div>
                <p className="text-[11px] text-[#786750] mt-1">
                  Basmati 1121 (Karnal Mandi)
                </p>
              </div>

              {/* Stat 2: Active Orders */}
              <div className="bg-white p-4 rounded-2xl border border-[#DFD8C7] shadow-xs">
                <span className="text-[11px] font-semibold text-[#6C5D47] uppercase block">
                  Active Farmer Orders
                </span>
                <div className="flex items-baseline justify-between mt-1">
                  <span className="text-xl font-extrabold text-[#234415] font-display tabular-nums">
                    18 Requests
                  </span>
                  <span className="text-[11px] font-bold text-[#234415] bg-[#E8EFE2] px-1.5 py-0.5 rounded">
                    4 New Today
                  </span>
                </div>
                <p className="text-[11px] text-[#786750] mt-1">
                  Value: ₹1,68,400 across 3 blocks
                </p>
              </div>

              {/* Stat 3: Pending Payments */}
              <div className="bg-white p-4 rounded-2xl border border-[#DFD8C7] shadow-xs">
                <span className="text-[11px] font-semibold text-[#6C5D47] uppercase block">
                  Pending Payments
                </span>
                <div className="flex items-baseline justify-between mt-1">
                  <span className="text-xl font-extrabold text-[#895719] font-display tabular-nums">
                    ₹1,42,800
                  </span>
                  <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded">
                    6 Invoices
                  </span>
                </div>
                <p className="text-[11px] text-[#786750] mt-1">
                  ₹22,600 due from Sardar Baldev Singh
                </p>
              </div>

              {/* Stat 4: Inventory Alert */}
              <div className="bg-white p-4 rounded-2xl border border-[#DFD8C7] shadow-xs">
                <span className="text-[11px] font-semibold text-[#6C5D47] uppercase block">
                  Inventory Alerts
                </span>
                <div className="flex items-baseline justify-between mt-1">
                  <span className="text-xl font-extrabold text-[#C85A32] font-display tabular-nums">
                    2 Items Low
                  </span>
                  <span className="text-[11px] font-bold text-red-700 bg-red-50 px-1.5 py-0.5 rounded">
                    Reorder Now
                  </span>
                </div>
                <p className="text-[11px] text-[#786750] mt-1">
                  Drip Pipes (4 rolls) & Zinc 33%
                </p>
              </div>

            </div>

            {/* Middle Section: Recent Incoming Farmer Requests + Fast Action Console */}
            <div className="grid lg:grid-cols-12 gap-6">
              
              {/* Left Column: Live Farmer Inquiries / Quotes Feed */}
              <div className="lg:col-span-8 bg-white p-5 rounded-2xl border border-[#DFD8C7] shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-[#2A1D0B] font-display">
                      Incoming Farmer Orders & Quotation Requests
                    </h3>
                    <p className="text-xs text-[#786750]">
                      Nearby farmers requesting inputs or quoting mandi prices
                    </p>
                  </div>
                  <button
                    onClick={() => setActiveTab('inventory')}
                    className="text-xs font-bold text-[#895719] hover:underline"
                  >
                    View All Orders →
                  </button>
                </div>

                <div className="space-y-3">
                  {orders.map((order) => (
                    <div
                      key={order.id}
                      className="p-3.5 bg-[#FAF8F3] rounded-xl border border-[#E9E4D7] flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-[#2A1D0B]">
                            {order.farmerName}
                          </span>
                          <span className="text-[10px] text-[#786750]">
                            · {order.village}
                          </span>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              order.status === 'New Request'
                                ? 'bg-amber-100 text-amber-900 border border-amber-200'
                                : order.status === 'Quote Sent'
                                ? 'bg-blue-100 text-blue-900'
                                : 'bg-emerald-100 text-emerald-900'
                            }`}
                          >
                            {order.status}
                          </span>
                        </div>
                        <p className="text-xs font-semibold text-[#483823] mt-1">
                          {order.productName}
                        </p>
                        <div className="flex items-center gap-3 text-[11px] text-[#786750] mt-0.5">
                          <span>Qty: {order.quantity}</span>
                          <span>·</span>
                          <span className="font-bold text-[#2A1D0B]">₹{order.totalValue.toLocaleString('en-IN')}</span>
                          <span>·</span>
                          <span>{order.date}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        {order.status === 'New Request' ? (
                          <button
                            onClick={() => handleUpdateOrderStatus(order.id, 'Quote Sent')}
                            className="px-3 py-1.5 bg-[#895719] hover:bg-[#6D420F] text-white text-xs font-semibold rounded-lg shadow-xs transition-colors whitespace-nowrap min-h-[36px]"
                          >
                            Send Quote
                          </button>
                        ) : order.status === 'Quote Sent' ? (
                          <button
                            onClick={() => handleUpdateOrderStatus(order.id, 'Fulfilled')}
                            className="px-3 py-1.5 bg-[#234415] hover:bg-[#1A3410] text-white text-xs font-semibold rounded-lg shadow-xs transition-colors whitespace-nowrap min-h-[36px]"
                          >
                            Mark Fulfilled
                          </button>
                        ) : (
                          <span className="text-xs font-bold text-emerald-700 flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Ready for Pickup</span>
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Right Column: Quick Business Actions & Mandi Shortcut */}
              <div className="lg:col-span-4 space-y-4">
                <div className="bg-white p-5 rounded-2xl border border-[#DFD8C7] shadow-xs space-y-3">
                  <h3 className="text-sm font-bold text-[#2A1D0B] font-display">
                    Quick Operations
                  </h3>
                  
                  <div className="space-y-2">
                    <button
                      onClick={() => setShowAddStockModal(true)}
                      className="w-full py-2.5 px-3 bg-[#FAF8F3] hover:bg-[#F2ECE0] text-[#2A1D0B] rounded-xl border border-[#D5CDBC] text-xs font-semibold flex items-center justify-between transition-colors min-h-[44px]"
                    >
                      <span className="flex items-center gap-2">
                        <Plus className="w-4 h-4 text-[#895719]" />
                        <span>Log New Stock Batch</span>
                      </span>
                      <span className="text-[10px] text-[#786750]">Inventory</span>
                    </button>

                    <button
                      onClick={() => setShowAddPaymentModal(true)}
                      className="w-full py-2.5 px-3 bg-[#FAF8F3] hover:bg-[#F2ECE0] text-[#2A1D0B] rounded-xl border border-[#D5CDBC] text-xs font-semibold flex items-center justify-between transition-colors min-h-[44px]"
                    >
                      <span className="flex items-center gap-2">
                        <CreditCard className="w-4 h-4 text-[#895719]" />
                        <span>Add Payment Mode / UPI QR</span>
                      </span>
                      <span className="text-[10px] text-[#786750]">Ledger</span>
                    </button>

                    <button
                      onClick={() => setActiveTab('prices')}
                      className="w-full py-2.5 px-3 bg-[#FAF8F3] hover:bg-[#F2ECE0] text-[#2A1D0B] rounded-xl border border-[#D5CDBC] text-xs font-semibold flex items-center justify-between transition-colors min-h-[44px]"
                    >
                      <span className="flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-[#895719]" />
                        <span>Compare State Mandi Rates</span>
                      </span>
                      <span className="text-[10px] text-[#786750]">APMC</span>
                    </button>
                  </div>
                </div>

                {/* Mandi Arbitrage Snapshot */}
                <div className="bg-[#FAF0E1] p-4 rounded-2xl border border-[#ECD9BE] space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#895719] uppercase tracking-wider">
                      Price Opportunity Alert
                    </span>
                    <span className="text-[10px] font-mono text-[#895719]">Live</span>
                  </div>
                  <p className="text-xs text-[#4F3C24] leading-relaxed">
                    <strong>Sharbati Wheat</strong> is trading at <strong>₹3,250/Q</strong> in Khargone MP vs <strong>₹2,840/Q</strong> in neighboring regions (+₹410/Q spread).
                  </p>
                  <button
                    onClick={() => setActiveTab('prices')}
                    className="text-xs font-bold text-[#895719] hover:underline block pt-1"
                  >
                    Check Mandi Arbitrage Table →
                  </button>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* ========================================================
            SUB-SCREEN 2: MARKET PRICE TRACKER
           ======================================================== */}
        {activeTab === 'prices' && (
          <div className="space-y-4">
            
            {/* Header & Filter Controls */}
            <div className="bg-white p-5 rounded-2xl border border-[#DFD8C7] shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-base font-bold text-[#2A1D0B] font-display">
                    APMC Mandi Price Tracker
                  </h3>
                  <p className="text-xs text-[#786750]">
                    Verified daily modal rates, arrival volumes, and 7-day trajectories across Indian agricultural markets
                  </p>
                </div>

                {/* Search Bar */}
                <div className="relative min-w-[240px]">
                  <Search className="w-4 h-4 text-[#8E7E67] absolute left-3 top-3" />
                  <input
                    type="text"
                    value={searchCommodity}
                    onChange={(e) => setSearchCommodity(e.target.value)}
                    placeholder="Search crop, variety, or mandi..."
                    className="w-full pl-9 pr-3 py-2 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-semibold text-[#2A1D0B] focus:ring-2 focus:ring-[#895719] focus:outline-none min-h-[40px]"
                  />
                </div>
              </div>

              {/* State Filter Chips */}
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#695843] block mb-2">
                  Select State:
                </span>
                <div className="flex flex-wrap items-center gap-1.5">
                  {statesList.map((st) => (
                    <button
                      key={st}
                      onClick={() => setSelectedState(st)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors min-h-[36px] ${
                        selectedState === st
                          ? 'bg-[#895719] text-white shadow-xs'
                          : 'bg-[#FAF8F3] text-[#4F402D] border border-[#DDD6C5] hover:bg-[#F2ECE0]'
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* The Price Table / Card Grid with Sparklines */}
            <div className="bg-white rounded-2xl border border-[#DFD8C7] shadow-xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#FAF8F3] border-b border-[#E3DDD0] text-[11px] font-bold text-[#64553F] uppercase tracking-wider">
                    <tr>
                      <th className="py-3.5 px-4">Commodity & Variety</th>
                      <th className="py-3.5 px-4">Mandi & District</th>
                      <th className="py-3.5 px-4 text-right">Min - Max Price (₹)</th>
                      <th className="py-3.5 px-4 text-right">Modal Price (₹/Q)</th>
                      <th className="py-3.5 px-4 text-center">7-Day Trend</th>
                      <th className="py-3.5 px-4 text-center">Change</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#EFECE1]">
                    {filteredMandiPrices.map((item) => (
                      <tr key={item.id} className="hover:bg-[#FAF8F3] transition-colors">
                        <td className="py-3.5 px-4">
                          <span className="font-bold text-[#2A1D0B] block text-sm">
                            {item.commodity}
                          </span>
                          <span className="text-[11px] text-[#786750]">
                            {item.variety}
                          </span>
                        </td>

                        <td className="py-3.5 px-4">
                          <span className="font-semibold text-[#3C2E1D] block">
                            {item.mandi}
                          </span>
                          <span className="text-[11px] text-[#786750]">
                            {item.district}, {item.state}
                          </span>
                        </td>

                        <td className="py-3.5 px-4 text-right font-mono tabular-nums text-[#5C4D38]">
                          ₹{item.minPrice} - ₹{item.maxPrice}
                        </td>

                        <td className="py-3.5 px-4 text-right font-mono font-bold text-sm tabular-nums text-[#2A1D0B]">
                          ₹{item.modalPrice.toLocaleString('en-IN')}
                        </td>

                        {/* Sparkline Column */}
                        <td className="py-3.5 px-4 text-center">
                          {renderSparkline(item.sparkline, item.trend)}
                        </td>

                        <td className="py-3.5 px-4 text-center">
                          <span
                            className={`inline-flex items-center gap-1 font-bold text-[11px] px-2 py-0.5 rounded-full ${
                              item.trend === 'up'
                                ? 'bg-emerald-100 text-emerald-800'
                                : item.trend === 'down'
                                ? 'bg-amber-100 text-amber-900'
                                : 'bg-stone-100 text-stone-700'
                            }`}
                          >
                            {item.trend === 'up' && <ArrowUpRight className="w-3 h-3" />}
                            {item.trend === 'down' && <ArrowDownRight className="w-3 h-3" />}
                            {item.trend === 'stable' && <Minus className="w-3 h-3" />}
                            <span>{item.changePercent}%</span>
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {filteredMandiPrices.length === 0 && (
                <div className="p-8 text-center text-xs text-[#786750]">
                  No commodities found matching current search or filters. Try selecting "All States".
                </div>
              )}
            </div>

          </div>
        )}

        {/* ========================================================
            SUB-SCREEN 3: BUSINESS ANALYSIS (CHARTS IN EARTHY PALETTE)
           ======================================================== */}
        {activeTab === 'analytics' && (
          <div className="space-y-6">
            
            {/* Header */}
            <div className="bg-white p-5 rounded-2xl border border-[#DFD8C7] shadow-xs">
              <h3 className="text-base font-bold text-[#2A1D0B] font-display">
                Vyapaar & Sales Performance Intelligence
              </h3>
              <p className="text-xs text-[#786750]">
                Clean monthly revenue trajectories, top agricultural input movers, and district demand breakdown.
              </p>
            </div>

            <div className="grid lg:grid-cols-2 gap-6">
              
              {/* Chart 1: Sales Revenue Over Time (Line Chart) */}
              <div className="bg-white p-5 rounded-2xl border border-[#DFD8C7] shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-[#4E3E28]">
                      Monthly Sales Revenue (2026)
                    </h4>
                    <span className="text-lg font-extrabold text-[#2A1D0B] font-display tabular-nums">
                      ₹18,45,000 <span className="text-xs font-normal text-emerald-700">▲ +14.2% YoY</span>
                    </span>
                  </div>
                  <span className="text-[10px] text-[#867560] font-mono">In Lakhs (₹)</span>
                </div>

                {/* Custom SVG Line Chart */}
                <div className="pt-2">
                  <svg viewBox="0 0 400 180" className="w-full h-44 overflow-visible">
                    {/* Gridlines */}
                    {[40, 80, 120, 160].map((y) => (
                      <line key={y} x1="0" y1={y} x2="400" y2={y} stroke="#EBE5D8" strokeDasharray="3 3" />
                    ))}
                    
                    {/* Area fill */}
                    <path
                      d="M 20 150 Q 80 130 140 115 T 260 70 T 380 40 L 380 160 L 20 160 Z"
                      fill="url(#greenGradient)"
                      opacity="0.25"
                    />

                    {/* Gradient definition */}
                    <defs>
                      <linearGradient id="greenGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#234415" />
                        <stop offset="100%" stopColor="#FAF8F3" />
                      </linearGradient>
                    </defs>

                    {/* Line */}
                    <path
                      d="M 20 150 Q 80 130 140 115 T 260 70 T 380 40"
                      fill="none"
                      stroke="#234415"
                      strokeWidth="3"
                      strokeLinecap="round"
                    />

                    {/* Data Points with labels */}
                    {[
                      { x: 20, y: 150, label: 'May', val: '₹8.4L' },
                      { x: 100, y: 125, label: 'Jun', val: '₹11.2L' },
                      { x: 180, y: 100, label: 'Jul', val: '₹14.0L' },
                      { x: 260, y: 70, label: 'Aug', val: '₹16.8L' },
                      { x: 340, y: 50, label: 'Sep', val: '₹17.9L' },
                      { x: 380, y: 40, label: 'Oct', val: '₹18.4L' },
                    ].map((pt, i) => (
                      <g key={i}>
                        <circle cx={pt.x} cy={pt.y} r="4" fill="#895719" stroke="#FFF" strokeWidth="2" />
                        <text x={pt.x} y="175" textAnchor="middle" fontSize="10" fill="#786750">
                          {pt.label}
                        </text>
                      </g>
                    ))}
                  </svg>
                </div>
              </div>

              {/* Chart 2: Top Selling Products (Bar Chart in Earthy Tones) */}
              <div className="bg-white p-5 rounded-2xl border border-[#DFD8C7] shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-[#4E3E28]">
                    Top-Selling Agri-Input Products (Volume)
                  </h4>
                  <span className="text-[10px] text-[#867560]">Units Sold</span>
                </div>

                <div className="space-y-3 pt-2">
                  {[
                    { name: 'NPK 19:19:19 Soluble (IFFCO)', sold: 420, max: 500, color: '#234415', revenue: '₹7.77L' },
                    { name: 'Pioneer 45S46 Mustard Seeds', sold: 310, max: 500, color: '#895719', revenue: '₹3.03L' },
                    { name: 'Neem Shield Bio-Pesticide', sold: 260, max: 500, color: '#567A38', revenue: '₹1.35L' },
                    { name: 'Zinc Sulfate Monohydrate 33%', sold: 180, max: 500, color: '#C85A32', revenue: '₹1.22L' },
                    { name: 'Drip Irrigation Lateral Bundles', sold: 90, max: 500, color: '#4D623C', revenue: '₹3.10L' },
                  ].map((prod) => (
                    <div key={prod.name} className="space-y-1">
                      <div className="flex items-center justify-between text-xs font-semibold text-[#2A1D0B]">
                        <span className="truncate max-w-[220px]">{prod.name}</span>
                        <span className="tabular-nums font-mono text-[#895719]">{prod.revenue}</span>
                      </div>
                      <div className="w-full bg-[#EFECE1] h-2.5 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-500"
                          style={{
                            width: `${(prod.sold / prod.max) * 100}%`,
                            backgroundColor: prod.color,
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Chart 3: Demand by District (Ranked List with Intensity Meters) */}
              <div className="bg-white p-5 rounded-2xl border border-[#DFD8C7] shadow-xs space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#4E3E28]">
                  Procurement Demand by District Hub
                </h4>

                <div className="space-y-2.5 pt-1">
                  {[
                    { rank: 1, district: 'Karnal (Haryana)', demand: 'Very High', score: 94, activeGrowers: 320 },
                    { rank: 2, district: 'Kurukshetra (Haryana)', demand: 'High', score: 86, activeGrowers: 240 },
                    { rank: 3, district: 'Khargone (Madhya Pradesh)', demand: 'High', score: 82, activeGrowers: 195 },
                    { rank: 4, district: 'Purba Bardhaman (West Bengal)', demand: 'Moderate', score: 71, activeGrowers: 160 },
                    { rank: 5, district: 'Kota (Rajasthan)', demand: 'Steady', score: 65, activeGrowers: 110 },
                  ].map((item) => (
                    <div
                      key={item.district}
                      className="p-3 bg-[#FAF8F3] rounded-xl border border-[#EBE5D6] flex items-center justify-between"
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-6 h-6 rounded-full bg-[#EAE3D3] text-[#4F3E28] font-bold text-xs flex items-center justify-center">
                          {item.rank}
                        </span>
                        <div>
                          <span className="text-xs font-bold text-[#2A1D0B] block">
                            {item.district}
                          </span>
                          <span className="text-[10px] text-[#786750]">
                            {item.activeGrowers} verified farm buyers
                          </span>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                          {item.demand}
                        </span>
                        <div className="w-16 bg-[#E0D8C6] h-1.5 rounded-full overflow-hidden mt-1">
                          <div
                            className="bg-[#234415] h-full"
                            style={{ width: `${item.score}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Chart 4: Seasonal Comparison (Kharif vs Rabi) */}
              <div className="bg-white p-5 rounded-2xl border border-[#DFD8C7] shadow-xs space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#4E3E28]">
                  Seasonal Trend Comparison (Year-Over-Year)
                </h4>

                <div className="grid grid-cols-2 gap-3 pt-1">
                  <div className="p-4 bg-[#EAF2E4] rounded-xl border border-[#CCE0BE]">
                    <span className="text-xs font-bold text-[#234415] block">Kharif (Monsoon)</span>
                    <span className="text-xl font-extrabold text-[#234415] tabular-nums mt-1 block">
                      3,840 Quintals
                    </span>
                    <p className="text-[11px] text-[#4C643E] mt-1">
                      Dominated by Paddy & Soybean. +11% volume vs 2025.
                    </p>
                  </div>

                  <div className="p-4 bg-[#FAF0E1] rounded-xl border border-[#ECD9BE]">
                    <span className="text-xs font-bold text-[#895719] block">Rabi (Winter Forecast)</span>
                    <span className="text-xl font-extrabold text-[#895719] tabular-nums mt-1 block">
                      4,600 Quintals
                    </span>
                    <p className="text-[11px] text-[#695439] mt-1">
                      Wheat & Mustard high procurement forecast starting Nov.
                    </p>
                  </div>
                </div>

                <p className="text-[11px] text-[#786750] italic pt-1">
                  * Based on agro-climatic satellite sowing records and regional mandi APMC arrival notices.
                </p>
              </div>

            </div>
          </div>
        )}

        {/* ========================================================
            SUB-SCREEN 4: PAYMENTS & LEDGER
           ======================================================== */}
        {activeTab === 'payments' && (
          <div className="space-y-6">
            
            {/* Payment Summary Header */}
            <div className="bg-white p-5 rounded-2xl border border-[#DFD8C7] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold text-[#2A1D0B] font-display">
                  Payments, Mandi Invoices & Settlement Ledger
                </h3>
                <p className="text-xs text-[#786750]">
                  Real-time UPI, RTGS and cash receipt reconciliation with instant digital receipts
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowAddPaymentModal(true)}
                  className="px-4 py-2 bg-[#895719] hover:bg-[#6D420F] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors shadow-xs min-h-[40px]"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Payment Method</span>
                </button>
              </div>
            </div>

            {/* Transaction History Table */}
            <div className="bg-white rounded-2xl border border-[#DFD8C7] shadow-xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#FAF8F3] border-b border-[#E3DDD0] text-[11px] font-bold text-[#64553F] uppercase tracking-wider">
                    <tr>
                      <th className="py-3.5 px-4">Entity / Counterparty</th>
                      <th className="py-3.5 px-4">Type</th>
                      <th className="py-3.5 px-4">Amount (₹)</th>
                      <th className="py-3.5 px-4">Payment Method</th>
                      <th className="py-3.5 px-4">Date</th>
                      <th className="py-3.5 px-4 text-center">Status</th>
                      <th className="py-3.5 px-4 text-right">Invoice</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#EFECE1]">
                    {payments.map((tx) => (
                      <tr key={tx.id} className="hover:bg-[#FAF8F3] transition-colors">
                        <td className="py-3.5 px-4">
                          <span className="font-bold text-[#2A1D0B] block">
                            {tx.entityName}
                          </span>
                          <span className="text-[10px] text-[#786750] font-mono">
                            Ref: {tx.invoiceRef}
                          </span>
                        </td>

                        <td className="py-3.5 px-4">
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              tx.type === 'Incoming'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-stone-200 text-stone-800'
                            }`}
                          >
                            {tx.type}
                          </span>
                        </td>

                        <td className="py-3.5 px-4 font-mono font-bold text-sm tabular-nums text-[#2A1D0B]">
                          ₹{tx.amount.toLocaleString('en-IN')}
                        </td>

                        <td className="py-3.5 px-4 text-[#524330]">
                          {tx.method}
                        </td>

                        <td className="py-3.5 px-4 text-[#786750]">
                          {tx.date}
                        </td>

                        <td className="py-3.5 px-4 text-center">
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              tx.status === 'Completed'
                                ? 'bg-emerald-100 text-emerald-800'
                                : tx.status === 'Pending'
                                ? 'bg-amber-100 text-amber-900'
                                : 'bg-red-100 text-red-900'
                            }`}
                          >
                            {tx.status}
                          </span>
                        </td>

                        <td className="py-3.5 px-4 text-right">
                          <button
                            onClick={() => setSelectedInvoice(tx)}
                            className="text-[#895719] hover:underline font-semibold text-xs flex items-center gap-1 justify-end ml-auto"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>View Receipt</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* ========================================================
            SUB-SCREEN 5: INVENTORY & ORDERS
           ======================================================== */}
        {activeTab === 'inventory' && (
          <div className="space-y-6">
            
            {/* Header */}
            <div className="bg-white p-5 rounded-2xl border border-[#DFD8C7] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold text-[#2A1D0B] font-display">
                  Agri-Input Warehouse & Stock Control
                </h3>
                <p className="text-xs text-[#786750]">
                  Track seeds, fertilizers, pesticides, and irrigation stock with re-order alerts
                </p>
              </div>

              <button
                onClick={() => setShowAddStockModal(true)}
                className="px-4 py-2 bg-[#234415] hover:bg-[#1A3410] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors shadow-xs min-h-[40px]"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Stock Item</span>
              </button>
            </div>

            {/* Inventory List */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {inventory.map((item) => (
                <div
                  key={item.id}
                  className="bg-white p-4 rounded-2xl border border-[#DFD8C7] shadow-xs flex flex-col justify-between"
                >
                  <div className="space-y-2">
                    <div className="flex items-start justify-between">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-[#695843] bg-[#FAF8F3] px-2 py-0.5 rounded border border-[#E5DFD0]">
                        {item.category}
                      </span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          item.status === 'In Stock'
                            ? 'bg-emerald-100 text-emerald-800'
                            : item.status === 'Low Stock'
                            ? 'bg-amber-100 text-amber-900'
                            : 'bg-red-100 text-red-900 animate-pulse'
                        }`}
                      >
                        {item.status}
                      </span>
                    </div>

                    <h4 className="text-sm font-bold text-[#2A1D0B] font-display">
                      {item.name}
                    </h4>

                    <div className="flex items-baseline justify-between pt-1">
                      <div>
                        <span className="text-[10px] text-[#786750] block">Available Stock</span>
                        <span className="text-lg font-extrabold text-[#2A1D0B] tabular-nums">
                          {item.currentStock} <span className="text-xs font-normal text-[#786750]">{item.unit}</span>
                        </span>
                      </div>

                      <div className="text-right">
                        <span className="text-[10px] text-[#786750] block">Selling Price</span>
                        <span className="text-sm font-bold text-[#895719] tabular-nums">
                          ₹{item.pricePerUnit}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-[#EFECE1] flex items-center justify-between">
                    <span className="text-[10px] text-[#786750]">
                      Reorder alert at: <strong>{item.reorderLevel} {item.unit.split(' ')[0]}</strong>
                    </span>
                    <button
                      onClick={() => alert(`Purchase order triggered for ${item.name}`)}
                      className="px-2.5 py-1 text-xs font-bold text-[#234415] hover:bg-[#E8EFE2] rounded-lg transition-colors"
                    >
                      Reorder
                    </button>
                  </div>
                </div>
              ))}
            </div>

          </div>
        )}

        {/* ========================================================
            SUB-SCREEN 6: PROFILE / BUSINESS SETTINGS
           ======================================================== */}
        {activeTab === 'profile' && (
          <div className="space-y-6">
            
            {/* Dealership Profile Card */}
            <div className="bg-white p-6 rounded-2xl border border-[#DFD8C7] shadow-xs space-y-4">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-[#895719] text-[#FDF8EE] flex items-center justify-center font-bold text-2xl font-display shadow-sm">
                    {profile.businessName.charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-xl font-bold text-[#2A1D0B] font-display">
                        {profile.businessName}
                      </h3>
                      <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>Verified</span>
                      </span>
                    </div>
                    <p className="text-xs text-[#786750] mt-0.5">
                      Proprietor: {profile.name} · Phone: +91 {profile.phone}
                    </p>
                    <p className="text-xs text-[#786750] font-mono mt-0.5">
                      GSTIN: {profile.gstin || '06AAECK9821L1Z9'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Service Areas */}
              <div className="pt-4 border-t border-[#EFECE1] space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#4E3E28]">
                  Operational Territory & Mandi Hubs
                </h4>
                <div className="flex flex-wrap gap-2">
                  {profile.districtsCovered.map((dist) => (
                    <span
                      key={dist}
                      className="px-3 py-1 bg-[#FAF8F3] border border-[#DDD6C5] rounded-xl text-xs font-semibold text-[#4E3E28]"
                    >
                      {dist} ({profile.state})
                    </span>
                  ))}
                  <button
                    onClick={() => alert('Additional districts can be added after Krishi license validation.')}
                    className="px-3 py-1 bg-[#EAE3D3] hover:bg-[#DDD4C1] rounded-xl text-xs font-bold text-[#2A1D0B] transition-colors"
                  >
                    + Add District
                  </button>
                </div>
              </div>

              {/* Regulatory License Status */}
              <div className="pt-4 border-t border-[#EFECE1] space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#4E3E28]">
                  Statutory Licenses
                </h4>
                <div className="grid sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 bg-[#FAF8F3] rounded-xl border border-[#EAE3D3]">
                    <span className="font-bold text-[#2A1D0B] block">Krishi Input Dealer License</span>
                    <span className="text-[#786750]">Lic. No: HR/KNL/SEED/2024-819 · Valid until 2029</span>
                  </div>
                  <div className="p-3 bg-[#FAF8F3] rounded-xl border border-[#EAE3D3]">
                    <span className="font-bold text-[#2A1D0B] block">Fertilizer Retail Sale Certificate</span>
                    <span className="text-[#786750]">Issued by Dept. of Agriculture, Haryana</span>
                  </div>
                </div>
              </div>
            </div>

          </div>
        )}

      </main>

      {/* ========================================================
          MODAL: ADD PAYMENT METHOD (UPI / BANK TRANSFER)
         ======================================================== */}
      {showAddPaymentModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-xl border border-[#DFD8C7] space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-[#FAF0E1] text-[#895719] flex items-center justify-center font-bold">
                  <CreditCard className="w-4 h-4" />
                </div>
                <h3 className="text-base font-bold text-[#2A1D0B] font-display">
                  Add Payment Receiving Method
                </h3>
              </div>
              <button
                onClick={() => setShowAddPaymentModal(false)}
                className="p-1 rounded-lg hover:bg-stone-100 text-stone-500"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-[#786750]">
              Configure UPI Virtual Payment Address or Bank Account to receive instant payments from farmers and FPOs.
            </p>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-[#4E3E28] uppercase tracking-wider mb-1">
                  1. Business UPI ID / VPA
                </label>
                <input
                  type="text"
                  defaultValue="kisansevakendra@okhdfcbank"
                  className="w-full px-3 py-2 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-mono font-bold text-[#2A1D0B]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#4E3E28] uppercase tracking-wider mb-1">
                  2. Bank Current Account Number
                </label>
                <input
                  type="text"
                  defaultValue="50200049281729"
                  className="w-full px-3 py-2 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-mono font-bold text-[#2A1D0B]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-[#4E3E28] uppercase tracking-wider mb-1">
                    IFSC Code
                  </label>
                  <input
                    type="text"
                    defaultValue="HDFC0001290"
                    className="w-full px-3 py-2 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-mono font-bold text-[#2A1D0B]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-[#4E3E28] uppercase tracking-wider mb-1">
                    Account Name
                  </label>
                  <input
                    type="text"
                    defaultValue="Kisan Seva Kendra"
                    className="w-full px-3 py-2 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-bold text-[#2A1D0B]"
                  />
                </div>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                onClick={() => setShowAddPaymentModal(false)}
                className="px-4 py-2 text-xs font-semibold text-[#786750] hover:bg-[#F2ECE0] rounded-xl min-h-[40px]"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  alert('UPI & Bank payment method saved and active for billing.');
                  setShowAddPaymentModal(false);
                }}
                className="px-4 py-2 bg-[#895719] hover:bg-[#6D420F] text-white text-xs font-bold rounded-xl shadow-xs min-h-[40px]"
              >
                Save Payment Method
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL: INVOICE / RECEIPT VIEWER
         ======================================================== */}
      {selectedInvoice && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-xl border border-[#DFD8C7] space-y-4">
            <div className="flex items-center justify-between border-b border-[#EFECE1] pb-3">
              <div>
                <span className="text-[10px] text-[#786750] uppercase font-mono">Tax Invoice & Mandi Receipt</span>
                <h3 className="text-base font-bold text-[#2A1D0B] font-display">
                  {selectedInvoice.invoiceRef}
                </h3>
              </div>
              <button
                onClick={() => setSelectedInvoice(null)}
                className="p-1 rounded-lg hover:bg-stone-100 text-stone-500"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex justify-between">
                <span className="text-[#786750]">Billed To / Received From:</span>
                <span className="font-bold text-[#2A1D0B]">{selectedInvoice.entityName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#786750]">Payment Mode:</span>
                <span className="font-bold text-[#2A1D0B]">{selectedInvoice.method}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#786750]">Date & Time:</span>
                <span className="font-bold text-[#2A1D0B]">{selectedInvoice.date}</span>
              </div>
              <div className="flex justify-between py-2 border-y border-[#EFECE1]">
                <span className="text-sm font-bold text-[#2A1D0B]">Total Amount Paid:</span>
                <span className="text-base font-extrabold text-[#234415] tabular-nums font-mono">
                  ₹{selectedInvoice.amount.toLocaleString('en-IN')}
                </span>
              </div>
            </div>

            <div className="p-3 bg-[#FAF8F3] rounded-xl text-[11px] text-[#786750] flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
              <span>Cryptographically verified on Mrittika Mandi Settlement Network</span>
            </div>

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                onClick={() => alert(`Invoice ${selectedInvoice.invoiceRef} downloaded as PDF`)}
                className="px-4 py-2 bg-[#234415] hover:bg-[#1A3410] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 shadow-xs min-h-[40px]"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download PDF Receipt</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL: ADD STOCK ITEM
         ======================================================== */}
      {showAddStockModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-xl border border-[#DFD8C7] space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-[#2A1D0B] font-display">
                Log New Inventory Batch
              </h3>
              <button
                onClick={() => setShowAddStockModal(false)}
                className="p-1 rounded-lg hover:bg-stone-100 text-stone-500"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-[#4E3E28] uppercase mb-1">
                  Product Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Urea 46% Neem Coated (KRIBHCO)"
                  className="w-full px-3 py-2 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-semibold text-[#2A1D0B]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-bold text-[#4E3E28] uppercase mb-1">
                    Category
                  </label>
                  <select className="w-full px-3 py-2 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-semibold text-[#2A1D0B]">
                    <option>Fertilizer</option>
                    <option>Seed</option>
                    <option>Pesticide</option>
                    <option>Irrigation</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-[#4E3E28] uppercase mb-1">
                    Quantity
                  </label>
                  <input
                    type="number"
                    placeholder="100"
                    className="w-full px-3 py-2 bg-[#FAF8F3] border border-[#D5CDBC] rounded-xl text-xs font-semibold text-[#2A1D0B]"
                  />
                </div>
              </div>
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                onClick={() => setShowAddStockModal(false)}
                className="px-4 py-2 text-xs font-semibold text-[#786750]"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  alert('Stock batch logged successfully');
                  setShowAddStockModal(false);
                }}
                className="px-4 py-2 bg-[#234415] text-white text-xs font-bold rounded-xl"
              >
                Add Stock
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
