import React, { useState } from 'react';
import { AppScreen, UserRole, LanguageCode, FarmerProfile, DealerProfile } from './types';
import { Navbar } from './components/Navigation/Navbar';
import { MrittikaAIPopup } from './components/Common/MrittikaAIPopup';
import { LandingScreen } from './components/Screens/LandingScreen';
import { SignUpPage } from './components/Screens/SignUpPage';
import { LoginPage } from './components/Screens/LoginPage';
import { RoleSelectionScreen } from './components/Screens/RoleSelectionScreen';
import { FarmerSignupScreen } from './components/Screens/FarmerSignupScreen';
import { DealerSignupScreen } from './components/Screens/DealerSignupScreen';
import { FarmerDashboard } from './components/Farmer/FarmerDashboard';
import { DealerDashboard } from './components/Dealer/DealerDashboard';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('login');
  const [currentRole, setCurrentRole] = useState<UserRole>('farmer');
  const [selectedLanguage, setSelectedLanguage] = useState<LanguageCode>('en');
  const [isAiPopupOpen, setIsAiPopupOpen] = useState<boolean>(true);

  // Initialized Profiles with realistic data
  const [farmerProfile, setFarmerProfile] = useState<FarmerProfile>({
    name: 'Rameshwar Patel',
    phone: '98261 44520',
    village: 'Pipaliya',
    district: 'Khargone',
    state: 'Madhya Pradesh',
    landSizeAcres: 4.5,
    primaryCrops: ['Soybean (सोयाबीन)', 'Wheat (गेहूं)', 'Mustard (सरसों)'],
    soilType: 'Black Cotton Soil (काली मिट्टी)',
    language: 'hi',
  });

  const [dealerProfile, setDealerProfile] = useState<DealerProfile>({
    name: 'Satish Kumar',
    phone: '98120 77341',
    businessName: 'Kisan Seva Kendra & Agri Supplies',
    businessType: 'Seeds, Fertilizers & Crop Protection',
    districtsCovered: ['Karnal', 'Kurukshetra', 'Panipat'],
    state: 'Haryana',
    gstin: '06AAECK9821L1Z9',
    verified: true,
  });

  // Flow handlers
  const handleSelectRole = (role: UserRole) => {
    setCurrentRole(role);
  };

  const handleFarmerSignupComplete = (profile: FarmerProfile) => {
    setFarmerProfile(profile);
    setSelectedLanguage(profile.language);
    setCurrentRole('farmer');
    setCurrentScreen('farmer-dashboard');
  };

  const handleDealerSignupComplete = (profile: DealerProfile) => {
    setDealerProfile(profile);
    setCurrentRole('dealer');
    setCurrentScreen('dealer-dashboard');
  };

  const handleFarmerLogin = () => {
    setCurrentRole('farmer');
    setCurrentScreen('farmer-dashboard');
  };

  const handleDealerLogin = () => {
    setCurrentRole('dealer');
    setCurrentScreen('dealer-dashboard');
  };

  return (
    <div className="min-h-screen bg-[#FBF9F4] text-[#1D2916] flex flex-col font-sans selection:bg-[#E2EED9] selection:text-[#18310E]">
      {/* Welcome Mrittika AI Pop-up at the beginning */}
      <MrittikaAIPopup
        isOpen={isAiPopupOpen}
        onClose={() => setIsAiPopupOpen(false)}
        onGetStarted={() => {
          setIsAiPopupOpen(false);
          setCurrentScreen('login');
        }}
      />

      {/* Top Bar Contract (3 Zones) */}
      <Navbar
        currentScreen={currentScreen}
        onNavigate={setCurrentScreen}
        currentRole={currentRole}
        onRoleChange={setCurrentRole}
        selectedLanguage={selectedLanguage}
        onLanguageChange={setSelectedLanguage}
        onOpenAiPopup={() => setIsAiPopupOpen(true)}
      />

      {/* Screen Router */}
      <main className="flex-1">
        {currentScreen === 'signup' && (
          <SignUpPage
            onNavigate={setCurrentScreen}
            onFarmerSignUp={handleFarmerSignupComplete}
            onDealerSignUp={handleDealerSignupComplete}
            selectedLanguage={selectedLanguage}
            onLanguageChange={setSelectedLanguage}
          />
        )}

        {currentScreen === 'login' && (
          <LoginPage
            onNavigate={setCurrentScreen}
            onLoginAsFarmer={handleFarmerLogin}
            onLoginAsDealer={handleDealerLogin}
          />
        )}

        {currentScreen === 'farmer-dashboard' && (
          <FarmerDashboard
            profile={farmerProfile}
            onUpdateProfile={(updated) => setFarmerProfile((prev) => ({ ...prev, ...updated }))}
            selectedLanguage={selectedLanguage}
            onLanguageChange={setSelectedLanguage}
            onSwitchToDealer={() => {
              setCurrentRole('dealer');
              setCurrentScreen('dealer-dashboard');
            }}
          />
        )}

        {currentScreen === 'dealer-dashboard' && (
          <DealerDashboard
            profile={dealerProfile}
            onUpdateProfile={(updated) => setDealerProfile((prev) => ({ ...prev, ...updated }))}
            onSwitchToFarmer={() => {
              setCurrentRole('farmer');
              setCurrentScreen('farmer-dashboard');
            }}
          />
        )}
      </main>
    </div>
  );
}
